import { test, expect } from '@playwright/test';
import { attachExchange, uniqueEmail } from './helpers';

// REQ-14: LOGIN-012 — authentication shall be performed by a trusted
// server-side mechanism. An API test inherently talks to the endpoint
// directly, bypassing the Angular client's own logic — exactly what this
// test case calls for.

// TC-REQ-14.1
test('TC-REQ-14.1: A login request bypassing client-side logic with invalid credentials is still rejected server-side', async ({ request }, testInfo) => {
  const unknownEmail = uniqueEmail('server-side'); // [test data] unique per run, guaranteed not registered

  const loginBody = { email: unknownEmail, password: 'anyPassword1' };
  const response = await request.post('/rest/user/login', { data: loginBody });
  const body = await attachExchange(testInfo, 'direct login request, bypassing the UI', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);

  expect(response.status(), `expected 401 rejection from the server, got ${response.status()} - ${JSON.stringify(body)}`).toBe(401);
  expect(response.headers()['set-cookie'], `expected no session/token cookie to be set on a rejected login, got ${JSON.stringify(response.headers())}`).toBeUndefined();
});
