# QA Pipeline — 8-Step Workflow

## Overview

The coordinator runs these 8 steps in sequence. Each step has specific input/output and success criteria.

```
┌─────────────────────────────────────────────────┐
│ Step 1: Task Context                            │
│ Input:  Issue key (from user)                   │
│ Output: <KEY>/context.md                        │
│ Skill:  task-context                            │
│ Model:  Sonnet (Medium effort)                  │
└─────────────────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────┐
│ Step 2: Requirements Grooming                   │
│ Input:  <KEY>/context.md                        │
│ Output: <KEY>/requirements.md (REQ-1, REQ-2...) │
│ Skill:  requirements-grooming                   │
│ Model:  Opus (High effort + Extended Thinking) │
└─────────────────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────┐
│ Step 3: QA Checklist                            │
│ Input:  <KEY>/requirements.md                   │
│ Output: <KEY>/checklist.md (REQ-1.1, REQ-1.2..)│
│ Skill:  qa-checklist                            │
│ Model:  Sonnet (Medium effort)                  │
└─────────────────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────┐
│ Step 4: QA Test Cases                           │
│ Input:  <KEY>/checklist.md                      │
│ Output: <KEY>/test-cases.md (TC-REQ-1.1, ...)   │
│ Skill:  qa-test-cases                           │
│ Model:  Sonnet (High effort)                    │
└─────────────────────────────────────────────────┘
                      ↓
        ┌─────────────────────────────────┐
        │  Step 5: PR Summary             │
        │  Input:  PR URL (from user)     │
        │  Output: <KEY>/pr-summary.md    │
        │  Skill:  pr-summary             │
        │  Model:  Sonnet (Medium effort) │
        └─────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────┐
│ Step 6: Code Review                             │
│ Input:  <KEY>/test-cases.md + pr-summary.md    │
│ Output: <KEY>/code-review.md (PASS/FAIL/QA)    │
│ Skill:  code-review                             │
│ Model:  Opus (High effort + Extended Thinking) │
└─────────────────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────┐
│ Step 7: Automation Strategy                     │
│ Input:  <KEY>/test-cases.md (+ code-review.md) │
│ Output: <KEY>/automation-strategy.md            │
│ Skill:  automation-strategy                     │
│ Model:  Sonnet (Medium effort)                  │
└─────────────────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────┐
│ Step 8: API Tests                               │
│ Input:  test-cases + automation-strategy        │
│ Output: <KEY>/api-tests/*.spec.ts + summary.md  │
│ Skill:  api-tests                               │
│ Model:  Sonnet (High effort)                    │
└─────────────────────────────────────────────────┘
                      ↓
              ✅ Pipeline Complete
```

## Step Details

### Step 1: Task Context Extraction

**What it does:** Queries your issue tracker and extracts all relevant information.

**Input:**
- Issue key (e.g., `PROJ-123`)

**Output:**
- `<ISSUE_KEY>/context.md` — Unified context file with:
  - Issue title and description
  - Acceptance criteria
  - Related tickets
  - Attachments (links)
  - Comments (relevant ones)

**Success Criteria:**
- File created and non-empty
- Contains all tracker fields
- Formatted as Markdown

**If it fails:**
- Check tracker access: `gh issue view PROJ-123`
- Verify issue key format
- Confirm read permissions

---

### Step 2: Requirements Grooming

**What it does:** Analyzes requirements for clarity, coverage, and risks. Creates numbered list.

**Input:**
- `<ISSUE_KEY>/context.md` from Step 1

**Output:**
- `<ISSUE_KEY>/requirements.md` with:
  - REQ-1, REQ-2, REQ-3... (sequential numbering)
  - Analysis findings (gaps, ambiguities)
  - Grooming questions asked to user
  - User responses

**Special:** Uses **Opus + Extended Thinking** (most complex step)

**Success Criteria:**
- File created with REQ-N numbering
- No gaps in numbering
- Requirements are numbered sequentially
- User accepted findings

**If it fails:**
- User may have rejected clarifying questions
- Re-run with more clarity in context
- Or approve requirements as-is

---

### Step 3: QA Checklist

**What it does:** Decomposes each requirement into atomic checks.

**Input:**
- `<ISSUE_KEY>/requirements.md` from Step 2

**Output:**
- `<ISSUE_KEY>/checklist.md` with:
  - REQ-1.1, REQ-1.2, REQ-2.1... (sub-numbered checks)
  - Each check is atomic and verifiable
  - Order matches requirements file

**Success Criteria:**
- File created with REQ-N.M numbering
- One requirement may have multiple checks
- Order preserved from requirements
- All checks are actionable

**If it fails:**
- Requirement may be ambiguous
- User may have unanswered clarifying questions
- Step 2 grooming may need refinement

---

### Step 4: QA Test Cases

**What it does:** Generates concrete test cases with steps, data, and expected results.

**Input:**
- `<ISSUE_KEY>/checklist.md` from Step 3

**Output:**
- `<ISSUE_KEY>/test-cases.md` with:
  - TC-REQ-1.1, TC-REQ-1.2... (test case numbering)
  - Each test case has: steps, test data, expected result
  - Based on checks in checklist
  - Uses exact values from requirements

**Success Criteria:**
- File created with TC-REQ-N.M numbering
- Test cases map to checks
- Steps are concrete and executable
- Data is marked `[test data]` if inferred

**If it fails:**
- Checklist may be incomplete
- Structural-only checks may not need test cases
- Step 3 checklist may need refinement

---

### Step 5: PR Summary

**What it does:** Reads PR and maps changed files and code diffs.

**Input:**
- PR URL or branch name (from user)

**Output:**
- `<ISSUE_KEY>/pr-summary.md` with:
  - List of changed files
  - What's added, deleted, changed in each file
  - Diff summary
  - Navigation map for code review

**Special:** Can run independently (no dependency on steps 1-4)

**Success Criteria:**
- File created with file listing
- Diffs are accurate
- Summary is complete

**If it fails:**
- Git CLI not authorized: `gh auth login`
- PR URL format invalid
- Repository not accessible

---

### Step 6: Code Review

**What it does:** Verifies each test case against PR code.

**Input:**
- `<ISSUE_KEY>/test-cases.md` from Step 4
- `<ISSUE_KEY>/pr-summary.md` from Step 5
- PR URL or branch name

**Output:**
- `<ISSUE_KEY>/code-review.md` with:
  - Results table: TC-ID → PASS/FAIL/QA
  - Findings for failed checks
  - Evidence of implementation

**Special:** Uses **Opus + Extended Thinking** (complex reasoning)

**Success Criteria:**
- File created with results table
- Each test case has a verdict
- Failed cases have explanations
- No false positives

**If it fails:**
- Test cases may not match PR scope
- PR may be incomplete
- Code may not implement requirements

---

### Step 7: Automation Strategy

**What it does:** Classifies each test case into a recommended automation approach — API, UI, or Manual/Not automatable.

**Input:**
- `<ISSUE_KEY>/test-cases.md` from Step 4
- `<ISSUE_KEY>/code-review.md` from Step 6 (optional — used only for priority notes)

**Output:**
- `<ISSUE_KEY>/automation-strategy.md` with:
  - One row per TC-REQ with a Recommendation (API/UI/Manual) and rationale
  - Statistics table with counts per category

**Success Criteria:**
- Every TC-REQ from the test-cases file has exactly one row with a rationale
- Order matches the test-cases file

**If it fails:**
- Test cases file may be missing or incomplete — run Step 4 first
- Genuinely ambiguous test cases may need a user answer before classification can finish

---

### Step 8: API Tests

**What it does:** Generates Playwright API test files (TypeScript, native `request` fixture) for every TC-REQ classified as API.

**Input:**
- `<ISSUE_KEY>/test-cases.md` from Step 4
- `<ISSUE_KEY>/automation-strategy.md` from Step 7
- Optional: a codebase folder path and/or a Swagger/OpenAPI document

**Output:**
- `<ISSUE_KEY>/api-tests/*.spec.ts` — one file per REQ group containing API-classified test cases
- `<ISSUE_KEY>/api-tests/summary.md` — traceability table and how-to-run instructions
- `<ISSUE_KEY>/api-tests/playwright.config.ts` — only if no existing config was detected

**Success Criteria:**
- Every API-classified TC-REQ has a generated test or a listed pending clarification in summary.md
- No endpoint, field, or status code invented — all sourced from codebase, Swagger doc, or explicit user answer

**If it fails:**
- automation-strategy may have zero API-classified items — nothing to generate
- No codebase/Swagger provided and the user hasn't answered the per-test-case clarification questions yet

---

## File Naming Convention

All files for one issue live under a folder named after the issue key,
inside the working directory: `<ISSUE_KEY>/<type>.md`. `api-tests`
additionally nests its output one level deeper in `<ISSUE_KEY>/api-tests/`.

| Step | Type | File | Generated By |
|------|------|------|--------------|
| 1 | context | `PROJ-123/context.md` | task-context |
| 2 | requirements | `PROJ-123/requirements.md` | requirements-grooming |
| 3 | checklist | `PROJ-123/checklist.md` | qa-checklist |
| 4 | test-cases | `PROJ-123/test-cases.md` | qa-test-cases |
| 5 | pr-summary | `PROJ-123/pr-summary.md` | pr-summary |
| 6 | code-review | `PROJ-123/code-review.md` | code-review |
| 7 | automation-strategy | `PROJ-123/automation-strategy.md` | automation-strategy |
| 8 | api-tests | `PROJ-123/api-tests/*.spec.ts`, `PROJ-123/api-tests/summary.md` | api-tests |

## Traceability

Requirements IDs flow through the pipeline:

```
requirements-grooming:  REQ-1, REQ-2, REQ-3a, REQ-3b
                           ↓
qa-checklist:          REQ-1.1, REQ-1.2, REQ-2.1, REQ-3a.1, REQ-3a.2, REQ-3b.1
                           ↓
qa-test-cases:         TC-REQ-1.1, TC-REQ-1.2, TC-REQ-2.1, TC-REQ-3a.1, TC-REQ-3b.1
                           ↓
code-review:           PASS TC-REQ-1.1 | FAIL TC-REQ-1.2 | QA TC-REQ-2.1
                           ↓
automation-strategy:   API TC-REQ-1.1 | UI TC-REQ-1.2 | Manual TC-REQ-2.1
                           ↓
api-tests:             TC-REQ-1.1 → checkout-webhooks.spec.ts (API-classified only)
```

**Key Rule:** Main REQ-N IDs never change across pipeline.
