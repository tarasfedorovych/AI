# QA Pipeline Coordinator Setup Guide

This guide helps you configure the QA Pipeline Coordinator for your team.

## Prerequisites

Before setting up the coordinator, you need:

1. **Issue Tracker Access** — Jira, GitHub Issues, GitLab, Linear, or Azure DevOps
2. **Git CLI Installed** — `gh` (GitHub), `glab` (GitLab), or other VCS CLI
3. **Git CLI Authorized** — Run `gh auth login` or equivalent for your VCS
4. **VS Code Chat Customizations** — Coordinator runs as a VS Code agent

## Configuration Checklist

- [ ] I know which tracker my team uses
- [ ] I know the issue key format (e.g., `PROJ-123` for Jira)
- [ ] Git CLI is installed and authorized
- [ ] I have read access to the repository

## Setup Steps

### Step 1: Identify Your Tracker System

**Which system does your team use?**

- **Jira Cloud/Server** → Issue format: `PROJ-123`
- **GitHub Issues** → Issue format: `#123` or `owner/repo#123`
- **GitLab** → Issue format: `GROUP/project#123`
- **Linear** → Issue format: `TEAM-123`
- **Azure DevOps** → Work item format: `123` or `PROJ-123`

> ⚠️ **CONFIGURE:** Open `SKILL.md` and update the example formats in the "8-Step Workflow" table if your format differs.

### Step 2: Verify Git CLI Access

**For GitHub (most common):**

```bash
gh auth login
# Follow prompts to authorize
gh pr view --help  # Verify access works
```

**For GitLab:**

```bash
glab auth login
glab mr view --help
```

**For Other VCS:**
- Azure DevOps: `az devops`
- Bitbucket: CLI or REST API

> ⚠️ **CONFIGURE:** If using a VCS other than GitHub, add specific CLI command examples to `references/vcs-setup.md`.

### Step 3: Test Issue Tracker Access

**For Jira:**
```bash
# Verify access (command depends on your Jira setup)
# Usually: curl -u user:token https://jira.example.com/rest/api/3/issue/PROJ-123
```

**For GitHub Issues:**
```bash
gh issue view PROJ-123
```

**For Linear:**
```bash
# Via Linear CLI or API
linear issue list
```

> ⚠️ **CONFIGURE:** Document your specific tracker access method in `references/tracker-setup.md`.

### Step 4: Update Coordinator with Your Settings

In `SKILL.md`, update these sections:

**Section: "Supported Trackers & VCS"**
- If using GitHub: Keep as-is
- If using Jira/GitLab/Linear/Azure: Add your tracker to the list

**Section: "Configuration"**
- Replace generic instructions with your specific setup
- Add your tracker and VCS names
- Example: "Verify Jira access with `jira issue view PROJ-123`"

### Step 5: Share with Team

Once configured, share these files:

1. **This setup-guide.md** — Team reads it before first use
2. **SKILL.md** — Reference for what the coordinator does
3. **references/workflow.md** — Details of the 8-step workflow

> ⚠️ **CONFIGURE:** Add team-specific notes to `references/team-notes.md`:
> - Your Jira/GitHub username pattern
> - Default branch names
> - Code review process
> - Any tool restrictions or requirements

## Troubleshooting

### "Coordinator can't access the tracker"

**Fix:** Run `gh auth login` (or your VCS CLI auth command) and verify access:
```bash
gh issue view PROJ-123
```

### "Coordinator can't access PR code"

**Fix:** Verify Git CLI is installed and authorized:
```bash
gh pr view https://github.com/owner/repo/pull/123
```

### "Coordinator stopped at Step 2"

**Fix:** Check that task-context skill completed successfully and file exists:
```bash
ls -la <ISSUE_KEY>/context.md
```

## File Structure

```
qa-pipeline-coordinator/
  SKILL.md                         — Agent definition (this file's parent)
  setup-guide.md                   — This setup guide
  references/
    workflow.md                    — Detailed 8-step workflow
    execution-log-template.md      — Template for tracking a coordinator run
    vcs-setup.md                   — Git CLI setup by system
    tracker-setup.md               — Issue tracker access setup
    team-notes.md                  — Your team's custom notes
```

## Next: Test the Coordinator

1. Pick a real issue from your tracker
2. Try: `@qa-pipeline-coordinator Run QA for PROJ-123`
3. Monitor the 8 steps
4. Review the generated files

## Questions?

- **"Can I use the coordinator for multiple projects?"** — Yes, use any issue key
- **"What if I don't have all 8 skills?"** — Coordinator will ask which skills you have configured
- **"Can I run coordinator without a PR URL?"** — Yes, coordinator asks for it during Step 5
- **"What files does coordinator create?"** — 8 files total, all under a folder named by the issue key (with api-tests output one level deeper in an api-tests/ subfolder)

## Support

For issues or questions:
1. Check `references/` folder for detailed docs
2. Verify tracker and VCS access work (manually test)
3. Check coordinator logs for which step failed
