# <ISSUEKEY> - Automation Strategy

Test cases: <path to test-cases file>
Code review: <path to code-review file, or "not provided">
Generated: <YYYY-MM-DD>

---

## REQ-1: <requirement text>

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-1.1 | <scenario name> | UI | Expected result requires reading a rendered success message on the page. |
| TC-REQ-1.2 | <scenario name> | API | All expected results are backend/event state, no rendered content is checked. |

---

## REQ-2: <requirement text>

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-2.1 | <scenario name> | Manual | Expected result depends on a third-party hosted page outside the product's own UI. |

---

## Statistics

| Recommendation | Count |
|-----------------|-------|
| API | <N> |
| UI | <N> |
| Manual / Not automatable | <N> |
| Total | <N> |

---

Section Rules:
- Metadata (Test cases, Code review, Generated) — each on a separate line.
- One table section per requirement group (### heading matches the REQ heading order in the test-cases file).
- One row per TC-REQ. No TC-REQ without a row, no row without a rationale.
- Statistics table — always present, counts must sum to the total number of TC-REQ rows.
