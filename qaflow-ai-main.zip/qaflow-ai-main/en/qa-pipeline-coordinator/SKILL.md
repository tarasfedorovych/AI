---
name: qa-pipeline-coordinator
description: >
  Orchestrates the core QA pipeline workflow. Runs 7 sequential skills
  automatically: task-context → requirements-grooming → qa-checklist →
  qa-test-cases → pr-summary → code-review → automation-strategy. Then
  pauses so the user can select which API-classified test cases to
  automate before running step 8 (api-tests). Steps 9 (ui-tests) and 10
  (manual-testing) are optional follow-ups the user triggers separately,
  not run automatically by this coordinator. Takes an issue key and
  optionally a PR URL, manages file handoff between steps, and produces
  all QA artifacts.
  Use when user says "run QA pipeline for PROJ-123" or 
  "run full QA for this issue".
---

# QA Pipeline Coordinator

Automates the 10-step QA workflow by orchestrating skills sequentially.
Steps 1-7 and step 8 run automatically with a mandatory checkpoint between
them; steps 9 and 10 are optional and the user invokes them separately
when needed. Coordinator manages state, validates preconditions, passes
files between steps, and reports progress and results to the user.

## What This Agent Does

1. **Parses Input** — Extracts issue key and optional PR URL
2. **Validates Setup** — Checks that required skills and tools are available
3. **Runs Steps 1-7 Sequentially** — Executes each skill via `runSubagent`
4. **Manages Files** — Passes output from step N as input to step N+1
5. **Validates Progress** — Checks that each step completed successfully
6. **Pauses for TC Selection** — After step 7, shows the automation-strategy
   classification and asks the user which API-classified test cases to
   automate before generating step 8
7. **Runs Step 8** — Generates api-tests only for the selected subset
8. **Reports Results** — Summarizes all created artifacts and points out
   that steps 9 (ui-tests) and 10 (manual-testing) are available as
   optional next steps, run on request

## User Invocation

**Simple:**
```
Run QA pipeline for PROJ-123
```

**With PR URL:**
```
Run QA pipeline for PROJ-123, PR is https://github.com/owner/repo/pull/456
```

**Or ask coordinator to help:**
```
What's the QA pipeline?
How do I use this coordinator?
```

## The 10-Step Workflow

Steps 1-8 are run by this coordinator (with a checkpoint between 7 and 8).
Steps 9-10 are optional and run independently — the coordinator does not
trigger them, but points to them at the end of the run.

| # | Skill | Input | Output | Purpose | Run by coordinator? |
|---|-------|-------|--------|---------|---------------------|
| 1 | task-context | Issue key | `<KEY>/context.md` | Extract task from tracker | Yes |
| 2 | requirements-grooming | Context file | `<KEY>/requirements.md` | Analyze requirements | Yes |
| 3 | qa-checklist | Requirements file | `<KEY>/checklist.md` | Decompose into checks | Yes |
| 4 | qa-test-cases | Checklist file | `<KEY>/test-cases.md` | Generate test cases | Yes |
| 5 | pr-summary | PR URL | `<KEY>/pr-summary.md` | Map PR changes | Yes |
| 6 | code-review | Test cases + PR summary | `<KEY>/code-review.md` | Verify implementation | Yes |
| 7 | automation-strategy | Test cases (+ code review) | `<KEY>/automation-strategy.md` | Classify test cases API/UI/Manual | Yes |
| — | *Checkpoint* | Automation strategy | User's selected TC-REQ subset | User picks which API-classified test cases to automate | Pauses here |
| 8 | api-tests | Selected test cases + automation strategy | `<KEY>/api-tests/*.spec.ts` + `summary.md` | Generate Playwright API tests | Yes, for selection only |
| 9 | ui-tests | Test cases + automation strategy | `<KEY>/ui-tests/*.spec.ts` + `summary.md` | Generate Playwright UI tests | No — optional, on request |
| 10 | manual-testing | Code review + test cases (+ automation strategy, ui-tests summary) | `<KEY>/manual-testing/report.md` | Manual/exploratory pass on whatever automation didn't cover | No — optional, on request |

## Checkpoint: Test Case Selection (before Step 8)

Step 8 is resource-intensive to generate, so the coordinator never
auto-generates tests for the full classified list. After step 7 produces
`automation-strategy.md`:

1. Stop before running step 8.
2. Show the user the classification results — counts and the list of
   API-classified TC-REQs.
3. Ask which of those TC-REQs should actually be generated as Playwright
   API tests.
4. Pass only the selected subset into step 8. Do not generate api-tests
   for TC-REQs the user didn't select.

This checkpoint applies to every run of the coordinator, not just a
one-off request.

## Key Features

✅ **Sequential Execution** — Steps run in order, not in parallel
✅ **Automatic File Handoff** — Previous step's output becomes next step's input
✅ **TC Selection Checkpoint** — Pauses after step 7 so the user controls
scope/cost before step 8 generates any tests
✅ **Error Handling** — Stops immediately if any step fails
✅ **Progress Reporting** — Shows what just completed
✅ **Configuration Optional** — Works out of the box for GitHub
✅ **Bilingual** — English (en/) and Ukrainian (ua/) for all 10 skills in
the pipeline, not just the 8 this coordinator touches — the optional
ui-tests (9) and manual-testing (10) skills are bilingual too

## Coordinator Rules

- Each skill must complete before next skill starts
- Validation: Check output file exists before proceeding
- On error: Stop and inform user of failure point
- Before step 8: stop and let the user select which API-classified
  TC-REQs to automate (see Checkpoint above) — never skip this to
  generate api-tests for the full classified list automatically
- Steps 9 and 10 are never triggered automatically — only run when the
  user separately asks for ui-tests or manual-testing
- On success: List all created files
- User can run individual skills manually if needed
- No file modification — only pass filenames

## Configuration

**Before first use, verify:**
- Tracker access working (Jira, GitHub, Linear, etc.)
- Git CLI installed and authorized (`gh auth login` for GitHub)
- Issue key format matches your tracker (e.g., `PROJ-123`)

See `setup-guide.md` for detailed configuration steps.

## Supported Trackers & VCS

**Trackers:** Jira, GitHub Issues, GitLab, Linear, Azure DevOps
**Version Control:** GitHub, GitLab, Bitbucket, Azure DevOps

Custom integrations supported via configuration.

## Next Steps

1. Read `setup-guide.md` for configuration
2. Run coordinator with an issue key
3. At the checkpoint, select which API-classified test cases to automate
4. Review generated files in working directory
5. Optionally run ui-tests (9) and/or manual-testing (10) for whatever
   step 8 didn't cover
6. Use individual skills for manual work if needed

## Questions?

- "How do I configure this?" → See setup-guide.md
- "What if a step fails?" → Coordinator will tell you what to check
- "Can I run one skill alone?" → Yes, use individual skills
- "Why did it stop after automation-strategy?" → That's the checkpoint —
  pick which API-classified test cases to automate, then it runs step 8
  for that selection
- "Does it also generate UI tests or do manual testing?" → No, those are
  steps 9 (ui-tests) and 10 (manual-testing) — optional, run them
  separately when you want them
- "How are files organized?" → All under a per-issue folder in the working directory: `<ISSUE_KEY>/<type>.md`, with API tests in `<ISSUE_KEY>/api-tests/`, UI tests in `<ISSUE_KEY>/ui-tests/`, and the manual testing report in `<ISSUE_KEY>/manual-testing/`
