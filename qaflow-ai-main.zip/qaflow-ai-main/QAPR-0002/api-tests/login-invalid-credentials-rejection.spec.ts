import { test, expect } from '@playwright/test';
import { attachExchange, uniqueEmail } from './helpers';

// REQ-7: LOGIN-005 — the system rejects an unknown email or an incorrect
// password. Endpoint: POST /rest/user/login. Expected results state
// rejection without a status code, but the discovered implementation
// (routes/login.ts) always answers a failed login with 401 and the fixed
// body "Invalid email or password." for both cases — confirmed empirically.

const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data]
const WRONG_PASSWORD = 'WrongPassw0rd!'; // [test data]

// TC-REQ-7.1
test('TC-REQ-7.1: Submitting an email that does not match any existing account is rejected', async ({ request }, testInfo) => {
  const unknownEmail = uniqueEmail('unknown'); // [test data] unique per run, guaranteed not registered

  const loginBody = { email: unknownEmail, password: 'anyPassword1' };
  const response = await request.post('/rest/user/login', { data: loginBody });
  const body = await attachExchange(testInfo, 'login with unknown email', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);

  expect(response.status(), `expected 401 for an unknown email, got ${response.status()} - ${JSON.stringify(body)}`).toBe(401);
});

// TC-REQ-7.2
test('TC-REQ-7.2: Submitting a correct/existing email with an incorrect password is rejected', async ({ request }, testInfo) => {
  const email = uniqueEmail('wrong-password');

  // Arrange — precondition: an account already exists with this email
  const registerBody = { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD };
  const registerResponse = await request.post('/api/Users', { data: registerBody });
  const registerRespBody = await attachExchange(testInfo, 'arrange: register existing account', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
  expect(registerResponse.status(), `expected 201 Created for the arrange-step registration, got ${registerResponse.status()} - ${JSON.stringify(registerRespBody)}`).toBe(201);

  // Act — enter the existing email with an incorrect password
  const loginBody = { email, password: WRONG_PASSWORD };
  const response = await request.post('/rest/user/login', { data: loginBody });
  const body = await attachExchange(testInfo, 'login with existing email, wrong password', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);

  // Assert — login is rejected
  expect(response.status(), `expected 401 for a wrong password, got ${response.status()} - ${JSON.stringify(body)}`).toBe(401);
});
