# QAPR-0001 - UI Tests Summary

Test cases: c:\src\!QA pipeline\QAPR-0001\test-cases.md
Automation strategy: c:\src\!QA pipeline\QAPR-0001\automation-strategy.md
Codebase reference: c:\src\!QA pipeline\juice-shop-master (read-only)
Live discovery: yes, see discovery/pages.json
UI mapping: QAPR-0001/ui-tests/ui-mapping.json
Generated: 2026-09-02

## Selection Checkpoint

UI-classified test cases available: 39
Selected for this run: 12 (REQ-1 through REQ-5)
Deferred by user: 27

| TC-REQ | Scenario | Decision |
|--------|----------|----------|
| TC-REQ-1.1 | Registration page is accessible to an unauthenticated visitor | Selected |
| TC-REQ-1.2 | Authenticated user opening the registration page is redirected away from it | Selected |
| TC-REQ-2a.2 | Email field accepts a value in the standard local@domain format | Selected |
| TC-REQ-2e.2 | Security Answer field accepts exactly 128 characters (maximum boundary) | Selected |
| TC-REQ-2e.3 | Security Answer field rejects a value exceeding 128 characters | Selected (pending — see below) |
| TC-REQ-2e.5 | Security Answer field accepts special characters and numbers | Selected |
| TC-REQ-3.1 | Unauthenticated visitor can view and interact with all registration fields | Selected |
| TC-REQ-4.1 | Email/Password/Confirm Password empty displays a validation error | Selected |
| TC-REQ-4.2 | Whitespace-only mandatory field treated as empty | Selected |
| TC-REQ-5.1 | Email field accepts a subdomain address | Selected |
| TC-REQ-5.2 | Email field accepts a plus-addressed value | Selected |
| TC-REQ-5.3 | Email field rejects a non-conforming value | Selected |
| TC-REQ-7.1 – TC-REQ-24.1 (27 items) | Password length, Confirm Password match, Security Question required, success/redirect messaging, repeated submission, injection safety, length/Unicode edge cases, end-to-end/duplicate/multi-field/mismatch acceptance criteria | Deferred by user |

## Traceability

| TC-REQ | Scenario | Test File | Test Name | Status |
|--------|----------|-----------|-----------|--------|
| TC-REQ-1.1 | Registration page is accessible to an unauthenticated visitor | registration-page-access.spec.ts | TC-REQ-1.1: ... | Generated |
| TC-REQ-1.2 | Authenticated user opening the registration page is redirected away from it | registration-page-access.spec.ts | TC-REQ-1.2: ... | Generated |
| TC-REQ-2a.2 | Email field accepts a value in the standard local@domain format | email-field-standard-format.spec.ts | TC-REQ-2a.2: ... | Generated |
| TC-REQ-2e.2 | Security Answer field accepts exactly 128 characters (maximum boundary) | security-answer-field.spec.ts | TC-REQ-2e.2: ... | Generated |
| TC-REQ-2e.3 | Security Answer field rejects a value exceeding 128 characters | — | — | Pending — no selector (see Pending Clarifications) |
| TC-REQ-2e.5 | Security Answer field accepts special characters and numbers | security-answer-field.spec.ts | TC-REQ-2e.5: ... | Generated |
| TC-REQ-3.1 | Unauthenticated visitor can view and interact with all registration fields | registration-field-visibility.spec.ts | TC-REQ-3.1: ... | Generated |
| TC-REQ-4.1 | Email/Password/Confirm Password empty displays a validation error | mandatory-field-validation.spec.ts | TC-REQ-4.1: ... | Generated |
| TC-REQ-4.2 | Whitespace-only mandatory field treated as empty | mandatory-field-validation.spec.ts | TC-REQ-4.2: ... | Generated |
| TC-REQ-5.1 | Email field accepts a subdomain address | email-format-validation.spec.ts | TC-REQ-5.1: ... | Generated |
| TC-REQ-5.2 | Email field accepts a plus-addressed value | email-format-validation.spec.ts | TC-REQ-5.2: ... | Generated |
| TC-REQ-5.3 | Email field rejects a non-conforming value | email-format-validation.spec.ts | TC-REQ-5.3: ... | Generated |

## Page Objects

| Page Object | File | Status | Used By |
|-------------|------|--------|---------|
| RegistrationPage | ui-framework/pages/RegistrationPage.ts | Created | TC-REQ-1.1, 1.2, 2a.2, 2e.2, 2e.5, 3.1, 4.1, 4.2, 5.1, 5.2, 5.3 |
| LoginPage | ui-framework/pages/LoginPage.ts | Created | TC-REQ-1.2 |
| (helper) dismissOverlays | ui-framework/pages/dismissOverlays.ts | Created | RegistrationPage.goto, LoginPage.goto |

`dismissOverlays` is a small shared helper (not a Page Object) used by
both pages' `goto()` — Juice Shop shows a first-visit welcome dialog and
a cookie-consent banner on every fresh browser context, confirmed via
the live discovery snapshot; every test gets a fresh context, so this
runs on every navigation.

## Discovered Selector Facts (why they differ from the generic reference doc)

Live discovery (`discovery/pages.json`) showed that every registration
and login form control carries an explicit `aria-label` that overrides
its visible `<mat-label>` text as the accessible name (confirmed
empirically, not assumed from Angular Material internals). Concretely:
Email is named "Email address field" (register) / "Text field for the
login email" (login), not "Email"; the submit button is named "Button
to complete the registration", not "Register". All locators in
`RegistrationPage`/`LoginPage` use these confirmed names via
`getByRole`, not the plain label text a generic example might suggest.

## Selector Fragility Notes

None — every locator uses `getByRole` (confirmed accessible name) or
`getByText` (confirmed translated validation string from
`frontend/src/assets/i18n/en.json`). No CSS/XPath selector was used.

## Cleanup Coverage

| TC-REQ | Creates persistent data? | Cleanup |
|--------|--------------------------|---------|
| TC-REQ-1.1 | No | N/A |
| TC-REQ-1.2 | Yes (throwaway account, precondition) | `DELETE /api/Users/:id` (confirmed available) |
| TC-REQ-2a.2 | Yes | `DELETE /api/Users/:id` (confirmed available) |
| TC-REQ-2e.2 | Yes | `DELETE /api/Users/:id` (confirmed available) |
| TC-REQ-2e.5 | Yes | `DELETE /api/Users/:id` (confirmed available) |
| TC-REQ-3.1 | No (verifies fields, never submits) | N/A |
| TC-REQ-4.1 | No (submit stays disabled while a field is empty) | N/A |
| TC-REQ-4.2 | No (submit stays disabled while email is invalid) | N/A |
| TC-REQ-5.1 | Yes | `DELETE /api/Users/:id` (confirmed available) |
| TC-REQ-5.2 | Yes | `DELETE /api/Users/:id` (confirmed available) |
| TC-REQ-5.3 | No (submit stays disabled while email is invalid) | N/A |

## Run Results (confirmed, `npx playwright test --workers=1`)

**9 passed, 2 failed.** Both failures are genuine app gaps found while
reading the codebase and confirmed by the run — not test defects:

- **TC-REQ-1.2** (fails): `frontend/src/app/app.routing.ts` has no
  `canActivate` guard on the `register` route, and
  `RegisterComponent.ngOnInit` contains no authentication check.
  Confirmed live: after registering, logging in, and navigating back to
  `/#/register`, the URL stays on `/#/register` and the Email field
  stays visible — no redirect mechanism exists for an authenticated
  user opening this page.
- **TC-REQ-4.2** (fails): `register.component.ts`'s `emailControl` uses
  Angular's built-in `Validators.required`, which does not trim
  whitespace before checking emptiness. Confirmed live: entering 3
  spaces and blurring the field shows "Email address is not valid."
  (the format validator), never the required-field message REQ-4
  specifies.

Run `npx playwright show-report` for the full report, including a
trace/screenshot/video for each of these two failures.

**Recommended: run with `--workers=1`.** The default parallel-worker run
against this single Juice Shop dev-mode instance produced intermittent,
unrelated timeouts (the security-question dropdown occasionally didn't
open in time) that disappeared once serialized — this is dev-server
contention under concurrent browser load, not a test defect.

## Implementation Notes (Page Object robustness)

Three non-obvious fixes were needed to make `RegistrationPage`/
`LoginPage` reliable against the real app, discovered by actually
running the generated suite rather than assumed:

- **`goto()` forces a fresh document load via `about:blank` first.**
  A same-document, hash-only navigation (e.g. `/#/search` →
  `/#/register`, or `/#/register` → itself) silently did not navigate
  at all in this environment — `page.goto('/#/register')` returned
  without error but left the browser on the previous URL. This first
  caused TC-REQ-1.2 to pass for the wrong reason (it never actually
  reached the register page to test the redirect). Confirmed by
  instrumenting the test with the real URL at assertion time.
- **`touchField()` uses `.focus()`, not `.click()`.** An empty,
  unfocused Material field's own floating `<mat-label>` (with its
  required-marker asterisk) rests directly over the input's clickable
  area until the field is focused, which makes a plain click's pointer
  hit-test intercept on that label and time out. `.focus()` sets focus
  directly without that hit-test.
- **`selectFirstSecurityQuestion()` opens via keyboard with a
  visible/hidden-state retry**, not a pointer click on the trigger —
  same label-overlap problem as above, plus the panel's close animation
  could still intercept the very next click for a moment.

## How to Run

See `README.md` for install/run instructions.

Existing Playwright setup detected: no — `juice-shop-master` uses
Cypress for e2e, not Playwright. A new `playwright.config.ts` and
`package.json` were scaffolded in this folder.

## Pending Clarifications

- TC-REQ-2e.3: `register.component.ts`'s `securityAnswerControl` has
  only `Validators.required` — no `Validators.maxLength(128)` — and
  the template has no `mat-error` markup for a Security Answer length
  violation. There is no selector to generate against because the
  codebase does not implement client-side enforcement of the
  128-character maximum REQ-2e describes. Needs a decision: is this
  enforced server-side only (out of scope for this UI suite), or is it
  a genuine product gap to raise separately?
