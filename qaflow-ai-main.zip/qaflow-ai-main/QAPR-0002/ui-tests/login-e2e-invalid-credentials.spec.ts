import { test, expect } from '@playwright/test';
import { LoginPage } from '../../ui-framework/pages/LoginPage';

// REQ-23: AC-LOGIN-002 (Invalid Credentials) — given the submitted
// credentials are incorrect, login fails, no authenticated session is
// created, and an appropriate error is displayed.

// TC-REQ-23.1
test('TC-REQ-23.1: Incorrect credentials fail login, create no session, and display an appropriate error', async ({ page }) => {
  const loginPage = new LoginPage(page);

  await test.step('Submit the login form with incorrect credentials', async () => {
    await loginPage.goto();
    await loginPage.login('unknown.user@example.com', 'anyPassword1'); // [test data]
  });

  await test.step('Verify authentication fails and no authenticated session is created', async () => {
    await expect(page, 'expected to remain on the login page after a failed attempt').toHaveURL(/#\/login/);
    expect(await loginPage.isAuthenticated(), 'expected the account menu to show no Logout item (no session)').toBe(false);
  });

  await test.step('Verify an appropriate error is displayed', async () => {
    await expect(
      loginPage.invalidCredentialsError,
      'expected an appropriate error to be displayed for the failed login'
    ).toBeVisible();
  });
});
