import { defineConfig, devices } from '@playwright/test';

// No playwright.config.ts/.js was found in the provided codebase folder
// (juice-shop-master uses Cypress for e2e, not Playwright), so this
// minimal config is scaffolded here. baseURL is the app's confirmed
// running port, not a placeholder.
export default defineConfig({
  reporter: [['html', { open: 'never' }]],
  use: {
    baseURL: 'http://localhost:3000',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
  ],
});
