# QAPR-0001 - QA Checklist

Requirements: c:\src\!QA pipeline\QAPR-0001\requirements.md
Generated: 2026-08-31

## Checklist

### REQ-1: Preconditions: The application is available; the user is not authenticated; the registration page is accessible. If an already authenticated user opens the registration page, the user is redirected away from it.
- [ ] REQ-1.1: Registration page is accessible to an unauthenticated visitor.
- [ ] REQ-1.2: An authenticated user who opens the registration page is redirected away from it.

### REQ-2a: Registration Field — Email (required, valid format and unique). Accepted format is the standard `local@domain` form, including subdomains and plus-addressing.
- [ ] REQ-2a.1: Email field is present on the registration form.
- [ ] REQ-2a.2: Email field accepts a value in the standard `local@domain` format.

### REQ-2b: Registration Field — Password (required, must satisfy the configured password policy: minimum 8 and maximum 128 characters).
- [ ] REQ-2b.1: Password field is present on the registration form.

### REQ-2c: Registration Field — Confirm Password (required, must match Password).
- [ ] REQ-2c.1: Confirm Password field is present on the registration form.

### REQ-2d: Registration Field — Security Question (required when security questions are enabled — user selects an available question).
- [ ] REQ-2d.1: Security Question field is present on the registration form.
- [ ] REQ-2d.2: Security Question field is a select from which the user chooses one question.
- [ ] REQ-2d.3: Security Question select is populated with available security questions.

### REQ-2e: Registration Field — Security Answer (required when security questions are enabled; must be non-empty after trim, maximum 128 characters, compared case-sensitively, with no other format restriction).
- [ ] REQ-2e.1: Security Answer field is present on the registration form.
- [ ] REQ-2e.2: Security Answer field accepts a value of exactly 128 characters (maximum boundary).
- [ ] REQ-2e.3: Security Answer field rejects a value exceeding 128 characters with a validation error.
- [ ] REQ-2e.4: Security Answer comparison is case-sensitive — a value differing only in letter case does not match.
- [ ] REQ-2e.5: Security Answer field accepts special characters and numbers with no additional format restriction beyond length and non-empty-after-trim.

### REQ-3: REG-001: The system shall allow an unauthenticated visitor to open the registration form. An authenticated user is redirected away from it per REQ-1.
- [ ] REQ-3.1: An unauthenticated visitor who opens the registration form can view and interact with all registration fields (Email, Password, Confirm Password, Security Question, Security Answer).

### REQ-4: REG-002: The system shall require all mandatory registration fields. All mandatory fields are trimmed before the required-field check, so a whitespace-only value counts as empty and fails validation.
- [ ] REQ-4.1: Submitting the registration form with Email, Password, or Confirm Password left completely empty displays a validation error for that field.
- [ ] REQ-4.2: Submitting the registration form with a mandatory field containing only whitespace characters displays a validation error for that field (whitespace-only treated as empty).

### REQ-5: REG-003: The system shall validate the email format against the standard `local@domain` form, accepting subdomains and plus-addressing.
- [ ] REQ-5.1: Email field accepts an address containing a subdomain (e.g., user@mail.example.com).
- [ ] REQ-5.2: Email field accepts a plus-addressed value (e.g., user+tag@example.com).
- [ ] REQ-5.3: Email field rejects a value that does not conform to the standard `local@domain` format.

### REQ-6: REG-004: The system shall not allow two accounts with the same email address. Emails are normalized by trimming whitespace and lowercasing before the uniqueness comparison. Uniqueness is enforced at persistence level (e.g. a database unique constraint), not only by a pre-check lookup; if two submissions race, exactly one succeeds and the other receives the generic registration failure message defined in REQ-14.
- [ ] REQ-6.1: Registering with an email identical to an existing account's email is rejected.
- [ ] REQ-6.2: Registering with an email differing only by leading or trailing whitespace from an existing account's email is rejected.
- [ ] REQ-6.3: Registering with an email differing only by letter case from an existing account's email is rejected.
- [ ] REQ-6.4: When two registration submissions for the same normalized email are processed concurrently, exactly one account is created and the other submission receives the generic registration failure message.

### REQ-7: REG-005: The system shall validate the password against the configured password policy: minimum 8 and maximum 128 characters.
- [ ] REQ-7.1: Password field accepts a value of exactly 8 characters (minimum boundary).
- [ ] REQ-7.2: Password field rejects a value of 7 characters (below minimum) with a validation error.
- [ ] REQ-7.3: Password field accepts a value of exactly 128 characters (maximum boundary).
- [ ] REQ-7.4: Password field rejects a value of 129 characters (above maximum) with a validation error.

### REQ-8: REG-006: Confirm Password shall exactly match Password.
- [ ] REQ-8.1: Submitting the form with Confirm Password identical to Password passes validation for this field.
- [ ] REQ-8.2: Submitting the form with Confirm Password different from Password displays a validation error indicating the mismatch.

### REQ-9: REG-007: If security questions are enabled, the user shall provide the required question and answer.
- [ ] REQ-9.1: With security questions enabled, submitting the form without selecting a Security Question displays a validation error.
- [ ] REQ-9.2: With security questions enabled, submitting the form without a Security Answer displays a validation error.

### REQ-10: REG-008: Registration data shall be validated by the server even when client-side validation exists.
- [ ] REQ-10.1: Registration data submitted directly to the server, bypassing client-side validation, is still validated server-side and invalid data is rejected.

### REQ-11: REG-009: Valid registration data shall create exactly one customer account. The account is immediately active on creation with the default role "customer"; no email verification or activation step is required.
- [ ] REQ-11.1: Submitting valid registration data creates exactly one customer account.
- [ ] REQ-11.2: The newly created account has the default role "customer".
- [ ] REQ-11.3: The newly created account is immediately active without requiring email verification or an activation step.

### REQ-12: REG-010: Invalid registration data shall not create an account.
- [ ] REQ-12.1: Submitting invalid registration data does not create a customer account.

### REQ-13a: REG-011: After successful registration, the user shall receive a clear success indication.
- [ ] REQ-13a.1: After successful registration, a success indication is displayed to the user.

### REQ-13b: REG-011: After successful registration, the user shall be redirected to the login page; the user is not automatically logged in.
- [ ] REQ-13b.1: After successful registration, the user is redirected to the login page.
- [ ] REQ-13b.2: After successful registration, the user is not automatically logged in.

### REQ-14: REG-012: Validation failures shall display an appropriate error without exposing internal system details — no stack traces, raw database errors, or internal identifiers. A failure caused by an already-registered email shall show a generic failure message that does not reveal whether the email already exists.
- [ ] REQ-14.1: A validation failure displays an error message without any stack trace, raw database error, or internal identifier.
- [ ] REQ-14.2: A registration failure caused by an already-registered email displays a generic failure message that does not reveal whether the email already exists.

### REQ-15: BR-REG-001: Email addresses must be unique after normalization, where normalization is defined as trimming whitespace and lowercasing before the uniqueness comparison (same single rule as REQ-6).
This business rule restates the same uniqueness rule as REQ-6. No additional check is added here to avoid duplication — see REQ-6.1–REQ-6.4 for verification of this rule.

### REQ-16: BR-REG-002: Passwords shall never be stored or logged in plaintext; they are hashed at rest, never written to logs, and never returned in any API response or error output.
- [ ] REQ-16.1: Password value does not appear anywhere in application logs.
- [ ] REQ-16.2: Password value is not returned in any API response, including error responses.
- [ ] REQ-16.3: Password is stored at rest in hashed form, not in plaintext.

### REQ-17: BR-REG-003: Credentials shall be transmitted securely in non-development environments.
- [ ] REQ-17.1: Registration data, including Password, is transmitted over a secure (HTTPS/TLS) connection in the QA environment under test.

### REQ-18: BR-REG-004: Repeated submission shall not create duplicate accounts. This covers double-click, page refresh / POST resubmission, and back-button resubmission, and is guaranteed by the same persistence-level uniqueness enforcement as REQ-6.
- [ ] REQ-18.1: Double-clicking the submit action during registration creates only one account.
- [ ] REQ-18.2: Refreshing the page after a registration POST submission (resubmitting the same form data) does not create a duplicate account.
- [ ] REQ-18.3: Using the browser back button after successful registration and resubmitting does not create a duplicate account.
- [ ] REQ-18.4: The repeat submission that does not result in account creation displays the generic registration failure message defined in REQ-14.

### REQ-19: BR-REG-005: User input shall be handled safely and shall not allow script or query injection. Dangerous input is safely escaped on output wherever registration data (email, security answer) is later displayed, rather than rejected outright, unless it also violates the field's own format rule.
- [ ] REQ-19.1: A Security Answer value containing script or HTML markup (e.g., `<script>alert(1)</script>`) is accepted and is safely escaped wherever it is later displayed, without executing as script.
- [ ] REQ-19.2: A Security Answer value containing SQL-like syntax (e.g., `' OR '1'='1`) is accepted and does not cause a database error or unintended query behavior.
- [ ] REQ-19.3: An Email value containing script or HTML-like characters that violates the standard email format rule is rejected by email format validation.

### REQ-20: Important Edge Cases (for grooming/test design coverage): empty mandatory fields; invalid email format; existing email; existing email with different letter case; leading/trailing whitespace in email; password below or above allowed length; password and confirmation mismatch; missing security question/answer when required; very long input; Unicode and special-character input; HTML/JavaScript-like or SQL-like input; multiple rapid submissions; network or backend failure during registration. Explicit maximum lengths apply — email 255, password 128, security answer 128 — and over-limit input is rejected with a validation error, never silently truncated. Unicode letters are accepted in password and security answer; email must still conform to the standard format rule in REQ-5; characters that do not break a field's own format are accepted and safely escaped on output per REQ-19. Multiple rapid submissions concern duplicate-account prevention (covered by REQ-6 and REQ-18), not rate limiting.
- [ ] REQ-20.1: Email field accepts a value of exactly 255 characters (maximum boundary).
- [ ] REQ-20.2: Email field rejects a value exceeding 255 characters, displaying a validation error rather than truncating it.
- [ ] REQ-20.3: Password field accepts a value containing Unicode letters (e.g., accented or non-Latin characters).
- [ ] REQ-20.4: Security Answer field accepts a value containing Unicode letters (e.g., accented or non-Latin characters).

### REQ-21: AC-REG-001 (Successful Registration): Given a visitor provides a unique valid email and valid mandatory data, when registration is submitted, then exactly one account is created and registration success is shown.
- [ ] REQ-21.1: Given a unique valid email and valid mandatory registration data, submitting the form creates exactly one account and displays the registration success indication.

### REQ-22: AC-REG-002 (Duplicate Email): Given an account already exists for the email, when the visitor registers with the same normalized email, then registration fails, no additional account is created, and the error shown is generic and does not reveal that the email is already registered.
- [ ] REQ-22.1: Given an account already exists for an email, registering with the same normalized email fails, creates no additional account, and displays the generic failure message without revealing that the email already exists.

### REQ-23: AC-REG-003 (Invalid Input): Given one or more mandatory values are missing or invalid, when registration is submitted, then registration fails, all validation errors for the currently-invalid fields are displayed together (not only the first), and no account is created.
- [ ] REQ-23.1: Given one or more mandatory values are missing or invalid, submitting the form fails and creates no account.
- [ ] REQ-23.2: When multiple fields are invalid at once, validation errors for all currently-invalid fields are displayed together, not only for the first invalid field.

### REQ-24: AC-REG-004 (Password Mismatch): Given Password and Confirm Password differ, when registration is submitted, then registration fails and the mismatch is communicated to the user.
- [ ] REQ-24.1: Given Password and Confirm Password differ, submitting the form fails and the mismatch is communicated to the user.

### REQ-25: AC-REG-005 (Backend Failure): Given valid registration data and account creation fails on the backend, when registration is submitted, then the user receives a controlled error and no partially usable account remains — no user record persists after the failed write, and the same email can be retried afterward.
- [ ] REQ-25.1: Given valid registration data, when account creation fails on the backend, the user receives a controlled error message instead of a raw system or server error.
- [ ] REQ-25.2: After a failed backend write during registration, no user record persists in the system for that attempt.
- [ ] REQ-25.3: After a failed backend write during registration, the same email can be used to retry registration.
