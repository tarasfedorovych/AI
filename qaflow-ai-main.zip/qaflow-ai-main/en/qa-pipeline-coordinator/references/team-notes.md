# Team Notes

> ⚠️ **CONFIGURE:** fill out this file with your team's conventions so
> the coordinator and individual skills follow them. Replace all
> `<placeholders>` with real values. After filling in — delete these
> ⚠️ CONFIGURE blocks.

## Identity

- **Jira/GitHub username pattern:** `<e.g. first.last, @handle>`
- **Default branch name:** `<e.g. main, master, develop>`

## Process

- **Code review process:** `<who reviews, required approvals, etc.>`
- **Tool restrictions or requirements:** `<e.g. no auto-merge, no force-push>`

## Notes

- `<anything else future runs of the coordinator should know>`
