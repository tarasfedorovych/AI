# UI Тести — Структура виводу

## `ui-mapping.json`

Схема, поля та готові приклади (single-page, multi-page flow, reused
vs. created Page Object, pending entry) — в
references/ui-mapping-schema.md. Генеруй цей файл перед будь-яким
файлом `.spec.ts`; файли Playwright рендеряться з нього.

## `package.json` (тільки коли заготовлюється самодостатня папка)

```json
{
  "name": "<issuekey-lowercase>-ui-tests",
  "private": true,
  "version": "1.0.0",
  "scripts": {
    "test": "playwright test"
  },
  "devDependencies": {
    "@playwright/test": "<pinned exact version, e.g. 1.62.1 — check the current release, don't guess>"
  }
}
```

На відміну від API-тестів, це потребує справжніх браузерних
бінарників — зазнач крок встановлення в `README.md` (`npx
playwright install chromium`).

## `README.md`

```
# <ISSUEKEY> - UI Тести

## Передумови
- Node.js <версія, що використовується/передбачається>
- Застосунок під тестуванням запущений і доступний за <baseURL>

## Встановлення
<cd <ISSUEKEY>/ui-tests && npm install>
  — або, якщо повторно використовується існуюча кодова база: <cd <шлях> && npm install>
<npx playwright install chromium>
  — встановлює браузерний бінарник; пропусти лише якщо повторно
  використана кодова база вже має його.

## Запуск
<npm test>
  — або еквівалентна команда для скрипта тестів існуючої кодової бази

## Перегляд звіту
<npx playwright show-report>
  — відкриває HTML-звіт з останнього запуску. Провалені тести мають
  трейс, скріншот та відео — відкрий трейс, щоб прогорнути точний
  стан DOM/мережі/консолі на кожному test.step.

## Примітки
- <будь-яка змінна середовища, логін чи вимога до seed-даних, на
  які розраховують тести>
- Page Object, які використовують ці тести, живуть у спільній папці
  `ui-framework/pages/` в корені репозиторію, не всередині цієї
  папки — вони повторно використовуються між задачами.
- Відкладені (deferred) та pending тест-кейси (див. summary.md) не
  включені в цей запуск.
```

Тримай цей файл коротким — це шлях copy-paste для людини, яка ніколи
не бачила цю папку раніше, а не переказ summary.md.

## Форма згенерованого файлу `.spec.ts`

Дивись references/playwright-ui-conventions.md щодо повних правил
генерації. Кожен файл починається з імпорту Playwright та імпорту
Page Object, яких він потребує, з `../../ui-framework/pages/...`,
будь-яких констант `[test data]`, потім одного блоку `test()` на
TC-REQ пункт у цій групі REQ, кожен з фазами `test.step` та
перевірками, що спираються на Page Object.

## `summary.md`

```
# <ISSUEKEY> - Резюме UI Тестів

Тест-кейси: <шлях до файлу тест-кейсів>
Стратегія автоматизації: <шлях до файлу automation-strategy>
Кодова база: <шлях, або "не надано">
Живий пошук: <так, див. discovery/pages.json / не потрібен / не надано>
UI мапінг: <ISSUEKEY>/ui-tests/ui-mapping.json
Згенеровано: <YYYY-MM-DD>

## Контрольна точка вибору

Доступні UI-класифіковані тест-кейси: <N>
Вибрано для цього запуску: <N>
Відкладено користувачем: <N>

| TC-REQ | Сценарій | Рішення |
|--------|----------|----------|
| TC-REQ-1.1 | Registration page is accessible to an unauthenticated visitor | Selected |
| TC-REQ-2a.2 | Email field accepts a value in the standard local@domain format | Deferred by user |

## Трасованість

| TC-REQ | Сценарій | Файл тесту | Назва тесту | Статус |
|--------|----------|-----------|-----------|--------|
| TC-REQ-1.1 | Registration page is accessible to an unauthenticated visitor | registration-page-access.spec.ts | TC-REQ-1.1: Registration page is accessible to an unauthenticated visitor | Generated |
| TC-REQ-8.3 | Password strength meter updates as the user types | password-strength.spec.ts | — | Pending — потрібен селектор |

## Page Object

| Page Object | Файл | Статус | Використовується в |
|-------------|------|--------|---------|
| RegistrationPage | ui-framework/pages/RegistrationPage.ts | Reused (extended) | TC-REQ-1.1, TC-REQ-4.1 |
| LoginPage | ui-framework/pages/LoginPage.ts | Created | TC-REQ-1.2 |

## Нотатки про крихкість селекторів

Повністю пропусти цю секцію, якщо не використано жодного CSS/XPath
селектора.

| TC-REQ | Елемент | Селектор | Чому не role/label/testid |
|--------|---------|----------|----------------------------|
| TC-REQ-8.3 | strength meter bar | `.password-strength-bar` | Немає accessible name, лейбла чи test id, що відрізняє його від інпуту |

## Покриття очищення

| TC-REQ | Створює постійні дані? | Очищення |
|--------|--------------------------|---------|
| TC-REQ-1.2 | Так (акаунт, через попередню передумову логіну) | DELETE /api/Users/:id (підтверджено доступний) |
| TC-REQ-1.1 | Ні | N/A |

Пропускай рядки для TC-REQ пунктів, чиї кроки не створюють жодного
постійного ресурсу, або тримай секцію короткою, перелічуючи лише
винятки — завжди додавай цю секцію, якщо хоча б один згенерований
тест створює постійні дані.

## Як запустити

Див. `README.md` для інструкцій встановлення/запуску.

Виявлено існуюче налаштування Playwright: <так, за <шлях> / ні — заготовлено нову конфігурацію та package.json>

## Очікують уточнення

- TC-REQ-X.Y: <що було запитано, все ще без відповіді>
```

Правила секцій:
- Контрольна точка вибору — присутня завжди; перелічує кожен
  UI-класифікований TC-REQ пункт з його рішенням Selected/Deferred.
- Таблиця трасованості — один рядок на кожен *вибраний* TC-REQ
  пункт, включно з pending.
- Таблиця Page Object — присутня завжди, коли згенеровано хоча б
  один тест; перелічує кожен Page Object, задіяний у цьому запуску,
  повторно використаний чи новостворений.
- Нотатки про крихкість селекторів — присутні лише якщо використано
  хоча б один CSS/XPath селектор; інакше відсутні.
- Очікують уточнення — присутня лише якщо хоча б один пункт очікує
  уточнення; інакше секція відсутня повністю.
- Як запустити — присутня завжди, повинна вказувати, чи використана
  існуюча конфігурація, чи заготовлена нова.
