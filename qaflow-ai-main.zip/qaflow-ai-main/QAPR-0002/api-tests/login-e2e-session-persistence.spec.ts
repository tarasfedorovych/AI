import { test, expect } from '@playwright/test';
import { attachExchange, uniqueEmail } from './helpers';

// REQ-25: AC-LOGIN-004 (Session Persistence) — given the customer
// successfully logged in, navigating within the application while the
// session is valid keeps the customer authenticated. A subsequent
// authenticated request stands in for "navigates within the application"
// at the API layer (same underlying mechanism as TC-REQ-10.1; kept
// separate to preserve 1:1 traceability to this distinct AC).

const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data]

// TC-REQ-25.1
test('TC-REQ-25.1: Customer remains authenticated while navigating with a valid session', async ({ request }, testInfo) => {
  const email = uniqueEmail('e2e-session-persistence');

  await test.step('Given the customer successfully logged in', async () => {
    const registerBody = { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD };
    const registerResponse = await request.post('/api/Users', { data: registerBody });
    await attachExchange(testInfo, 'given: register', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
    expect(registerResponse.status(), `expected 201 Created, got ${registerResponse.status()}`).toBe(201);
  });

  let token!: string;
  await test.step('customer logs in', async () => {
    const loginBody = { email, password: VALID_PASSWORD };
    const response = await request.post('/rest/user/login', { data: loginBody });
    const body = await attachExchange(testInfo, 'login', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);
    expect(response.status(), `expected 200 OK, got ${response.status()} - ${JSON.stringify(body)}`).toBe(200);
    token = body.authentication.token;
  });

  await test.step('When the customer navigates within the application while the session is valid', async () => {
    const response = await request.get('/rest/user/whoami', { headers: { Cookie: `token=${token}` } });
    const body = await attachExchange(testInfo, 'when: subsequent authenticated request (stand-in for in-app navigation)', { method: 'GET', url: '/rest/user/whoami', headers: { Cookie: 'token=<redacted>' } }, response);
    // Then the customer remains authenticated
    expect(response.status(), `expected 200 OK, got ${response.status()}`).toBe(200);
    expect(body.user?.email, `expected the customer to remain authenticated as ${email}, got ${JSON.stringify(body)}`).toBe(email);
  });
});
