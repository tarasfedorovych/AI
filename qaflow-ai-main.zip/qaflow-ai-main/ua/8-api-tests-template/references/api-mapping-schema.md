# API Mapping Schema — довідка

`api-mapping.json` — це фреймворк-агностичний масив, один запис на
кожен API-класифікований TC-REQ пункт (включно з pending). Він
фіксує рішення пошуку ендпоінту до того, як написано будь-який
Playwright-специфічний код, щоб вони були придатними для рев'ю самі
по собі і придатними для повторного використання іншим рендерером
пізніше.

Не запихуй кожен тест-кейс в єдину форму запиту/відповіді — кілька
кейсів, які цей скіл фактично мусить покривати, є багатокроковими
ланцюжками або гонками (race conditions). Використовуй `steps: [...]`
(один або більше) для всіх записів, навіть однозапитних, щоб форма
була однорідною.

## Поля

```jsonc
{
  "tcReqId": "TC-REQ-11.1",
  "reqGroup": "REQ-11",
  "title": "Submitting valid registration data creates exactly one customer account",
  "status": "generated",          // "generated" | "pending"
  "reason": null,                  // required, non-null when status is "pending"
  "source": "swagger",             // "swagger" | "codebase" | "user-provided"
  "variables": {
    "email": "[test data] unique per run",
    "password": "[test data] valid mandatory data"
  },
  "steps": [
    {
      "name": "register",
      "method": "POST",
      "endpoint": "/api/Users",
      "body": { "email": "${email}", "password": "${password}", "passwordRepeat": "${password}" },
      "expectedStatus": 201,
      "capture": { "userId": "response.data.id" },
      "assertions": ["response.data.email equals ${email}"]
    }
  ],
  "concurrency": null,             // null, or see "Concurrent steps" below
  "cleanup": [
    { "method": "DELETE", "endpoint": "/api/Users/${userId}", "source": "codebase", "note": "confirmed available, no auth required" }
  ],
  "notes": []                       // e.g. substituted [test data] literals, discovery caveats
}
```

- `tcReqId` / `reqGroup` / `title` — копіюються дослівно з
  test-cases.md / automation-strategy.md. Ніколи не перефразовуються.
- `status` — `"pending"` означає, що не знайдено впевненого
  ендпоінту/механізму; `reason` повинен пояснювати, якого доступу
  чи механізму бракує (не генеруй тест `.spec.ts` для цього запису).
- `source` — звідки взято ендпоінт/схему кроку. Використовуй
  `"user-provided"` лише коли користувач відповів на згруповане
  уточнювальне питання саме для цього TC-REQ.
- `variables` — кожен `${плейсхолдер}`, використаний будь-де в
  `steps` чи `cleanup`, повинен бути оголошений тут, позначений
  `[test data]`, коли це реалістичний приклад, а не літеральне
  значення з вимоги.
- `steps` — впорядкований список. `capture` називає значення,
  взяті з відповіді кроку, для використання в `body`/`endpoint`
  наступного кроку (через той самий синтаксис плейсхолдера
  `${name}`). `assertions` — короткі, конкретні, природномовні
  перевірки (що дзеркально відображають власний Очікуваний
  Результат тест-кейсу) — не розпливчасті слова на кшталт
  «коректно»/«належним чином».
- `cleanup` — один або більше кроків для запуску після тесту, для
  будь-якого ресурсу, створеного кроком. Пропускай ключ повністю
  (не як порожній масив) лише коли кроки запису взагалі не
  створюють постійного ресурсу (наприклад, тест на відхилену
  реєстрацію). Якщо ресурс створюється, але механізм очищення не
  знайдено — залиш ключ з порожнім масивом і зазнач це в `notes` —
  не пропускай його мовчки.

## Паралельні кроки

Для тест-кейсу на race condition назви кроки, які повинні
спрацювати разом, і встанови режим:

```jsonc
"steps": [
  { "name": "submitA", "method": "POST", "endpoint": "/api/Users", "body": { "email": "${raceEmail}", "...": "..." } },
  { "name": "submitB", "method": "POST", "endpoint": "/api/Users", "body": { "email": "${raceEmail}", "...": "..." } }
],
"concurrency": { "parallelSteps": ["submitA", "submitB"] }
```

Рендерер запускає `parallelSteps` разом (наприклад, `Promise.all` у
Playwright), а не послідовно.

## Приклад pending-запису

```jsonc
{
  "tcReqId": "TC-REQ-16.1",
  "reqGroup": "REQ-16",
  "title": "Password value does not appear anywhere in application logs",
  "status": "pending",
  "reason": "У swagger.yml чи кодовій базі не знайдено ендпоінту або шляху до файлу з доступом до логів через HTTP. Потрібен прямий доступ до файлової системи/лог-агрегатора або механізм отримання логів, вказаний користувачем.",
  "source": null,
  "variables": {},
  "steps": [],
  "concurrency": null,
  "notes": []
}
```

## Верифікація перед записом файлів `.spec.ts`

- Кожен запис має встановлений `status`.
- Кожен не-pending запис у `steps` посилається лише на ендпоінти,
  дійсно підтверджені через swagger/кодову базу/відповідь
  користувача (відповідає правилу «ніколи не вигадуй» з SKILL.md).
- Кожен `${плейсхолдер}`, використаний у `steps`/`cleanup`,
  оголошений у `variables` або отриманий через `capture` попереднього
  кроку.
- Кожен запис, чиї кроки створюють постійний ресурс, має
  непропущений ключ `cleanup` (заповнений, або порожній із записом
  у `notes`, що пояснює причину).
