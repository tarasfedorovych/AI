# QAPR-0001 - Automation Strategy

Test cases: c:\src\!QA pipeline\QAPR-0001\test-cases.md
Code review: not provided
Generated: 2026-08-31

---

## REQ-1: Preconditions: The application is available; the user is not authenticated; the registration page is accessible. If an already authenticated user opens the registration page, the user is redirected away from it.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-1.1 | Registration page is accessible to an unauthenticated visitor | UI | Expected result is "Registration page loads and is displayed" — verifiable only by reading rendered page content. |
| TC-REQ-1.2 | Authenticated user opening the registration page is redirected away from it | UI | Expected result checks a navigation outcome and that "the registration form is not displayed" — both rendered-content/navigation checks. |

---

## REQ-2a: Registration Field — Email (required, valid format and unique). Accepted format is the standard `local@domain` form, including subdomains and plus-addressing.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-2a.2 | Email field accepts a value in the standard local@domain format | UI | Both expected results are stated as "no format validation error is shown/displayed" — a rendered-content check, not a backend state. |

---

## REQ-2e: Registration Field — Security Answer (required when security questions are enabled; must be non-empty after trim, maximum 128 characters, compared case-sensitively, with no other format restriction).

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-2e.2 | Security Answer field accepts exactly 128 characters (maximum boundary) | UI | Expected results are "no length validation error is shown/displayed" — verifiable only by reading the form's rendered validation state. |
| TC-REQ-2e.3 | Security Answer field rejects a value exceeding 128 characters | UI | Expected result is "Validation error is displayed for Security Answer" — rendered UI content. |
| TC-REQ-2e.4 | Security Answer comparison is case-sensitive | API | Expected result is stated as a data-match outcome ("does not match" / "matches ... verification succeeds"), not as a displayed message, so by the letter of the text this is a backend comparison. Verification mechanism was ambiguous (not named in the requirement); user confirmed API classification. |
| TC-REQ-2e.5 | Security Answer field accepts special characters and numbers with no additional format restriction | UI | Expected results are "no format validation error is shown" / "No validation error is displayed" — rendered form state. |

---

## REQ-3: REG-001: The system shall allow an unauthenticated visitor to open the registration form. An authenticated user is redirected away from it per REQ-1.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-3.1 | Unauthenticated visitor can view and interact with all registration fields | UI | Every expected result is a visibility/interactability check ("Field is visible and accepts input", "a question can be selected") — inherently rendered-page verification. |

---

## REQ-4: REG-002: The system shall require all mandatory registration fields. All mandatory fields are trimmed before the required-field check, so a whitespace-only value counts as empty and fails validation.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-4.1 | Submitting with Email, Password, or Confirm Password left completely empty displays a validation error for that field | UI | Each expected result is "Validation error is displayed for the [field]" — rendered content. |
| TC-REQ-4.2 | Submitting with a mandatory field containing only whitespace displays a validation error (whitespace-only treated as empty) | UI | Expected result is "Validation error is displayed for the Email field" — rendered content. |

---

## REQ-5: REG-003: The system shall validate the email format against the standard `local@domain` form, accepting subdomains and plus-addressing.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-5.1 | Email field accepts an address containing a subdomain | UI | Expected result is "No email-format validation error is displayed" — rendered form state. |
| TC-REQ-5.2 | Email field accepts a plus-addressed value | UI | Expected result is "No email-format validation error is displayed" — rendered form state. |
| TC-REQ-5.3 | Email field rejects a value that does not conform to the standard format | UI | Expected result is "Validation error is displayed for the Email field indicating an invalid format" — rendered content. |

---

## REQ-6: REG-004: The system shall not allow two accounts with the same email address. Emails are normalized by trimming whitespace and lowercasing before the uniqueness comparison. Uniqueness is enforced at persistence level (e.g. a database unique constraint), not only by a pre-check lookup; if two submissions race, exactly one succeeds and the other receives the generic registration failure message defined in REQ-14.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-6.1 | Registering with an email identical to an existing account's email is rejected | API | Expected result is "Registration is rejected; no new account is created" — a backend account-existence/count state, with no rendered message referenced. |
| TC-REQ-6.2 | Registering with an email differing only by leading/trailing whitespace from an existing account's email is rejected | API | Same wording pattern — "Registration is rejected; no new account is created for this submission" is a backend state check. |
| TC-REQ-6.3 | Registering with an email differing only by letter case from an existing account's email is rejected | API | Same — backend account-creation state, no display verified. |
| TC-REQ-6.4 | Concurrent registration submissions for the same normalized email — exactly one succeeds | API | Test data explicitly specifies the mechanism as "two parallel HTTP requests", and the expected result ("exactly one submission succeeds and creates one account") is a backend/database state plus a response-message check — all confirmable via API responses. |

---

## REQ-7: REG-005: The system shall validate the password against the configured password policy: minimum 8 and maximum 128 characters.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-7.1 | Password field accepts exactly 8 characters (minimum boundary) | UI | Expected result "No password-length validation error is displayed" is a rendered form check. |
| TC-REQ-7.2 | Password field rejects a value of 7 characters (below minimum) | UI | Expected result "Validation error is displayed indicating the password does not meet the minimum length" — rendered content. |
| TC-REQ-7.3 | Password field accepts exactly 128 characters (maximum boundary) | UI | Same pattern — "No password-length validation error is displayed". |
| TC-REQ-7.4 | Password field rejects a value of 129 characters (above maximum) | UI | Expected result "Validation error is displayed indicating the password exceeds the maximum length" — rendered content. |

---

## REQ-8: REG-006: Confirm Password shall exactly match Password.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-8.1 | Confirm Password identical to Password passes validation | UI | Expected result "No mismatch validation error is displayed for Confirm Password" — rendered form state. |
| TC-REQ-8.2 | Confirm Password different from Password displays a mismatch validation error | UI | Expected result "Validation error is displayed for Confirm Password" — rendered content. |

---

## REQ-9: REG-007: If security questions are enabled, the user shall provide the required question and answer.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-9.1 | Submitting without selecting a Security Question displays a validation error | UI | Expected result "Validation error is displayed for the Security Question field" — rendered content. |
| TC-REQ-9.2 | Submitting without a Security Answer displays a validation error | UI | Expected result "Validation error is displayed for the Security Answer field" — rendered content. |

---

## REQ-10: REG-008: Registration data shall be validated by the server even when client-side validation exists.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-10.1 | Invalid registration data submitted directly to the server is still validated and rejected | API | Step explicitly bypasses the UI ("Send a registration request directly to the server-side registration endpoint, bypassing the UI/client-side validation"), and the expected result ("the response indicates a validation error; no account is created") is a response/backend-state check. |

---

## REQ-11: REG-009: Valid registration data shall create exactly one customer account. The account is immediately active on creation with the default role "customer"; no email verification or activation step is required.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-11.1 | Submitting valid registration data creates exactly one customer account | API | Expected result "Exactly one customer account is created" is a backend account-count state, verifiable independent of how the submission is rendered. |
| TC-REQ-11.2 | The newly created account has the default role "customer" | API | Step is "Inspect the created account's role" and expected result is a backend data field ("Account role is 'customer'") — no rendered content involved. |
| TC-REQ-11.3 | The newly created account is immediately active without email verification or activation | API | Expected result "Login succeeds; account is active immediately upon creation" is stated as an authentication/state outcome, confirmable via a login API response, with no rendered page content described. |

---

## REQ-12: REG-010: Invalid registration data shall not create an account.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-12.1 | Submitting invalid registration data does not create a customer account | API | Expected result "Registration fails; no customer account is created" is a backend account-existence state, with no display verified. |

---

## REQ-13a: REG-011: After successful registration, the user shall receive a clear success indication.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-13a.1 | Success indication is displayed after successful registration | UI | Expected result is explicitly "A success indication is displayed to the user" — rendered content. |

---

## REQ-13b: REG-011: After successful registration, the user shall be redirected to the login page; the user is not automatically logged in.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-13b.1 | After successful registration, the user is redirected to the login page | UI | Expected result "User is redirected to the login page" is a navigation/rendered-page outcome. |
| TC-REQ-13b.2 | After successful registration, the user is not automatically logged in | UI | Expected result includes "the login page requires the user to enter credentials" — a rendered-page state, in addition to the auth state. |

---

## REQ-14: REG-012: Validation failures shall display an appropriate error without exposing internal system details — no stack traces, raw database errors, or internal identifiers. A failure caused by an already-registered email shall show a generic failure message that does not reveal whether the email already exists.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-14.1 | A validation failure error contains no stack trace, raw database error, or internal identifier | UI | Expected result is "Error message displayed contains no stack trace..." — explicitly a displayed-message check. |
| TC-REQ-14.2 | A registration failure caused by an already-registered email displays a generic failure message | UI | Expected result "A generic registration failure message is displayed" — rendered content. |

---

## REQ-15: BR-REG-001: Email addresses must be unique after normalization, where normalization is defined as trimming whitespace and lowercasing before the uniqueness comparison (same single rule as REQ-6).

No test cases in this requirement group — it restates the uniqueness rule already covered by REQ-6 (TC-REQ-6.1 – TC-REQ-6.4), per the cross-reference note in test-cases.md.

---

## REQ-16: BR-REG-002: Passwords shall never be stored or logged in plaintext; they are hashed at rest, never written to logs, and never returned in any API response or error output.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-16.1 | Password value does not appear anywhere in application logs | API | Step is to "inspect the application logs" and the expected result is a backend/log-content state — no UI involved. |
| TC-REQ-16.2 | Password value is not returned in any API response, including error responses | API | Step explicitly says "inspect the response bodies" and the expected result concerns API response content directly. |
| TC-REQ-16.3 | Password is stored at rest in hashed form, not in plaintext | API | Step is to "inspect the stored account record at rest" — a database/backend-state check. |

---

## REQ-17: BR-REG-003: Credentials shall be transmitted securely in non-development environments.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-17.1 | Registration data, including Password, is transmitted over a secure connection | Manual / Not automatable | Verification requires capturing and inspecting network traffic ("browser dev tools / proxy") for TLS/HTTPS usage — a transport-layer check that fits neither a rendered-UI assertion nor a simple response-body/status inspection as defined by the API criteria, and is typically verified as environment/infrastructure configuration rather than scripted per test case. User confirmed Manual classification. |

---

## REQ-18: BR-REG-004: Repeated submission shall not create duplicate accounts. This covers double-click, page refresh / POST resubmission, and back-button resubmission, and is guaranteed by the same persistence-level uniqueness enforcement as REQ-6.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-18.1 | Double-clicking the submit action creates only one account | UI | The step is specifically "double-click the submit action" — a literal browser gesture only exercisable through actual UI interaction (not a direct request), and the interaction sequence itself is part of what's being verified. |
| TC-REQ-18.2 | Refreshing the page after a registration POST submission does not create a duplicate account | UI | The mechanism is explicitly "Refresh the page to trigger a resubmission" — a browser-level action requiring an actual page/browser session, distinct from a direct API request. |
| TC-REQ-18.3 | Using the browser back button after successful registration and resubmitting does not create a duplicate account | UI | The step explicitly uses "the browser back button" to return to the form and resubmit — a browser-navigation gesture only exercisable via UI automation. |
| TC-REQ-18.4 | A repeat submission that does not create an account displays the generic registration failure message | UI | Expected result is "The generic registration failure message... is displayed" — rendered content. |

---

## REQ-19: BR-REG-005: User input shall be handled safely and shall not allow script or query injection. Dangerous input is safely escaped on output wherever registration data (email, security answer) is later displayed, rather than rejected outright, unless it also violates the field's own format rule.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-19.1 | A Security Answer containing script/HTML markup is accepted and safely escaped wherever later displayed | UI | Step 2 requires viewing "the Security Answer value wherever it is later displayed" and checking it "is displayed as literal text (escaped); the script does not execute" — a rendered-content check that makes UI the overall (stricter) classification, even though step 1's acceptance is separately API-checkable. |
| TC-REQ-19.2 | A Security Answer containing SQL-like syntax is accepted and does not cause a database error | API | Expected result "Registration completes without a database error... the value is stored as literal data" is a backend/database state, with no rendered content referenced. |
| TC-REQ-19.3 | An Email containing script/HTML-like characters that violates the email format rule is rejected | UI | Expected result "Validation error is displayed for the Email field indicating an invalid format" — rendered content. |

---

## REQ-20: Important Edge Cases (for grooming/test design coverage): empty mandatory fields; invalid email format; existing email; existing email with different letter case; leading/trailing whitespace in email; password below or above allowed length; password and confirmation mismatch; missing security question/answer when required; very long input; Unicode and special-character input; HTML/JavaScript-like or SQL-like input; multiple rapid submissions; network or backend failure during registration. Explicit maximum lengths apply — email 255, password 128, security answer 128 — and over-limit input is rejected with a validation error, never silently truncated. Unicode letters are accepted in password and security answer; email must still conform to the standard format rule in REQ-5; characters that do not break a field's own format are accepted and safely escaped on output per REQ-19. Multiple rapid submissions concern duplicate-account prevention (covered by REQ-6 and REQ-18), not rate limiting.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-20.1 | Email field accepts exactly 255 characters (maximum boundary) | UI | Expected result "No email-length validation error is displayed" — rendered form state. |
| TC-REQ-20.2 | Email field rejects a value exceeding 255 characters, displaying a validation error rather than truncating | UI | Expected result "Validation error is displayed indicating the email exceeds the maximum length... not silently truncated" — rendered content. |
| TC-REQ-20.3 | Password field accepts a value containing Unicode letters | UI | Expected result "Value is accepted, no validation error is displayed" — rendered form state. |
| TC-REQ-20.4 | Security Answer field accepts a value containing Unicode letters | UI | Same pattern — "Value is accepted, no validation error is displayed". |

---

## REQ-21: AC-REG-001 (Successful Registration): Given a visitor provides a unique valid email and valid mandatory data, when registration is submitted, then exactly one account is created and registration success is shown.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-21.1 | End-to-end successful registration creates one account and shows success | UI | Step 2's expected result "Registration success indication is displayed" is rendered content, making UI the overall classification even though step 1's account-creation count is separately API-checkable. |

---

## REQ-22: AC-REG-002 (Duplicate Email): Given an account already exists for the email, when the visitor registers with the same normalized email, then registration fails, no additional account is created, and the error shown is generic and does not reveal that the email is already registered.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-22.1 | Registering with an already-registered normalized email fails with a generic message and no additional account | UI | Expected result explicitly references "the displayed failure message" being generic — a rendered-content check, making UI the overall classification even though the no-additional-account part is separately API-checkable. |

---

## REQ-23: AC-REG-003 (Invalid Input): Given one or more mandatory values are missing or invalid, when registration is submitted, then registration fails, all validation errors for the currently-invalid fields are displayed together (not only the first), and no account is created.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-23.1 | Submitting with one or more mandatory values missing or invalid fails and creates no account | API | Expected result "Registration fails; no account is created" is a backend state with no displayed content referenced. |
| TC-REQ-23.2 | Multiple invalid fields at once display validation errors for all of them together | UI | Expected result "Validation errors are displayed for all currently-invalid fields at once" — explicitly rendered content. |

---

## REQ-24: AC-REG-004 (Password Mismatch): Given Password and Confirm Password differ, when registration is submitted, then registration fails and the mismatch is communicated to the user.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-24.1 | Password/Confirm Password mismatch causes registration to fail with the mismatch communicated | UI | Expected result "the mismatch... is communicated to the user" mirrors the explicitly displayed validation message in TC-REQ-8.2, i.e. rendered content. |

---

## REQ-25: AC-REG-005 (Backend Failure): Given valid registration data and account creation fails on the backend, when registration is submitted, then the user receives a controlled error and no partially usable account remains — no user record persists after the failed write, and the same email can be retried afterward.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-25.1 | Backend write failure during registration produces a controlled error, not a raw system error | API | The scenario is driven by a backend fault-injection mechanism and the expected result concerns an error's content/type ("no raw system or server error... is shown"), naturally checked via the response body/status. Reference to a "default server error page" was flagged as ambiguous; user confirmed API classification (verify via response body/status). |
| TC-REQ-25.2 | No user record persists after a failed backend write during registration | API | Step is to "inspect the system for a user record" — a backend/database state check. |
| TC-REQ-25.3 | The same email can be retried after a failed backend write | API | Expected result "Registration succeeds; an account is created using that email" is a backend account-creation state, with no display referenced. |

---

## Statistics

| Recommendation | Count |
|-----------------|-------|
| API | 18 |
| UI | 39 |
| Manual / Not automatable | 1 |
| Total | 58 |
