import { test, expect } from '@playwright/test';
import { LoginPage } from '../../ui-framework/pages/LoginPage';

// REQ-4: LOGIN-002 — the system requires email and password.

const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data]
const VALID_EMAIL = 'registered.user@example.com'; // [test data]

// TC-REQ-4.1
test('TC-REQ-4.1: Submitting with Email or Password left completely empty does not authenticate', async ({ page }) => {
  const loginPage = new LoginPage(page);

  await test.step('Leave Email empty, fill Password with a value', async () => {
    await loginPage.goto();
    await loginPage.fillPassword(VALID_PASSWORD);
    await loginPage.touchField(loginPage.emailInput);
  });

  await test.step('Verify a validation error is displayed for the missing Email', async () => {
    await expect(
      loginPage.emailRequiredError,
      'expected a required-field validation error for Email'
    ).toBeVisible();
  });

  await test.step('Fill Email with a value, leave Password empty', async () => {
    await loginPage.goto();
    await loginPage.fillEmail(VALID_EMAIL);
    await loginPage.touchField(loginPage.passwordInput);
  });

  await test.step('Verify a validation error is displayed for the missing Password', async () => {
    await expect(
      loginPage.passwordRequiredError,
      'expected a required-field validation error for Password'
    ).toBeVisible();
  });
});

// TC-REQ-4.2
test('TC-REQ-4.2: Submitting with a mandatory field containing only whitespace is treated as empty', async ({ page }) => {
  const loginPage = new LoginPage(page);

  await test.step('Enter a whitespace-only value in the Email field, fill Password with a value, submit', async () => {
    await loginPage.goto();
    await loginPage.fillEmail('   '); // [test data, 3 spaces]
    await loginPage.fillPassword(VALID_PASSWORD);
    await loginPage.loginButton.click();
  });

  await test.step('Verify login does not succeed as if a real Email value were provided', async () => {
    // Discovery note: login.component.ts's emailControl uses only
    // Validators.required (value == null || value.length === 0), which a
    // 3-space string does NOT trigger — the Login button is not disabled
    // either (login.component.html checks the raw truthy value, and "   "
    // is truthy). So the whitespace-only value is submitted to the server
    // like any other value and rejected the same generic way as a
    // non-matching credential, rather than being blocked as "required" —
    // this still satisfies the test case's own flexible wording ("treated
    // as empty or as a non-matching value, not as valid input").
    await expect(
      loginPage.invalidCredentialsError,
      'expected the whitespace-only Email to be rejected the same generic way as a non-matching credential, not accepted as valid input'
    ).toBeVisible();
  });
});
