# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: registration-page-access.spec.ts >> TC-REQ-1.2: Authenticated user opening the registration page is redirected away from it
- Location: registration-page-access.spec.ts:28:5

# Error details

```
Error: expected the app to redirect an authenticated user away from /#/register

expect(page).not.toHaveURL(expected) failed

Expected pattern: not /#\/register/
Received string: "http://localhost:3000/#/register"
Timeout: 5000ms

Call log:
  - expected the app to redirect an authenticated user away from /#/register with timeout 5000ms
    14 × locator resolved to <html lang="en" data-beasties-container="" class="fontawesome-i2svg-active fontawesome-i2svg-complete">…</html>
       - unexpected value "http://localhost:3000/#/register"

```

```yaml
- button "Open Sidenav"
- button "Back to homepage":
  - img "OWASP Juice Shop"
  - text: OWASP Juice Shop
- button "Open search"
- textbox
- button "Close search"
- button "Show/hide account menu": Account
- button "Show the shopping cart": Your Basket 0
- button "Language selection menu": EN
- heading "User Registration" [level=1]
- text: Email
- textbox "Email address field"
- text: Password
- textbox "Field for the password"
- emphasis: Password must be 5-40 characters long.
- text: 0/20 Repeat Password
- textbox "Field to confirm the password"
- text: 0/40
- switch "Show password advice"
- text: Show password advice Security Question
- combobox "Selection list for the security question"
- emphasis: This cannot be changed later!
- text: Answer
- textbox "Field for the answer to the security question":
  - /placeholder: Answer to your security question
- button "Button to complete the registration" [disabled]: Register
- link "Already a customer?":
  - /url: "#/login"
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import { RegistrationPage } from '../../ui-framework/pages/RegistrationPage';
  3  | import { LoginPage } from '../../ui-framework/pages/LoginPage';
  4  | 
  5  | const NEW_ACCOUNT_PASSWORD = 'Str0ngP@ssw0rd!'; // [test data] valid mandatory data
  6  | 
  7  | function uniqueEmail(label: string) {
  8  |   return `ui-${label}-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per run
  9  | }
  10 | 
  11 | // TC-REQ-1.1
  12 | test('TC-REQ-1.1: Registration page is accessible to an unauthenticated visitor', async ({ page }) => {
  13 |   const registrationPage = new RegistrationPage(page);
  14 | 
  15 |   await test.step('Navigate to the registration page', async () => {
  16 |     await registrationPage.goto();
  17 |   });
  18 | 
  19 |   await test.step('Verify the registration page loads and is displayed', async () => {
  20 |     await expect(
  21 |       registrationPage.emailInput,
  22 |       'expected the registration form (Email field) to be visible for an unauthenticated visitor'
  23 |     ).toBeVisible();
  24 |   });
  25 | });
  26 | 
  27 | // TC-REQ-1.2
  28 | test('TC-REQ-1.2: Authenticated user opening the registration page is redirected away from it', async ({ page }) => {
  29 |   const registrationPage = new RegistrationPage(page);
  30 |   const loginPage = new LoginPage(page);
  31 |   const email = uniqueEmail('auth-redirect');
  32 |   let userId: number | undefined;
  33 | 
  34 |   await test.step('Precondition: register and log in as a new user', async () => {
  35 |     userId = await registrationPage.registerNewAccount({
  36 |       email,
  37 |       password: NEW_ACCOUNT_PASSWORD,
  38 |       securityAnswer: 'TestAnswer123', // [test data]
  39 |     });
  40 |     await loginPage.goto();
  41 |     await loginPage.login(email, NEW_ACCOUNT_PASSWORD);
  42 |   });
  43 | 
  44 |   try {
  45 |     await test.step('While authenticated, navigate to the registration page URL', async () => {
  46 |       await registrationPage.goto();
  47 |     });
  48 | 
  49 |     await test.step('Verify the user is redirected away and the registration form is not displayed', async () => {
  50 |       await expect(
  51 |         page,
  52 |         'expected the app to redirect an authenticated user away from /#/register'
> 53 |       ).not.toHaveURL(/#\/register/);
     |             ^ Error: expected the app to redirect an authenticated user away from /#/register
  54 |       await expect(
  55 |         registrationPage.emailInput,
  56 |         'expected the registration form not to be displayed to an authenticated user'
  57 |       ).not.toBeVisible();
  58 |     });
  59 |   } finally {
  60 |     if (userId) {
  61 |       await page.request.delete(`/api/Users/${userId}`);
  62 |     }
  63 |   }
  64 | });
  65 | 
```