import { test, expect } from '@playwright/test';
import { attachExchange, uniqueEmail } from './helpers';

// REQ-22: AC-LOGIN-001 (Successful Login) — given an eligible registered
// customer exists, submitting the correct email and password authenticates
// successfully and establishes a valid session for the correct customer.
// End-to-end acceptance test combining registration, login, and identity
// verification via GET /rest/user/whoami.

const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data]

// TC-REQ-22.1
test('TC-REQ-22.1: End-to-end successful login authenticates and establishes a session for the correct customer', async ({ request }, testInfo) => {
  const email = uniqueEmail('e2e-successful-login');

  await test.step('Given an eligible registered customer exists', async () => {
    const registerBody = { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD };
    const response = await request.post('/api/Users', { data: registerBody });
    const body = await attachExchange(testInfo, 'given: register eligible customer', { method: 'POST', url: '/api/Users', body: registerBody }, response);
    expect(response.status(), `expected 201 Created, got ${response.status()} - ${JSON.stringify(body)}`).toBe(201);
  });

  let token!: string;
  await test.step('When the customer submits the correct email and password', async () => {
    const loginBody = { email, password: VALID_PASSWORD };
    const response = await request.post('/rest/user/login', { data: loginBody });
    const body = await attachExchange(testInfo, 'when: submit correct credentials', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);
    // Then authentication succeeds
    expect(response.status(), `expected 200 OK, got ${response.status()} - ${JSON.stringify(body)}`).toBe(200);
    expect(body.authentication?.token, `expected a session token, got ${JSON.stringify(body)}`).toBeTruthy();
    token = body.authentication.token;
  });

  await test.step('And a valid session is established for the correct customer', async () => {
    const response = await request.get('/rest/user/whoami', { headers: { Cookie: `token=${token}` } });
    const body = await attachExchange(testInfo, 'and: session identifies the correct customer', { method: 'GET', url: '/rest/user/whoami', headers: { Cookie: 'token=<redacted>' } }, response);
    expect(response.status(), `expected 200 OK, got ${response.status()}`).toBe(200);
    expect(body.user?.email, `expected the session to identify ${email}, got ${JSON.stringify(body)}`).toBe(email);
  });
});
