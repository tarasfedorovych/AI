import { test, expect } from '@playwright/test';
import { LoginPage } from '../../ui-framework/pages/LoginPage';

// REQ-5: LOGIN-003 — the password field shall obscure its value by
// default. login.component.ts's `hide` flag defaults to true, and
// login.component.html binds the input's [type] to `hide ? 'password' :
// 'text'` — confirmed in the codebase.

// TC-REQ-5.1
test('TC-REQ-5.1: Password field masks its entered value by default', async ({ page }) => {
  const loginPage = new LoginPage(page);
  await loginPage.goto();

  await test.step('Enter a value into the Password field', async () => {
    await loginPage.fillPassword('Str0ngP@ssw0rd!'); // [test data]
  });

  await test.step('Verify the entered characters are rendered obscured by default', async () => {
    await expect(
      loginPage.passwordInput,
      'expected the Password field to render as type="password" (masked) by default'
    ).toHaveAttribute('type', 'password');
  });
});
