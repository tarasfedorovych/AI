import { test, expect } from '@playwright/test';
import { RegistrationPage } from '../../ui-framework/pages/RegistrationPage';

const VALID_PASSWORD = 'Str0ngP@ssw0rd!'; // [test data] valid mandatory data
const VALID_SECURITY_ANSWER = 'TestAnswer123'; // [test data] valid mandatory data
const VALID_EMAIL = 'validator@example.com'; // [test data] valid mandatory data

// TC-REQ-4.1
test('TC-REQ-4.1: Submitting with Email, Password, or Confirm Password left completely empty displays a validation error for that field', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);

  await test.step('Leave Email empty, fill the remaining mandatory fields with valid data', async () => {
    await registrationPage.goto();
    await registrationPage.fillPassword(VALID_PASSWORD);
    await registrationPage.fillRepeatPassword(VALID_PASSWORD);
    await registrationPage.selectFirstSecurityQuestion();
    await registrationPage.fillSecurityAnswer(VALID_SECURITY_ANSWER);
    await registrationPage.touchField(registrationPage.emailInput);
  });

  await test.step('Verify a validation error is displayed for the Email field indicating it is required', async () => {
    await expect(
      registrationPage.emailRequiredError,
      'expected a required-field validation error for Email'
    ).toBeVisible();
  });

  await test.step('Fill Email with valid data, leave Password empty, fill the remaining fields with valid data', async () => {
    await registrationPage.goto();
    await registrationPage.fillEmail(VALID_EMAIL);
    await registrationPage.selectFirstSecurityQuestion();
    await registrationPage.fillSecurityAnswer(VALID_SECURITY_ANSWER);
    await registrationPage.touchField(registrationPage.passwordInput);
  });

  await test.step('Verify a validation error is displayed for the Password field indicating it is required', async () => {
    await expect(
      registrationPage.passwordRequiredError,
      'expected a required-field validation error for Password'
    ).toBeVisible();
  });

  await test.step('Fill Email and Password with valid data, leave Confirm Password empty, fill the remaining fields with valid data', async () => {
    await registrationPage.goto();
    await registrationPage.fillEmail(VALID_EMAIL);
    await registrationPage.fillPassword(VALID_PASSWORD);
    await registrationPage.selectFirstSecurityQuestion();
    await registrationPage.fillSecurityAnswer(VALID_SECURITY_ANSWER);
    await registrationPage.touchField(registrationPage.repeatPasswordInput);
  });

  await test.step('Verify a validation error is displayed for the Confirm Password field indicating it is required', async () => {
    await expect(
      registrationPage.repeatPasswordRequiredError,
      'expected a required-field validation error for Confirm Password'
    ).toBeVisible();
  });
});

// TC-REQ-4.2
test('TC-REQ-4.2: Submitting with a mandatory field containing only whitespace displays a validation error (whitespace-only treated as empty)', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);

  await test.step('Enter a whitespace-only value in the Email field, fill the remaining mandatory fields with valid data', async () => {
    await registrationPage.goto();
    await registrationPage.fillEmail('   '); // [test data, 3 spaces]
    await registrationPage.fillPassword(VALID_PASSWORD);
    await registrationPage.fillRepeatPassword(VALID_PASSWORD);
    await registrationPage.selectFirstSecurityQuestion();
    await registrationPage.fillSecurityAnswer(VALID_SECURITY_ANSWER);
    await registrationPage.touchField(registrationPage.emailInput);
  });

  await test.step('Verify a validation error is displayed for the Email field indicating it is required (whitespace-only value is treated as empty)', async () => {
    await expect(
      registrationPage.emailRequiredError,
      'expected a required-field validation error for Email, since a whitespace-only value must be treated as empty per REQ-4'
    ).toBeVisible();
  });
});
