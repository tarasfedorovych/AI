import { test, expect } from '@playwright/test';
import { attachExchange, uniqueEmail } from './helpers';

// REQ-6: LOGIN-004 — the system authenticates a user when valid credentials
// for an eligible account are provided. Endpoints: POST /api/Users
// (registration, to create the eligible account) and POST /rest/user/login
// (swagger.yml: LoginCredentials -> AuthenticationResponse).
//
// No cleanup endpoint is available (see summary.md — DELETE /api/Users/:id
// is security.denyAll() in this codebase, confirmed by reading server.ts and
// empirically), so a fresh unique email is used per test instead of a
// shared literal or any reliance on removing what was created.

const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data] valid mandatory data

// TC-REQ-6.1
test('TC-REQ-6.1: Valid credentials for an existing account authenticate successfully', async ({ request }, testInfo) => {
  const email = uniqueEmail('valid-login');

  // Arrange — precondition: a registered account exists with this email/password
  const registerBody = { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD };
  const registerResponse = await request.post('/api/Users', { data: registerBody });
  const registerRespBody = await attachExchange(testInfo, 'arrange: register account', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
  expect(registerResponse.status(), `expected 201 Created for the arrange-step registration, got ${registerResponse.status()} - ${JSON.stringify(registerRespBody)}`).toBe(201);

  // Act — enter the account's email and password, submit
  const loginBody = { email, password: VALID_PASSWORD };
  const loginResponse = await request.post('/rest/user/login', { data: loginBody });
  const loginRespBody = await attachExchange(testInfo, 'act: login with valid credentials', { method: 'POST', url: '/rest/user/login', body: loginBody }, loginResponse);

  // Assert — authentication succeeds
  expect(loginResponse.status(), `expected 200 OK on valid login, got ${loginResponse.status()} - ${JSON.stringify(loginRespBody)}`).toBe(200);
  expect(loginRespBody.authentication?.token, `expected an authentication token in the response, got ${JSON.stringify(loginRespBody)}`).toBeTruthy();
});
