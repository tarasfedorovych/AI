# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: login-edge-cases.spec.ts >> TC-REQ-21.1: Login with the registered email in a different letter case authenticates the same as the original case
- Location: login-edge-cases.spec.ts:11:5

# Error details

```
Error: expected 200 (case-insensitive email match) — got 401 - Invalid email or password. (known gap: routes/login.ts's raw SQL email lookup is case-sensitive, no normalization)

expect(received).toBe(expected) // Object.is equality

Expected: 200
Received: 401
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import { attachExchange, uniqueEmail } from './helpers';
  3  | 
  4  | // REQ-21: Important edge cases — letter case, whitespace padding, very long
  5  | // input, and Unicode/special-character input in the login Email field.
  6  | // Endpoints: POST /api/Users (arrange), POST /rest/user/login (act).
  7  | 
  8  | const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data]
  9  | 
  10 | // TC-REQ-21.1
  11 | test('TC-REQ-21.1: Login with the registered email in a different letter case authenticates the same as the original case', async ({ request }, testInfo) => {
  12 |   const email = uniqueEmail('case-sensitivity'); // registered in lowercase
  13 | 
  14 |   const registerBody = { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD };
  15 |   const registerResponse = await request.post('/api/Users', { data: registerBody });
  16 |   const registerRespBody = await attachExchange(testInfo, 'arrange: register account (lowercase email)', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
  17 |   expect(registerResponse.status(), `expected 201 Created, got ${registerResponse.status()} - ${JSON.stringify(registerRespBody)}`).toBe(201);
  18 | 
  19 |   // Act — submit login with the registered email in all-uppercase
  20 |   const loginBody = { email: email.toUpperCase(), password: VALID_PASSWORD };
  21 |   const response = await request.post('/rest/user/login', { data: loginBody });
  22 |   const bodyText = await response.text();
  23 |   await attachExchange(testInfo, 'login with uppercase email', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);
  24 | 
  25 |   // GENUINE FINDING, confirmed by running this test: routes/login.ts's raw
  26 |   // SQL lookup compares `email = '<value>'` with no case normalization, so
  27 |   // the uppercased email does not match the stored (as-registered) row —
  28 |   // login is rejected (401) instead of succeeding. This test case assumes
  29 |   // login should behave case-insensitively on email, a reasonable reading
  30 |   // of the source document's edge-case list, which the implementation does
  31 |   // not satisfy. The assertion is left as written (expecting success)
  32 |   // rather than weakened.
> 33 |   expect(response.status(), `expected 200 (case-insensitive email match) — got ${response.status()} - ${bodyText} (known gap: routes/login.ts's raw SQL email lookup is case-sensitive, no normalization)`).toBe(200);
     |                                                                                                                                                                                                             ^ Error: expected 200 (case-insensitive email match) — got 401 - Invalid email or password. (known gap: routes/login.ts's raw SQL email lookup is case-sensitive, no normalization)
  34 | });
  35 | 
  36 | // TC-REQ-21.2
  37 | test('TC-REQ-21.2: Login with the registered email padded with leading/trailing whitespace is handled consistently', async ({ request }, testInfo) => {
  38 |   const email = uniqueEmail('whitespace-padding');
  39 | 
  40 |   const registerBody = { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD };
  41 |   const registerResponse = await request.post('/api/Users', { data: registerBody });
  42 |   const registerRespBody = await attachExchange(testInfo, 'arrange: register account', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
  43 |   expect(registerResponse.status(), `expected 201 Created, got ${registerResponse.status()} - ${JSON.stringify(registerRespBody)}`).toBe(201);
  44 | 
  45 |   // Act — submit login with the email padded with leading/trailing whitespace
  46 |   const loginBody = { email: `  ${email}  `, password: VALID_PASSWORD };
  47 |   const response = await request.post('/rest/user/login', { data: loginBody });
  48 |   const bodyText = await response.text();
  49 |   await attachExchange(testInfo, 'login with whitespace-padded email', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);
  50 | 
  51 |   // Confirmed by running: the implementation rejects (401) rather than
  52 |   // trimming — one of the two flexible outcomes this test case allows, so
  53 |   // this assertion passes. Either way, no crash may occur.
  54 |   expect([200, 401].includes(response.status()), `expected either 200 (trimmed and matched) or 401 (rejected generically), got ${response.status()} - ${bodyText}`).toBe(true);
  55 |   expect(response.status(), 'expected no unhandled server error (5xx)').toBeLessThan(500);
  56 | });
  57 | 
  58 | // TC-REQ-21.3
  59 | test('TC-REQ-21.3: Very long input in Email or Password does not cause a crash or unhandled server error', async ({ request }, testInfo) => {
  60 |   const longEmail = `${'a'.repeat(10000)}@example.com`; // [test data, 10,000-character local part]
  61 | 
  62 |   const loginBody = { email: longEmail, password: 'anyPassword1' };
  63 |   const response = await request.post('/rest/user/login', { data: loginBody });
  64 |   const bodyText = await response.text();
  65 |   await attachExchange(testInfo, 'login with a very long email', { method: 'POST', url: '/rest/user/login', body: { email: `[10000 chars]@example.com`, password: loginBody.password } }, response);
  66 | 
  67 |   expect(response.status(), `expected 401 (rejected in a controlled way), got ${response.status()} - ${bodyText.slice(0, 200)}`).toBe(401);
  68 | });
  69 | 
  70 | // TC-REQ-21.4
  71 | test('TC-REQ-21.4: Unicode/special-character input in Email or Password does not cause a crash and is rejected generically', async ({ request }, testInfo) => {
  72 |   const unicodeEmail = 'пошта@example.com'; // [test data]
  73 | 
  74 |   const loginBody = { email: unicodeEmail, password: 'anyPassword1' };
  75 |   const response = await request.post('/rest/user/login', { data: loginBody });
  76 |   const bodyText = await response.text();
  77 |   await attachExchange(testInfo, 'login with a Unicode email', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);
  78 | 
  79 |   expect(response.status(), `expected 401 (rejected the same generic way as any other non-matching credential), got ${response.status()} - ${bodyText}`).toBe(401);
  80 | });
  81 | 
```