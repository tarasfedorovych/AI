---
name: task-context
description: >
  Collects task data from tracker, matches information
  from all fields (description, comments, attachments, acceptance criteria, etc.),
  and forms a unified enriched Markdown context — source of truth
  for subsequent skills. Use when user gives URL or task key
  and wants to get processed context, or says "extract
  context from tracker", "prepare task context", "process ticket".
---

# Task Context

> ⚠️ **CONFIGURE:** edit trigger phrases in `description` (frontmatter above) —
> replace "extract context from tracker" and other phrases with those
> used by your team.

> ⚙️ Recommended settings: **Sonnet · Effort: Medium · Extended thinking: Off**

**MANDATORY before starting work** — output a message to the user
and stop. Do not perform any actions until the user confirms:

⚙️ Switch settings for this skill:
- **Model:** Sonnet
- **Effort:** Medium
- **Extended thinking:** Off

Confirm when ready.

Collects task data from tracker, matches information
from all fields, and forms a unified enriched Markdown context — source of truth
for subsequent skills in the chain.

## Input Data

From the user, need:
1. URL or task key in the tracker

> ⚠️ **CONFIGURE:** specify the task key format in your tracker.
> For example: `PROJ-1234` for Jira, `#1234` for GitHub Issues,
> `ENG-123` for Linear, etc.

## Rules

- All communication with user and all handoff content — in English.
- Chat messages — brief. Do not paste raw tracker responses.
- Do not clarify or groom requirements. This skill only collects
  and structures tracker data as is. Output file — source of truth
  for all subsequent skills in the chain.
- Ask user only about operational blockers: unavailable
  attachments, read errors.
- Concise bullets, no filler.

## Tracker Access

> ⚠️ **CONFIGURE:** describe how the skill accesses your tracker.
>
> Examples:
> - **Jira Cloud** → Atlassian MCP: use getJiraIssue
>   with specific field list and responseContentFormat: "markdown"
> - **Linear** → Linear MCP: use appropriate tools
> - **GitHub Issues** → gh CLI: `gh issue view <number> --json title,body,comments,labels`
> - **Azure DevOps** → appropriate MCP or REST API
> - **No integration** → user copies task description to chat manually
>
> Mandatory rule: if integration is unavailable —
> stop and inform the user. Do not use workarounds
> (browser, internet search) as a replacement.

### Effective Usage

> ⚠️ **CONFIGURE:** describe optimal way to query your tracker.
> Goal: do not load full payloads, but request
> only necessary fields. Specify exact commands or
> MCP tools for your tracker.

### Recommended Flow

> ⚠️ **CONFIGURE:** describe the step-by-step flow for retrieving data
> from your tracker. For example:
> 1. Parse URL → extract task key
> 2. Get task data with required fields
> 3. If first method fails — fallback
> 4. Related tasks — read for context, but process
>    only data for current task

## Task Types and Fields

> ⚠️ **CONFIGURE:** specify which task types are used
> in your project (e.g.: Story, Task, Bug, Epic, Subtask)
> and how to identify type from tracker response.

1. Determine task type from tracker response.
2. Load field map for this type from references/field-maps.md.
3. Read only fields listed in the map. Ignore other fields.
4. Do not reopen field maps every time —
   they are fixed for your project.

## Empty Fields

Mandatory field to process — task description
(according to references/field-maps.md).

> ⚠️ **CONFIGURE:** specify which field is mandatory for each
> task type. For example:
> - Story/Task: description
> - Bug: steps to reproduce or bug description

If mandatory field is empty or missing — stop
and inform user that there is nothing to process, need
to add description to the ticket.

All other fields — optional. Collect everything that is filled,
skip empty fields. Complete field list for each task type
is in references/field-maps.md.

## Attachments

> ⚠️ **CONFIGURE:** describe how your tracker/MCP returns attachments.
> Some MCPs return only metadata (name, type, size)
> without the file itself — then you need to ask the user
> to upload files to chat. Some give direct access to files.

Flow:
1. Collect list of attachments from task metadata.
2. Determine supported for processing:
   - images: png, jpg, jpeg, gif, webp
   - markdown: md, markdown
   - PDF: pdf
3. If supported attachments exist — ask user to
   upload them to chat for processing.
4. After receiving files — extract information
   and add to appropriate context sections.
5. Video (mp4, mov, webm, avi, mkv) — Claude cannot
   view. Record in context as available
   but not processed.
6. If user skips upload — record
   attachments in context as available but not processed.

## Data Collection and Matching

This step is performed after receiving all data:
fields, comments, and attachments from the user.

Match data between each other and form a unified enriched context.

Principle:
- Go through all filled task fields.
- Compare data across fields: comments may supplement
  description, attachments may detail steps, acceptance
  criteria may clarify requirements from description.
- If one field has detail missing from another —
  add it to the appropriate context section.
- If attachments (screenshots, mockups, md-files) provide
  specifics that expand description — integrate this information.
- Result: one file where everything is collected, deduplicated,
  and organized by sections. Not separate data from fields,
  but a coherent picture of the task.

Processing comments:
- Comments — same data source as description
  or acceptance criteria.
- If comment supplements or clarifies existing requirement —
  integrate into Requirements section.
- If comment describes issue not in requirements —
  add as additional requirement in section
  "Additional Requirements (from comments)" under main requirements.
- Everything else (bugs in existing requirements, test status,
  process discussion) — ignore.

Prohibitions — violation of any of these makes handoff unusable:
- Do not change essence, wording, or meaning of requirements.
- Do not change validation rules, validation messages,
  validation trigger conditions.
- Do not simplify or generalize specific values: numbers,
  limits, ranges, sizes, thresholds, units.
- Do not replace exact names, labels, copy, statuses, states,
  roles, permissions with generic wording.
- Do not skip before/after values when changing — keep
  both sides.
- Do not assume, make logical conclusions, do not add
  information not in any task field.
- Do not combine different requirements into one if in tracker
  they are described separately.
- Do not change conditional logic: keep all condition branches
  (if/then/else) as in tracker.
- Do not break links between requirements: if one
  requirement depends on another (field on state, action on condition,
  rule on role) — keep this link in one place.

## Verification Before Saving

Before saving, go through each filled field
from references/field-maps.md list and verify:

- Does each fact, requirement, and detail from this field
  end up in the appropriate context section?
- Did nothing get skipped because it seemed
  familiar, repeated, or unimportant?

If missing information is found — add it
to the appropriate section before saving.

## Output File

Create the folder <ISSUEKEY>/ in the working directory if it does not
exist, then create file context.md inside it, and provide it to the
user for download.

The file remains in <ISSUEKEY>/ — the next skill in the same chat
takes it automatically.

If the file already exists — delete it completely and create a new one.
Always output one file with results from the latest run.
Do not merge with the previous version, do not append, do not preserve
data from the previous record.

Before finishing, verify:
- One top-level heading
- One coherent handoff without duplicate sections
- All prohibitions from "Data Collection and Matching" are followed
- Do not create sections that are not in references/output-template.md
- Do not include estimation, story points, sprint, assignee,
  work dates or other project management data

File structure template is in references/output-template.md.

## Final Response

After saving the file, inform:
- Path to the saved file
- If anything was skipped (user skipped attachments,
  field was unavailable) — briefly remind what exactly
  did not make it into context.
