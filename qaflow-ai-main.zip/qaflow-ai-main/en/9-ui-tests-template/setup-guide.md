# UI Tests Setup Guide

This skill needs no tracker or VCS authentication of its own — it does
not talk to your issue tracker or your PR host. It reads the test-cases
and automation-strategy files produced earlier in the pipeline, and
optionally reads a frontend codebase folder and/or a running app URL.

## Input Modes

Pick whichever applies to your situation:

1. **Frontend codebase folder** — point the skill at your app's
   frontend root (or a subfolder). It reads component/template markup
   for accessible roles, labels, and any existing `data-testid`
   convention, and detects an existing Playwright config or POM layer
   to match.
2. **Running app URL** — give a base URL. The skill runs a one-shot
   headless discovery script against the pages your selected test
   cases need and reads back an ARIA snapshot, instead of driving a
   browser interactively step by step (cheaper, and reviewable as a
   file).
3. **Neither** — the skill will ask you, per test case, for the page
   URL/navigation path and how to identify each field/button it needs.
   It never invents these.

You can combine a codebase folder and a running app URL; the codebase
is also used to detect an existing Playwright/POM setup to reuse
(base URL, auth fixtures) regardless of which discovery source covers
a given page.

## The Shared Page Object Folder

Page Objects this skill creates or extends live in `ui-framework/pages/` at
the root of your working directory — **not** inside any `<ISSUEKEY>/`
folder. This is intentional: the value of a POM layer is reuse across
tickets against the same app, so a later run (different ticket, same
app) should find and extend an existing Page Object instead of
regenerating it. Don't delete this folder between runs, and don't treat
it as issue-specific scratch output. It's deliberately named
`ui-framework/`, not `ui-tests/`, so it doesn't read as just another
`<ISSUEKEY>/ui-tests/` output folder next to all the per-issue ones.

If your working directory structure keeps issue folders somewhere other
than the working directory root, tell the skill where the shared
`ui-framework/pages/` folder should live (or already lives) so it can find
it consistently across runs.

## What to Configure

If your team always uses the same selector convention (e.g. every
interactive element carries a `data-testid`, or you want `getByTestId`
to outrank `getByRole` for your app specifically), you can note that in
`references/playwright-ui-conventions.md` under "Selector Strategy" so
it's applied by default. This is optional — the documented priority
order (role → label/placeholder → text → test id → CSS/XPath) matches
general Playwright best practice and needs no changes to work.

## Skill Files

```
9-ui-tests-template/
  SKILL.md                              — Agent definition
  setup-guide.md                        — This guide
  references/
    output-template.md                  — Output structure (spec files + summary.md)
    playwright-ui-conventions.md        — POM conventions, selectors, discovery script, config
    ui-mapping-schema.md                — Mapping schema
```

## Next Steps

1. Run this skill after automation-strategy (it will pause at the
   Selection Checkpoint to let you pick which UI-classified test cases
   to generate this run — expect this, it's deliberate).
2. Review the generated `.spec.ts` files and `summary.md` in
   `<ISSUEKEY>/ui-tests/`, and the Page Objects under `ui-framework/pages/`.
3. Answer any pending clarifications listed in summary.md, then re-run
   to generate the remaining tests.
4. Install browsers once per machine: `npx playwright install
   chromium`.
5. Run `npx playwright test` per the instructions in summary.md, then
   `npx playwright show-report` to review results — trace/screenshot/
   video are attached automatically for any failure.
