import { test, expect } from '@playwright/test';
import { RegistrationPage } from '../../ui-framework/pages/RegistrationPage';

const VALID_PASSWORD = 'Str0ngP@ssw0rd!'; // [test data] valid mandatory data
const VALID_SECURITY_ANSWER = 'TestAnswer123'; // [test data] valid mandatory data

// TC-REQ-5.1
test('TC-REQ-5.1: Email field accepts an address containing a subdomain', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);
  const email = `user-${Date.now()}@mail.example.com`; // [test data] unique per run, contains a subdomain
  let userId: number | undefined;

  await test.step('Enter an email address containing a subdomain in the Email field, submit with the remaining mandatory fields valid', async () => {
    await registrationPage.goto();
    await registrationPage.fillEmail(email);
    await registrationPage.fillPassword(VALID_PASSWORD);
    await registrationPage.fillRepeatPassword(VALID_PASSWORD);
    await registrationPage.selectFirstSecurityQuestion();
    await registrationPage.fillSecurityAnswer(VALID_SECURITY_ANSWER);
    userId = await registrationPage.submitAndCaptureCreatedUserId();
  });

  try {
    await test.step('Verify no email-format validation error is displayed', async () => {
      await expect(
        registrationPage.emailInvalidFormatError,
        'expected no email-format validation error for a subdomain address'
      ).not.toBeVisible();
    });
  } finally {
    if (userId) {
      await page.request.delete(`/api/Users/${userId}`);
    }
  }
});

// TC-REQ-5.2
test('TC-REQ-5.2: Email field accepts a plus-addressed value', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);
  const email = `user+tag-${Date.now()}@example.com`; // [test data] unique per run, plus-addressed
  let userId: number | undefined;

  await test.step('Enter a plus-addressed email value in the Email field, submit with the remaining mandatory fields valid', async () => {
    await registrationPage.goto();
    await registrationPage.fillEmail(email);
    await registrationPage.fillPassword(VALID_PASSWORD);
    await registrationPage.fillRepeatPassword(VALID_PASSWORD);
    await registrationPage.selectFirstSecurityQuestion();
    await registrationPage.fillSecurityAnswer(VALID_SECURITY_ANSWER);
    userId = await registrationPage.submitAndCaptureCreatedUserId();
  });

  try {
    await test.step('Verify no email-format validation error is displayed', async () => {
      await expect(
        registrationPage.emailInvalidFormatError,
        'expected no email-format validation error for a plus-addressed value'
      ).not.toBeVisible();
    });
  } finally {
    if (userId) {
      await page.request.delete(`/api/Users/${userId}`);
    }
  }
});

// TC-REQ-5.3
test('TC-REQ-5.3: Email field rejects a value that does not conform to the standard format', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);

  await test.step('Enter a value that does not conform to the standard local@domain format in the Email field', async () => {
    await registrationPage.goto();
    await registrationPage.fillEmail('userexample.com'); // [test data, missing @]
    await registrationPage.touchField(registrationPage.emailInput);
  });

  await test.step('Verify a validation error is displayed for the Email field indicating an invalid format', async () => {
    await expect(
      registrationPage.emailInvalidFormatError,
      'expected an email-format validation error for a value missing "@"'
    ).toBeVisible();
  });
});
