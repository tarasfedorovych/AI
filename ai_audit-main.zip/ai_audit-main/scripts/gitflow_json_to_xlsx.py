#!/usr/bin/env python3
"""
gitflow_json_to_xlsx.py
Convert a gitflow audit JSON report into a comprehensive XLSX report with charts.

Usage:
  python gitflow_json_to_xlsx.py gitflow.audit.json gitflow.audit.xlsx

Requires:
  pip install openpyxl
"""
from __future__ import annotations
import json
import sys
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, PieChart, Reference


# Color schemes
COLORS = {
    "critical": "DC3545",  # Red
    "high": "FD7E14",      # Orange
    "medium": "FFC107",    # Yellow
    "low": "28A745",       # Green
    "info": "17A2B8",      # Blue
    "header": "343A40",    # Dark gray
    "subheader": "6C757D", # Medium gray
    "light": "F8F9FA",     # Light gray
}


def setup_column_widths(ws, widths):
    """Set column widths for a worksheet."""
    for col_idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(col_idx)].width = width


def add_header_row(ws, row_idx, values, bg_color=COLORS["header"]):
    """Add a styled header row."""
    for col_idx, value in enumerate(values, start=1):
        cell = ws.cell(row=row_idx, column=col_idx, value=value)
        cell.font = Font(bold=True, color="FFFFFF", size=11)
        cell.fill = PatternFill(start_color=bg_color, end_color=bg_color, fill_type="solid")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(
            left=Side(style="thin"),
            right=Side(style="thin"),
            top=Side(style="thin"),
            bottom=Side(style="thin"),
        )


def add_data_row(ws, row_idx, values, bg_color=None, bold=False):
    """Add a data row with optional background color."""
    for col_idx, value in enumerate(values, start=1):
        cell = ws.cell(row=row_idx, column=col_idx, value=value)
        cell.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
        cell.border = Border(
            left=Side(style="thin"),
            right=Side(style="thin"),
            top=Side(style="thin"),
            bottom=Side(style="thin"),
        )
        if bold:
            cell.font = Font(bold=True)
        if bg_color:
            cell.fill = PatternFill(start_color=bg_color, end_color=bg_color, fill_type="solid")


def add_title_row(ws, row_idx, title, cols_to_merge):
    """Add a title row spanning multiple columns."""
    ws.merge_cells(f"A{row_idx}:{get_column_letter(cols_to_merge)}{row_idx}")
    title_cell = ws[f"A{row_idx}"]
    title_cell.value = title
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color=COLORS["header"], end_color=COLORS["header"], fill_type="solid")
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[row_idx].height = 30


def add_section_header(ws, row_idx, title, cols_to_merge):
    """Add a section header."""
    ws.merge_cells(f"A{row_idx}:{get_column_letter(cols_to_merge)}{row_idx}")
    cell = ws[f"A{row_idx}"]
    cell.value = title
    cell.font = Font(bold=True, size=14)
    cell.fill = PatternFill(start_color=COLORS["light"], end_color=COLORS["light"], fill_type="solid")
    cell.alignment = Alignment(horizontal="left", vertical="center")


def create_summary_sheet(wb, data):
    """Create executive summary sheet."""
    ws = wb.active
    ws.title = "Executive Summary"
    setup_column_widths(ws, [25, 20, 60])

    row = 1
    add_title_row(ws, row, "Git Workflow Audit Report - Executive Summary", 3)
    row += 2

    # Meta information
    meta = data.get("meta", {})
    target = meta.get("target", {})
    
    ws[f"A{row}"] = "Report ID:"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = meta.get("report_id", "N/A")
    ws.merge_cells(f"B{row}:C{row}")
    row += 1

    ws[f"A{row}"] = "Generated:"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = meta.get("generated_at", "N/A")
    ws.merge_cells(f"B{row}:C{row}")
    row += 1

    ws[f"A{row}"] = "Repository:"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = target.get("repo", "N/A")
    ws.merge_cells(f"B{row}:C{row}")
    row += 1

    ws[f"A{row}"] = "Branch:"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = target.get("ref_id", "N/A")
    ws.merge_cells(f"B{row}:C{row}")
    row += 1

    analysis_period = meta.get("analysis_period", {})
    ws[f"A{row}"] = "Commits Analyzed:"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = analysis_period.get("commits_analyzed", 0)
    ws.merge_cells(f"B{row}:C{row}")
    row += 2

    # Overall score and risk
    exec_sum = data.get("executive_summary", {})
    
    ws[f"A{row}"] = "OVERALL SCORE"
    ws[f"A{row}"].font = Font(bold=True, size=14)
    ws[f"B{row}"] = exec_sum.get("overall_score", 0)
    ws[f"B{row}"].font = Font(bold=True, size=24, color=COLORS["header"])
    ws[f"B{row}"].alignment = Alignment(horizontal="center", vertical="center")
    row += 1

    ws[f"A{row}"] = "RISK LEVEL"
    ws[f"A{row}"].font = Font(bold=True, size=14)
    risk_level = exec_sum.get("risk_level", "unknown").upper()
    ws[f"B{row}"] = risk_level
    risk_color = COLORS.get(risk_level.lower(), COLORS["info"])
    ws[f"B{row}"].font = Font(bold=True, size=18, color=risk_color)
    ws[f"B{row}"].alignment = Alignment(horizontal="center", vertical="center")
    row += 2

    # Headline
    ws[f"A{row}"] = "Summary:"
    ws[f"A{row}"].font = Font(bold=True)
    row += 1
    ws.merge_cells(f"A{row}:C{row}")
    ws[f"A{row}"] = exec_sum.get("headline", "")
    ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[row].height = 60
    row += 2

    # Strengths
    highlights = exec_sum.get("highlights", {})
    add_section_header(ws, row, "STRENGTHS", 3)
    row += 1
    
    for strength in highlights.get("strengths", []):
        ws[f"A{row}"] = "✓"
        ws[f"A{row}"].font = Font(color=COLORS["low"], size=14, bold=True)
        ws.merge_cells(f"B{row}:C{row}")
        ws[f"B{row}"] = strength
        ws[f"B{row}"].alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[row].height = 30
        row += 1
    
    row += 1
    
    # Top Risks
    add_section_header(ws, row, "TOP RISKS", 3)
    row += 1
    
    for risk in highlights.get("top_risks", []):
        ws[f"A{row}"] = "⚠"
        ws[f"A{row}"].font = Font(color=COLORS["high"], size=14, bold=True)
        ws.merge_cells(f"B{row}:C{row}")
        ws[f"B{row}"] = risk
        ws[f"B{row}"].alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[row].height = 30
        row += 1
    
    row += 1
    
    # Quick Wins
    add_section_header(ws, row, "QUICK WINS", 3)
    row += 1
    
    for win in highlights.get("quick_wins", []):
        ws[f"A{row}"] = "→"
        ws[f"A{row}"].font = Font(color=COLORS["info"], size=14, bold=True)
        ws.merge_cells(f"B{row}:C{row}")
        ws[f"B{row}"] = win
        ws[f"B{row}"].alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[row].height = 30
        row += 1


def create_scorecard_sheet(wb, data):
    """Create scorecard sheet with area scores."""
    ws = wb.create_sheet("Scorecard")
    setup_column_widths(ws, [25, 12, 12, 60])

    row = 1
    add_title_row(ws, row, "Quality Scorecard by Area", 4)
    row += 2

    add_header_row(ws, row, ["Area", "Score", "Risk Level", "Rationale"])
    row += 1

    scorecard = data.get("scorecard", [])
    for area in scorecard:
        area_name = area.get("area_name", "Unknown")
        score = area.get("score", 0)
        risk_level = area.get("risk_level", "unknown").upper()
        rationale = area.get("rationale", "")
        
        risk_color = COLORS.get(risk_level.lower(), COLORS["light"])
        add_data_row(ws, row, [area_name, score, risk_level, rationale], bg_color=risk_color)
        ws.row_dimensions[row].height = 40
        row += 1

    # Add chart
    if scorecard:
        chart = BarChart()
        chart.type = "col"
        chart.title = "Quality Scores by Area"
        chart.y_axis.title = "Score (0-100)"
        chart.x_axis.title = "Quality Area"
        
        # Data references
        data_ref = Reference(ws, min_col=2, min_row=3, max_row=3 + len(scorecard) - 1)
        cats_ref = Reference(ws, min_col=1, min_row=4, max_row=3 + len(scorecard))
        
        chart.add_data(data_ref, titles_from_data=False)
        chart.set_categories(cats_ref)
        chart.height = 10
        chart.width = 20
        
        ws.add_chart(chart, f"A{row + 2}")


def create_findings_sheet(wb, data):
    """Create detailed findings sheet."""
    ws = wb.create_sheet("Findings")
    setup_column_widths(ws, [8, 40, 12, 12, 12, 50, 50, 8, 8])

    row = 1
    add_title_row(ws, row, "Detailed Findings", 9)
    row += 2

    add_header_row(ws, row, ["ID", "Title", "Severity", "Area", "Risk", "Issue", "Impact", "Effort", "Priority"])
    row += 1

    findings = data.get("findings", [])
    for finding in findings:
        finding_id = finding.get("id", "")
        title = finding.get("title", "")
        severity = finding.get("severity", "").upper()
        area_id = finding.get("area_id", "")
        risk_level = finding.get("risk_level", "").upper()
        issue = finding.get("issue", "")
        impact = finding.get("impact", "")
        effort = finding.get("effort", "")
        priority = finding.get("priority_rank", "")
        
        severity_color = COLORS.get(severity.lower(), COLORS["light"])
        add_data_row(ws, row, [finding_id, title, severity, area_id, risk_level, issue, impact, effort, priority], 
                     bg_color=severity_color)
        ws.row_dimensions[row].height = 50
        row += 1


def create_findings_detail_sheet(wb, data):
    """Create detailed findings with recommendations."""
    ws = wb.create_sheet("Findings Detail")
    setup_column_widths(ws, [80])

    row = 1
    add_title_row(ws, row, "Findings with Recommendations", 1)
    row += 2

    findings = data.get("findings", [])
    for i, finding in enumerate(findings, 1):
        # Finding header
        ws[f"A{row}"] = f"{finding.get('id', '')} - {finding.get('title', '')}"
        ws[f"A{row}"].font = Font(bold=True, size=14)
        severity_color = COLORS.get(finding.get("severity", "info").lower(), COLORS["light"])
        ws[f"A{row}"].fill = PatternFill(start_color=severity_color, end_color=severity_color, fill_type="solid")
        row += 1

        # Metadata
        ws[f"A{row}"] = f"Severity: {finding.get('severity', '').upper()} | Risk: {finding.get('risk_level', '').upper()} | Effort: {finding.get('effort', '')} | Priority: {finding.get('priority_rank', '')}"
        ws[f"A{row}"].font = Font(bold=True)
        row += 1

        # Issue
        ws[f"A{row}"] = "ISSUE:"
        ws[f"A{row}"].font = Font(bold=True)
        row += 1
        ws[f"A{row}"] = finding.get("issue", "")
        ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[row].height = 40
        row += 1

        # Impact
        ws[f"A{row}"] = "IMPACT:"
        ws[f"A{row}"].font = Font(bold=True)
        row += 1
        ws[f"A{row}"] = finding.get("impact", "")
        ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[row].height = 40
        row += 1

        # Evidence
        evidence = finding.get("evidence", [])
        if evidence:
            ws[f"A{row}"] = "EVIDENCE:"
            ws[f"A{row}"].font = Font(bold=True)
            row += 1
            for ev in evidence:
                context = ev.get("context", "")
                ws[f"A{row}"] = f"• {context}"
                ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top", indent=1)
                ws.row_dimensions[row].height = 30
                row += 1

        # Recommendation
        ws[f"A{row}"] = "RECOMMENDATION:"
        ws[f"A{row}"].font = Font(bold=True)
        row += 1
        ws[f"A{row}"] = finding.get("recommendation", "")
        ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")
        ws[f"A{row}"].fill = PatternFill(start_color=COLORS["light"], end_color=COLORS["light"], fill_type="solid")
        ws.row_dimensions[row].height = 60
        row += 2


def create_commit_analysis_sheet(wb, data):
    """Create commit analysis sheet."""
    ws = wb.create_sheet("Commit Analysis")
    setup_column_widths(ws, [30, 50])

    row = 1
    add_title_row(ws, row, "Commit History Analysis", 2)
    row += 2

    commit_data = data.get("commit_analysis", {})
    
    ws[f"A{row}"] = "Total Commits"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = commit_data.get("total_commits", 0)
    ws[f"B{row}"].font = Font(size=14, bold=True)
    row += 2

    # Message compliance
    compliance = commit_data.get("commit_message_compliance", {})
    ws[f"A{row}"] = "Convention Detected"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = compliance.get("convention_detected", "N/A")
    row += 1

    ws[f"A{row}"] = "Compliant Commits %"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = f"{compliance.get('compliant_commits_percentage', 0)}%"
    row += 2

    # Common prefixes
    ws[f"A{row}"] = "Common Commit Prefixes"
    ws[f"A{row}"].font = Font(bold=True)
    row += 1
    for prefix in compliance.get("common_prefixes", [])[:10]:
        ws[f"B{row}"] = prefix
        row += 1
    row += 1

    # Issues found
    ws[f"A{row}"] = "Issues Found"
    ws[f"A{row}"].font = Font(bold=True)
    row += 1
    for issue in compliance.get("issues_found", []):
        ws[f"B{row}"] = f"• {issue}"
        ws[f"B{row}"].alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[row].height = 25
        row += 1
    row += 2

    # Size distribution
    size_dist = commit_data.get("commit_size_distribution", {})
    ws[f"A{row}"] = "Commit Size Distribution"
    ws[f"A{row}"].font = Font(bold=True, size=12)
    row += 1

    add_header_row(ws, row, ["Size Category", "Count / Percentage"])
    row += 1

    for size_cat in ["small", "medium", "large", "mega"]:
        cat_data = size_dist.get(size_cat, {})
        count = cat_data.get("count", 0)
        pct = cat_data.get("percentage", 0)
        add_data_row(ws, row, [size_cat.upper(), f"{count} ({pct}%)"])
        row += 1


def create_branching_sheet(wb, data):
    """Create branching analysis sheet."""
    ws = wb.create_sheet("Branching")
    setup_column_widths(ws, [30, 50])

    row = 1
    add_title_row(ws, row, "Branching Strategy Analysis", 2)
    row += 2

    branch_data = data.get("branching_analysis", {})
    
    ws[f"A{row}"] = "Branching Model"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = branch_data.get("branching_model", "N/A")
    ws[f"B{row}"].alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[row].height = 30
    row += 1

    ws[f"A{row}"] = "Confidence"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = branch_data.get("confidence", "N/A").upper()
    row += 2

    # Statistics
    stats = branch_data.get("branch_statistics", {})
    ws[f"A{row}"] = "Branch Statistics"
    ws[f"A{row}"].font = Font(bold=True, size=12)
    row += 1

    add_header_row(ws, row, ["Metric", "Value"])
    row += 1

    stats_items = [
        ("Total Branches", stats.get("total_branches", 0)),
        ("Active Branches", stats.get("active_branches", 0)),
        ("Stale Branches", stats.get("stale_branches", 0)),
    ]

    for label, value in stats_items:
        add_data_row(ws, row, [label, value])
        row += 1
    row += 1

    # Naming convention
    naming = branch_data.get("naming_convention", {})
    ws[f"A{row}"] = "Naming Convention"
    ws[f"A{row}"].font = Font(bold=True, size=12)
    row += 1

    ws[f"A{row}"] = "Has Convention"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = "Yes" if naming.get("has_convention") else "No"
    row += 1

    ws[f"A{row}"] = "Pattern"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = naming.get("pattern", "N/A")
    ws[f"B{row}"].alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[row].height = 30
    row += 1

    ws[f"A{row}"] = "Compliance"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = f"{naming.get('compliance_percentage', 0)}%"
    row += 2

    # Non-compliant examples
    ws[f"A{row}"] = "Non-Compliant Examples"
    ws[f"A{row}"].font = Font(bold=True)
    row += 1
    for example in naming.get("non_compliant_examples", [])[:10]:
        ws[f"B{row}"] = example
        row += 1
    row += 1

    # Merge patterns
    merge = branch_data.get("merge_patterns", {})
    ws[f"A{row}"] = "Merge Patterns"
    ws[f"A{row}"].font = Font(bold=True, size=12)
    row += 1

    add_header_row(ws, row, ["Pattern Type", "Count"])
    row += 1

    merge_items = [
        ("Merge Commits", merge.get("merge_commits", 0)),
        ("Squash Merges", merge.get("squash_merges", 0)),
        ("Rebase Merges", merge.get("rebase_merges", 0)),
        ("Direct Commits to Main", merge.get("direct_commits_to_main", 0)),
    ]

    for label, value in merge_items:
        add_data_row(ws, row, [label, value])
        row += 1


def create_contributors_sheet(wb, data):
    """Create contributors analysis sheet."""
    ws = wb.create_sheet("Contributors")
    setup_column_widths(ws, [25, 12, 12, 12, 20, 20])

    row = 1
    add_title_row(ws, row, "Contributor Analysis", 6)
    row += 2

    contrib_data = data.get("contributor_analysis", {})
    
    ws[f"A{row}"] = "Total Contributors"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = contrib_data.get("total_contributors", 0)
    row += 1

    ws[f"A{row}"] = "Active Contributors (90 days)"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = contrib_data.get("active_contributors", 0)
    row += 2

    # Distribution
    dist = contrib_data.get("contribution_distribution", {})
    ws[f"A{row}"] = "Top Contributor %"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = f"{dist.get('top_contributor_percentage', 0)}%"
    row += 1

    ws[f"A{row}"] = "Top 3 Contributors %"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = f"{dist.get('top_3_contributors_percentage', 0)}%"
    row += 1

    ws[f"A{row}"] = "Bus Factor"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = dist.get("bus_factor", 0)
    bus_factor = dist.get("bus_factor", 0)
    if bus_factor <= 2:
        ws[f"B{row}"].font = Font(color=COLORS["critical"], bold=True)
    row += 2

    # Productivity metrics
    ws[f"A{row}"] = "Contributor Productivity"
    ws[f"A{row}"].font = Font(bold=True, size=12)
    row += 1

    add_header_row(ws, row, ["Contributor", "Commits", "Active Days", "Avg Commit Size", "First Commit", "Last Commit"])
    row += 1

    metrics = contrib_data.get("productivity_metrics", [])
    for metric in metrics:
        contributor = metric.get("contributor", "")
        commits = metric.get("commits", 0)
        active_days = metric.get("active_days", 0)
        avg_size = metric.get("average_commit_size", 0)
        first = metric.get("first_commit_date", "")[:10] if metric.get("first_commit_date") else ""
        last = metric.get("last_commit_date", "")[:10] if metric.get("last_commit_date") else ""
        
        add_data_row(ws, row, [contributor, commits, active_days, avg_size, first, last])
        row += 1
    row += 2

    # Risk indicators
    risks = contrib_data.get("risk_indicators", [])
    if risks:
        ws.merge_cells(f"A{row}:F{row}")
        ws[f"A{row}"] = "Risk Indicators"
        ws[f"A{row}"].font = Font(bold=True, size=12)
        row += 1

        add_header_row(ws, row, ["Risk Type", "Severity", "Description", "", "", ""])
        ws.merge_cells(f"C{row}:F{row}")
        row += 1

        for risk in risks:
            risk_type = risk.get("risk_type", "")
            severity = risk.get("severity", "").upper()
            description = risk.get("description", "")
            
            severity_color = COLORS.get(severity.lower(), COLORS["light"])
            ws[f"A{row}"] = risk_type
            ws[f"B{row}"] = severity
            ws.merge_cells(f"C{row}:F{row}")
            ws[f"C{row}"] = description
            ws[f"C{row}"].alignment = Alignment(wrap_text=True, vertical="top")
            
            ws[f"B{row}"].fill = PatternFill(start_color=severity_color, end_color=severity_color, fill_type="solid")
            ws.row_dimensions[row].height = 40
            row += 1


def create_action_plan_sheet(wb, data):
    """Create action plan sheet."""
    ws = wb.create_sheet("Action Plan")
    setup_column_widths(ws, [8, 35, 50, 8])

    row = 1
    add_title_row(ws, row, "Prioritized Action Plan", 4)
    row += 2

    action_plan = data.get("action_plan", [])
    for action in action_plan:
        priority = action.get("priority", "")
        title = action.get("title", "")
        goal = action.get("goal", "")
        impact = action.get("expected_impact", "")
        
        # Action header
        ws[f"A{row}"] = f"#{priority}"
        ws[f"A{row}"].font = Font(bold=True, size=14)
        ws[f"A{row}"].alignment = Alignment(horizontal="center", vertical="center")
        
        ws.merge_cells(f"B{row}:D{row}")
        ws[f"B{row}"] = title
        ws[f"B{row}"].font = Font(bold=True, size=12)
        ws[f"B{row}"].fill = PatternFill(start_color=COLORS["subheader"], end_color=COLORS["subheader"], fill_type="solid")
        row += 1

        ws[f"A{row}"] = "Goal:"
        ws[f"A{row}"].font = Font(bold=True)
        ws.merge_cells(f"B{row}:D{row}")
        ws[f"B{row}"] = goal
        ws[f"B{row}"].alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[row].height = 30
        row += 1

        ws[f"A{row}"] = "Impact:"
        ws[f"A{row}"].font = Font(bold=True)
        ws.merge_cells(f"B{row}:D{row}")
        ws[f"B{row}"] = impact
        ws[f"B{row}"].alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[row].height = 30
        row += 1

        # Tasks
        ws[f"A{row}"] = "Tasks:"
        ws[f"A{row}"].font = Font(bold=True)
        row += 1

        tasks = action.get("tasks", [])
        for task in tasks:
            task_id = task.get("task_id", "")
            description = task.get("description", "")
            owner = task.get("owner_role", "")
            effort = task.get("effort_days", "")
            
            add_data_row(ws, row, [task_id, description, owner, f"{effort}d"], bold=False)
            ws[f"B{row}"].alignment = Alignment(wrap_text=True, vertical="top")
            ws.row_dimensions[row].height = 35
            row += 1
        
        row += 1


def main():
    """Main function."""
    if len(sys.argv) != 3:
        print("Usage: python gitflow_json_to_xlsx.py input.json output.xlsx")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    # Load JSON data
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception as e:
        print(f"Error loading JSON file: {e}")
        sys.exit(1)

    # Create workbook
    wb = Workbook()
    
    print("Creating summary sheet...")
    create_summary_sheet(wb, data)
    
    print("Creating scorecard sheet...")
    create_scorecard_sheet(wb, data)
    
    print("Creating findings sheet...")
    create_findings_sheet(wb, data)
    
    print("Creating findings detail sheet...")
    create_findings_detail_sheet(wb, data)
    
    print("Creating commit analysis sheet...")
    create_commit_analysis_sheet(wb, data)
    
    print("Creating branching sheet...")
    create_branching_sheet(wb, data)
    
    print("Creating contributors sheet...")
    create_contributors_sheet(wb, data)
    
    print("Creating action plan sheet...")
    create_action_plan_sheet(wb, data)

    # Save workbook
    try:
        wb.save(output_file)
        print(f"\n✓ Successfully created XLSX report: {output_file}")
    except Exception as e:
        print(f"Error saving XLSX file: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
