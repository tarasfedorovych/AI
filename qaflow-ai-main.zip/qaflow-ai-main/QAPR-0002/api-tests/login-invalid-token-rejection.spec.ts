import { test, expect } from '@playwright/test';
import { attachExchange, uniqueEmail } from './helpers';

// REQ-11: LOGIN-009 — expired or invalid sessions/tokens shall not provide
// authenticated access. Verified here via a malformed token value and a
// tampered (signature-broken) token value — true time-based expiry (the
// token is valid for 6h, per swagger.yml) is impractical to force in an
// automated test without a fast-forward/expiry-simulation mechanism, which
// was not found in the codebase; see requirements.md's REQ-11 assumption.

const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data]

// TC-REQ-11.1
test('TC-REQ-11.1: A malformed session/token value does not grant authenticated access', async ({ request }, testInfo) => {
  const malformedToken = 'not-a-real-token'; // [test data]

  const response = await request.get('/rest/user/whoami', { headers: { Cookie: `token=${malformedToken}` } });
  const body = await attachExchange(testInfo, 'whoami with a malformed token', { method: 'GET', url: '/rest/user/whoami', headers: { Cookie: `token=${malformedToken}` } }, response);

  expect(response.status(), `expected 200 (whoami never errors, it just returns an empty user when unauthenticated), got ${response.status()}`).toBe(200);
  expect(body.user, `expected an empty user object for a malformed token, got ${JSON.stringify(body)}`).toEqual({});
});

// TC-REQ-11.2
test('TC-REQ-11.2: A tampered session/token value does not grant authenticated access', async ({ request }, testInfo) => {
  const email = uniqueEmail('tampered-token');

  const registerBody = { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD };
  const registerResponse = await request.post('/api/Users', { data: registerBody });
  const registerRespBody = await attachExchange(testInfo, 'arrange: register account', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
  expect(registerResponse.status(), `expected 201 Created, got ${registerResponse.status()} - ${JSON.stringify(registerRespBody)}`).toBe(201);

  const loginBody = { email, password: VALID_PASSWORD };
  const loginResponse = await request.post('/rest/user/login', { data: loginBody });
  const loginRespBody = await attachExchange(testInfo, 'login', { method: 'POST', url: '/rest/user/login', body: loginBody }, loginResponse);
  expect(loginResponse.status(), `expected 200 OK, got ${loginResponse.status()} - ${JSON.stringify(loginRespBody)}`).toBe(200);

  // Act — alter one character of the valid token
  const validToken: string = loginRespBody.authentication.token;
  const tamperedToken = validToken.slice(0, -1) + (validToken.endsWith('A') ? 'B' : 'A');

  const whoamiResponse = await request.get('/rest/user/whoami', { headers: { Cookie: `token=${tamperedToken}` } });
  const whoamiRespBody = await attachExchange(testInfo, 'whoami with a tampered token', { method: 'GET', url: '/rest/user/whoami', headers: { Cookie: 'token=<tampered, redacted>' } }, whoamiResponse);

  // Assert — access is not granted
  expect(whoamiResponse.status(), `expected 200, got ${whoamiResponse.status()}`).toBe(200);
  expect(whoamiRespBody.user, `expected an empty user object for a tampered token (signature no longer verifies), got ${JSON.stringify(whoamiRespBody)}`).toEqual({});
});
