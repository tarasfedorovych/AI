# Field Maps

> ⚠️ **CONFIGURE:** this is a map of your project's fields in the tracker.
> For each task type, specify which fields to read.
>
> How to fill:
> 1. Determine what task types exist in your project
> 2. For each type, create a table of fields
> 3. "Value" — what this field means in human language
> 4. "Field Key" — technical key in your tracker
>    (for Jira this is customfield_XXXXX, for Linear — field name in API,
>    for GitHub — field from JSON response)
> 5. "Mandatory" — if field is empty, skill stops
>    and asks to fill it. At minimum,
>    field with task description must be mandatory.
>
> Below — template. Replace with your types and fields.

Fixed field maps for the project. Do not reopen
these maps every time — use as is.

## <Task Type 1, for example Story>

| Value | Field Key | Mandatory |
|---|---|---|
| Name | <key, for example summary> | — |
| Description | <key, for example description> | yes |
| <Your field, for example User Story> | <key> | no |
| <Your field, for example Acceptance Criteria> | <key> | no |
| <Your field, for example Notes for QA> | <key> | no |
| Comments | <key, for example comment> | no |
| Attachments | <key, for example attachment> | no |

## <Task Type 2, for example Task>

| Value | Field Key | Mandatory |
|---|---|---|
| Name | <key> | — |
| Description | <key> | yes |
| <Your field> | <key> | no |
| Comments | <key> | no |
| Attachments | <key> | no |

## <Task Type 3, for example Bug>

| Value | Field Key | Mandatory |
|---|---|---|
| Name | <key> | — |
| <Bug description, for example Bug Description> | <key> | yes |
| <Your field> | <key> | no |
| Comments | <key> | no |
| Attachments | <key> | no |
