import { test, expect } from '@playwright/test';
import { dismissOverlays } from '../../ui-framework/pages/dismissOverlays';

// REQ-26: AC-LOGIN-005 (Expired Session) — given the customer's session
// has expired, requesting authenticated functionality is rejected and the
// application follows its configured re-authentication behavior.
//
// Discovery note (adjusts requirements.md's REQ-26 assumption): the
// frontend's route guard for this kind of page — LoginGuard
// (frontend/src/app/app.guard.ts) — checks only whether
// localStorage.getItem('token') is truthy; it does not decode or validate
// the token itself. So an absent token (this test's practical stand-in for
// "expired", same rationale as TC-REQ-11.1/11.2's malformed/tampered
// tokens — see requirements.md's REQ-11 assumption) is what actually
// triggers the guard; the guard's own configured re-authentication
// behavior activates the 403 page's component via
// `router.navigate(['403'], { skipLocationChange: true, ... })` —
// confirmed live: the URL bar stays on '/#/address/saved' (skipLocationChange
// leaves the address bar untouched), but the rendered content becomes
// "403 Please login to view this page." This is a second, more precise
// discovery than the original requirements.md assumption ("returns the
// user to the login form" / a URL-level redirect) — the app's actual
// configured re-authentication behavior is an in-place 403 message, not a
// navigation back to /#/login. '/#/address/saved' (SavedAddressComponent)
// is one of the routes wired with `canActivate: [LoginGuard]`
// (app.routing.ts) — confirmed in the codebase. ErrorPageComponent's own
// template (error-page.component.html) renders "403" and the translated
// error message as two separate elements (a headline div and a
// `{{error}}` span), so the assertion below targets the message span's own
// text ("Please login to view this page.", the ErrorPageComponent's
// resolved translation of the 'UNAUTHORIZED_ACCESS_ERROR' key) rather than
// the combined "403 Please login..." string an ARIA snapshot's flattened
// text line might suggest is one node.

// TC-REQ-26.1
test('TC-REQ-26.1: Expired/invalid session rejects authenticated access and triggers the re-authentication flow', async ({ page }) => {
  await test.step('Given the customer\'s session has expired (practical stand-in: no valid token held by the browser)', async () => {
    await page.goto('/'); // establish an origin so localStorage is accessible before clearing it
    await dismissOverlays(page); // first-visit welcome dialog + cookie-consent banner, same as LoginPage/RegistrationPage.goto()
    await page.evaluate(() => localStorage.removeItem('token'));
  });

  await test.step('When authenticated functionality is requested', async () => {
    await page.goto('/#/address/saved');
    await dismissOverlays(page);
  });

  await test.step('Then authenticated access is rejected and the app follows its configured re-authentication behavior', async () => {
    await expect(
      page.getByText('Please login to view this page.'),
      'expected LoginGuard\'s configured re-authentication/rejection behavior (an in-place 403 message) for a session with no valid token'
    ).toBeVisible();
  });
});
