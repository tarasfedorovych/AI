import type { Page } from '@playwright/test';

// Juice Shop shows a first-visit welcome dialog and a cookie-consent
// banner on top of every page in a fresh browser context (confirmed via
// live ARIA-snapshot discovery); both must be cleared before any form
// interaction. Each test gets a fresh context, so this runs on every
// navigation, not just the first.
export async function dismissOverlays(page: Page): Promise<void> {
  try {
    await page.getByRole('button', { name: 'Close Welcome Banner' }).click({ timeout: 1500 });
  } catch {
    // not shown this run
  }
  try {
    await page.getByRole('button', { name: 'dismiss cookie message' }).click({ timeout: 1500 });
  } catch {
    // not shown this run
  }
}
