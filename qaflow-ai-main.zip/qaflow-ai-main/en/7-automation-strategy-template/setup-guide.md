# Automation Strategy Setup Guide

This skill needs no tracker or VCS access — it works entirely from the
test-cases file (and optionally the code-review file) already produced
earlier in the pipeline. There is nothing to authenticate or connect.

## What You Might Want to Adjust

The classification criteria and signal phrases (words like "verify ...
in the backend", "is displayed", "visually") live in `SKILL.md` under
"Classification Method". If your team's requirements use different
domain vocabulary for backend vs. UI behavior, you can extend the
signal-phrase lists there — this is optional and only worth doing if
you notice repeated misclassifications.

## Skill Files

```
7-automation-strategy-template/
  SKILL.md                              — Agent definition
  setup-guide.md                        — This guide
  references/
    output-template.md                  — Output file structure
    classification-examples.md          — Worked API/UI/Manual examples
```

## Next Steps

1. Run this skill after code-review (or right after qa-test-cases if
   you don't need PR-based prioritization).
2. Review the generated `<ISSUEKEY>/automation-strategy.md`.
3. Run the api-tests skill next to generate Playwright tests for every
   TC-REQ classified as API.
