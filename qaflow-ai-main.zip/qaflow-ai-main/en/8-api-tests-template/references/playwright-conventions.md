# Playwright Generation Conventions — reference

## Framework

Use only Playwright Test's native API testing features:

```ts
import { test, expect } from '@playwright/test';
```

Requests go through the built-in `request` fixture (an
`APIRequestContext`) that Playwright Test injects automatically —
never `supertest`, `axios`, `node-fetch`, or `fetch` directly.

## File Naming and Grouping

- One `.spec.ts` file per requirement group (the REQ heading in the
  test-cases file), not per TC-REQ item. Name the file after the
  feature/entity the REQ group covers, in kebab-case, e.g.
  `checkout-webhooks.spec.ts`, `subscription-cancellation.spec.ts`.
- If a REQ group has only one API-classified TC-REQ item, it still
  gets its own file — do not merge unrelated REQ groups into one
  "misc" or "other" file, since that breaks the 1:1 traceability from
  filename to requirement.
- Place all files directly under `<ISSUEKEY>/api-tests/` (or a `tests/`
  subfolder of it if the detected existing codebase convention uses
  one — match what was found, but never write outside
  `<ISSUEKEY>/api-tests/`).

## Test Structure

One `test()` per TC-REQ item. Every test takes `testInfo` as its
second parameter (needed for the attachments described in
"Traceability in Test Output" below):

```ts
// TC-REQ-6.1
test('TC-REQ-6.1: checkout.session.completed activates the subscription', async ({ request }, testInfo) => {
  // Arrange
  const payload = { /* from the test case's Test Data column */ };

  // Act
  const response = await request.post('/webhooks/stripe', { data: payload });
  const body = await attachExchange(testInfo, 'trigger webhook', { method: 'POST', url: '/webhooks/stripe', body: payload }, response);

  // Assert
  expect(response.ok(), `expected webhook to be accepted, got ${response.status()} - ${JSON.stringify(body)}`).toBeTruthy();
  expect(body.subscriptionStatus, `expected subscriptionStatus to be 'active', got response ${JSON.stringify(body)}`).toBe('active');
});
```

- Arrange/Act/Assert should mirror the test case's own Steps and
  Expected Result rows one-to-one where practical — do not add extra
  setup or assertions the test case doesn't describe.
- Use `expect(response.status()).toBe(<code>)` when the test case
  specifies an exact status code; use `expect(response.ok()).toBeTruthy()`
  when it only implies success/failure without a specific code.
- Use literal values from the test case exactly as written (status
  codes, field names, event type strings). For anything the test case
  marks `[test data]`, define a named constant at the top of the file
  instead of an inline magic value, e.g.:

```ts
const TEST_CARD_DECLINED = '4000000000000002'; // [test data] from requirements
```

## Traceability in Test Output

A generated test must be understandable from its own output — the
HTML report or terminal log — without opening the source file or
re-running it in a debugger. This is mandatory for every test, not an
optional polish pass. Two techniques, both required together:

### 1. Attach every request/response exchange

Right after each call through `request`, attach a JSON blob of what
was sent and what came back, via a shared helper placed once in
`<ISSUEKEY>/api-tests/helpers.ts` and imported by every spec file:

```ts
import type { APIRequestContext, APIResponse, TestInfo } from '@playwright/test';

export async function attachExchange(
  testInfo: TestInfo,
  label: string,
  requestInfo: { method: string; url: string; body?: unknown },
  response: APIResponse
): Promise<unknown> {
  const responseBody = await response.json().catch(() => response.text());
  await testInfo.attach(label, {
    body: JSON.stringify({ request: requestInfo, status: response.status(), response: responseBody }, null, 2),
    contentType: 'application/json',
  });
  return responseBody;
}
```

Call it once per request, with a short label describing that specific
call's intent (e.g. `'register (arrange)'`, `'duplicate registration attempt'`,
not a generic `'response'`). Use the value it returns as the parsed
body for subsequent assertions — do not call `.json()`/`.text()` again
separately on the same response; `attachExchange` already consumed it.

This makes the actual input parameters and the full response visible
as a viewable attachment in the HTML report for every test, whether it
passed or failed — directly addresses "what did we send" and "what did
we get back" without needing the source file open.

### 2. Every assertion carries a descriptive message

Never leave a bare `expect(response.ok()).toBeFalsy()` or
`expect(x).toBe(y)` with no message. Every `expect()` on a response or
a value derived from one must state what was expected and include the
actual observed value, so a failure is self-explanatory from the
message alone:

```ts
expect(response.status(), `expected 400 for missing password, got ${response.status()} - ${JSON.stringify(body)}`).toBe(400);
expect(response.ok(), `expected registration to be rejected as a duplicate, got ${response.status()} - ${JSON.stringify(body)}`).toBeFalsy();
```

Keep the message concise (expected vs. actual, not a restatement of
the whole test) — the attachment from technique 1 already carries the
full exchange; the message just needs to make a failing assertion
readable in a one-line test-runner summary too.

### 3. Group multi-step tests with `test.step`

For any test with more than one request (arrange + act, or a
multi-step chain from `api-mapping.json`), wrap each logical step in
`test.step('<intent>', async () => { ... })`. This makes the HTML
report's step list narrate the scenario on its own (e.g. "Arrange:
register existing account" → "Act: attempt duplicate registration" →
"Assert: rejected"), in addition to — not instead of — the attachments
and messages above.

## Config Detection and Scaffolding

- If a provided codebase has `playwright.config.ts`/`.js` with a
  `baseURL`, reuse it — write requests with relative paths
  (`request.post('/webhooks/stripe', ...)`), not a hardcoded host.
- If a provided codebase has existing auth fixtures (a custom
  `request` fixture, a `storageState`, a global-setup token), reuse
  the same pattern via import rather than re-deriving auth per test.
- If no codebase was provided, or none of the above was found, create
  a minimal `playwright.config.ts` inside `<ISSUEKEY>/api-tests/`,
  with the HTML reporter configured:

```ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: [['html', { open: 'never' }]],
  use: {
    baseURL: 'http://localhost:3000', // TODO: replace with the real API base URL
  },
});
```

`open: 'never'` keeps a plain `npm test` from trying to launch a
browser after the run — the person running it opens the report
explicitly via `npx playwright show-report` (see README.md template).

- If reusing an existing `playwright.config.ts` from a provided
  codebase that has no `reporter` set (or only `'list'`/`'dot'`), do
  not silently rely on the default — state plainly in `README.md` how
  to view results for a config you don't control: either the default
  terminal list, or `npx playwright test --reporter=html` to get a
  report for this run without editing the existing config.

## Cleanup

If `api-mapping.json` names a confirmed cleanup step for a test (a
delete/reset endpoint for data the test created), wrap everything
after the resource is created in `try { ... } finally { ... }`, with
the cleanup call in `finally` — never just appended after the last
assertion. A cleanup call placed after assertions is unreachable
exactly when an assertion throws, which is precisely when leftover
data is most likely (a failing/flaky run), defeating the point of
cleaning up at all. Confirmed empirically: an earlier version of this
convention (cleanup appended at the end, no `finally`) left orphaned
accounts in the target app's database the first time a generated
assertion legitimately failed.

```ts
// TC-REQ-11.1
test('TC-REQ-11.1: Submitting valid registration data creates exactly one customer account', async ({ request }, testInfo) => {
  const response = await request.post('/api/Users', { data: payload });
  const body = await attachExchange(testInfo, 'register', { method: 'POST', url: '/api/Users', body: payload }, response);
  expect(response.status(), `expected 201 Created, got ${response.status()} - ${JSON.stringify(body)}`).toBe(201);
  const userId = (body as any).data.id;

  try {
    expect(userId, `expected a created account id in the response, got ${JSON.stringify(body)}`).toBeTruthy();
  } finally {
    // Cleanup — remove the account created above (DELETE /api/Users/:id, confirmed available)
    await request.delete(`/api/Users/${userId}`);
  }
});
```

If a step whose result also needs cleanup happens *after* the first
assertion, capture that step's id before the assertion that might
throw, or open the `try` block immediately after the resource-creating
call, before any assertion runs against it — not just around the last
assertion.

Keep cleanup itself a plain, unasserted best-effort call (don't add
`expect()` around it, and don't let a cleanup failure mask the
original test failure — a bare `await request.delete(...)` inside
`finally` is enough; do not wrap it in its own try/catch). If the
mapping notes no cleanup mechanism was found, do not add one; leave
the test as-is (already covered as a pending item in summary.md if
relevant).

Never let one test's arrange step assume a resource created by
*another* test is already gone or already present — if two test cases
in the same file need the same precondition (e.g. "an account already
exists"), either give each its own uniquely-generated data, or clean
up after each test so the next one starts fresh. Do not rely on
test-execution order for correctness.

## Shared Setup

When the same multi-step setup sequence (e.g. register → fetch a
reference list → post a dependent record) is needed by more than one
test — whether in the same file or across files in this run — factor
it into a shared async helper function, either local to the file (as
in a single-file case) or in `helpers.ts` at the root of
`<ISSUEKEY>/api-tests/` when reused across multiple `.spec.ts` files —
the same file that holds `attachExchange` (see Traceability in Test
Output above). Import it rather than re-inlining the same steps. This
mirrors what `api-mapping.json` already captures once per logical
setup sequence — don't re-derive it per file.

## Anti-patterns

- Do not use any HTTP client other than Playwright's `request` fixture.
- Do not generate a test for a TC-REQ item with no discovered or
  confirmed endpoint — list it as pending clarification instead.
- Do not hardcode a full URL when a `baseURL` is configured.
- Do not combine unrelated REQ groups into one file.
- Do not add retries or timeouts not implied by the test case.
- Do not add cleanup that isn't a confirmed, discovered endpoint —
  but do not omit confirmed cleanup either (see Cleanup above).
- Do not leave any `expect()` on a response (or a value derived from
  one) without a descriptive message stating expected vs. actual.
- Do not skip attaching a request/response exchange for any call
  through `request` — a test with no attachments is not traceable.
