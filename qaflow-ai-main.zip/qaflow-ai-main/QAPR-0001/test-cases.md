# QAPR-0001 - Test Cases

Checklist: c:\src\!QA pipeline\QAPR-0001\checklist.md
Generated: 2026-08-31

---

## REQ-1: Preconditions: The application is available; the user is not authenticated; the registration page is accessible. If an already authenticated user opens the registration page, the user is redirected away from it.

Applied techniques: Use Case

### TC-REQ-1.1: Registration page is accessible to an unauthenticated visitor

**Precondition:** Application is available; user is not authenticated.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Navigate to the registration page URL | — | Registration page loads and is displayed |

### TC-REQ-1.2: Authenticated user opening the registration page is redirected away from it

**Precondition:** User is authenticated (logged in).

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | While authenticated, navigate to the registration page URL | — | User is redirected away from the registration page; the registration form is not displayed |

---

## REQ-2a: Registration Field — Email (required, valid format and unique). Accepted format is the standard `local@domain` form, including subdomains and plus-addressing.

Applied techniques: EP

### TC-REQ-2a.2: Email field accepts a value in the standard local@domain format

**Precondition:** Registration page is open; user is not authenticated.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a value in the standard local@domain format in the Email field | user@example.com [test data] | Value is accepted in the Email field, no format validation error is shown |
| 2 | Submit the form with the remaining mandatory fields filled with valid data | valid Password, Confirm Password, Security Question, Security Answer [test data] | No email-format validation error is displayed |

---

## REQ-2e: Registration Field — Security Answer (required when security questions are enabled; must be non-empty after trim, maximum 128 characters, compared case-sensitively, with no other format restriction).

Applied techniques: EP, BVA

### TC-REQ-2e.2: Security Answer field accepts exactly 128 characters (maximum boundary)

**Precondition:** Registration page is open; security questions are enabled.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a Security Answer value of exactly 128 characters | [test data, 128 characters, e.g. repeating "A"] | Value is accepted, no length validation error is shown for Security Answer |
| 2 | Submit the form with the remaining mandatory fields valid | [test data] | No validation error is displayed for Security Answer |

### TC-REQ-2e.3: Security Answer field rejects a value exceeding 128 characters

**Precondition:** Registration page is open; security questions are enabled.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a Security Answer value of 129 characters | [test data, 129 characters] | — |
| 2 | Submit the form | [test data] | Validation error is displayed for Security Answer indicating the maximum length (128 characters) is exceeded |

### TC-REQ-2e.4: Security Answer comparison is case-sensitive

**Precondition:** An account has been registered with Security Answer = "TestAnswer123" [test data].

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Provide the Security Answer with a different letter case via the system's security-answer verification mechanism [test data/environment-specific] | testanswer123 [test data] | Value does not match the stored Security Answer — verification fails |
| 2 | Provide the Security Answer in the original letter case via the same mechanism | TestAnswer123 [test data] | Value matches the stored Security Answer — verification succeeds |

### TC-REQ-2e.5: Security Answer field accepts special characters and numbers with no additional format restriction

**Precondition:** Registration page is open; security questions are enabled.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a Security Answer value containing special characters and numbers | Ans@123!# [test data] | Value is accepted, no format validation error is shown |
| 2 | Submit the form with the remaining mandatory fields valid | [test data] | No validation error is displayed for Security Answer |

---

## REQ-3: REG-001: The system shall allow an unauthenticated visitor to open the registration form. An authenticated user is redirected away from it per REQ-1.

Applied techniques: Use Case

### TC-REQ-3.1: Unauthenticated visitor can view and interact with all registration fields

**Precondition:** Registration page is open; user is not authenticated.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Verify Email field | — | Field is visible and accepts input |
| 2 | Verify Password field | — | Field is visible and accepts input |
| 3 | Verify Confirm Password field | — | Field is visible and accepts input |
| 4 | Verify Security Question field | — | Field is visible and a question can be selected |
| 5 | Verify Security Answer field | — | Field is visible and accepts input |

---

## REQ-4: REG-002: The system shall require all mandatory registration fields. All mandatory fields are trimmed before the required-field check, so a whitespace-only value counts as empty and fails validation.

Applied techniques: EP

### TC-REQ-4.1: Submitting with Email, Password, or Confirm Password left completely empty displays a validation error for that field

**Precondition:** Registration page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Leave Email empty, fill Password, Confirm Password, Security Question, Security Answer with valid data, submit | [test data for other fields] | Validation error is displayed for the Email field indicating it is required |
| 2 | Fill Email with valid data, leave Password empty, fill the remaining fields with valid data, submit | [test data] | Validation error is displayed for the Password field indicating it is required |
| 3 | Fill Email and Password with valid data, leave Confirm Password empty, fill the remaining fields with valid data, submit | [test data] | Validation error is displayed for the Confirm Password field indicating it is required |

### TC-REQ-4.2: Submitting with a mandatory field containing only whitespace displays a validation error (whitespace-only treated as empty)

**Precondition:** Registration page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a whitespace-only value in the Email field, fill the remaining mandatory fields with valid data, submit | "   " [test data, 3 spaces] | Validation error is displayed for the Email field indicating it is required (whitespace-only value is treated as empty) |

---

## REQ-5: REG-003: The system shall validate the email format against the standard `local@domain` form, accepting subdomains and plus-addressing.

Applied techniques: EP

### TC-REQ-5.1: Email field accepts an address containing a subdomain

**Precondition:** Registration page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter an email address containing a subdomain in the Email field, submit with the remaining mandatory fields valid | user@mail.example.com [test data] | No email-format validation error is displayed |

### TC-REQ-5.2: Email field accepts a plus-addressed value

**Precondition:** Registration page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a plus-addressed email value in the Email field, submit with the remaining mandatory fields valid | user+tag@example.com [test data] | No email-format validation error is displayed |

### TC-REQ-5.3: Email field rejects a value that does not conform to the standard format

**Precondition:** Registration page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a value that does not conform to the standard local@domain format in the Email field, submit | userexample.com [test data, missing @] | Validation error is displayed for the Email field indicating an invalid format |

---

## REQ-6: REG-004: The system shall not allow two accounts with the same email address. Emails are normalized by trimming whitespace and lowercasing before the uniqueness comparison. Uniqueness is enforced at persistence level (e.g. a database unique constraint), not only by a pre-check lookup; if two submissions race, exactly one succeeds and the other receives the generic registration failure message defined in REQ-14.

Applied techniques: EP, Use Case

### TC-REQ-6.1: Registering with an email identical to an existing account's email is rejected

**Precondition:** An account already exists with email "existing.user@example.com" [test data].

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Register a new account using the same email as the existing account, with valid mandatory data otherwise, submit | existing.user@example.com [test data] | Registration is rejected; no new account is created for this submission |

### TC-REQ-6.2: Registering with an email differing only by leading/trailing whitespace from an existing account's email is rejected

**Precondition:** An account already exists with email "existing.user@example.com" [test data].

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Register a new account using the existing email with added leading/trailing whitespace, with valid mandatory data otherwise, submit | "  existing.user@example.com  " [test data] | Registration is rejected; no new account is created for this submission |

### TC-REQ-6.3: Registering with an email differing only by letter case from an existing account's email is rejected

**Precondition:** An account already exists with email "existing.user@example.com" [test data].

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Register a new account using the existing email with different letter case, with valid mandatory data otherwise, submit | Existing.User@Example.com [test data] | Registration is rejected; no new account is created for this submission |

### TC-REQ-6.4: Concurrent registration submissions for the same normalized email — exactly one succeeds

**Precondition:** No account currently exists with email "race.user@example.com" [test data].

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit two registration requests concurrently with the same normalized email and valid mandatory data [test data/mechanism, e.g. two parallel HTTP requests] | race.user@example.com [test data] | Exactly one submission succeeds and creates one account; the other submission receives the generic registration failure message defined in REQ-14 |

---

## REQ-7: REG-005: The system shall validate the password against the configured password policy: minimum 8 and maximum 128 characters.

Applied techniques: BVA

### TC-REQ-7.1: Password field accepts exactly 8 characters (minimum boundary)

**Precondition:** Registration page is open; the remaining mandatory fields are filled with valid data.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a Password of exactly 8 characters, and the same value in Confirm Password, submit | Passw0rd [test data, 8 characters] | No password-length validation error is displayed |

### TC-REQ-7.2: Password field rejects a value of 7 characters (below minimum)

**Precondition:** Registration page is open; the remaining mandatory fields are filled with valid data.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a Password of 7 characters, and the same value in Confirm Password, submit | Passw0r [test data, 7 characters] | Validation error is displayed indicating the password does not meet the minimum length (8 characters) |

### TC-REQ-7.3: Password field accepts exactly 128 characters (maximum boundary)

**Precondition:** Registration page is open; the remaining mandatory fields are filled with valid data.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a Password of exactly 128 characters, and the same value in Confirm Password, submit | [test data, 128 characters] | No password-length validation error is displayed |

### TC-REQ-7.4: Password field rejects a value of 129 characters (above maximum)

**Precondition:** Registration page is open; the remaining mandatory fields are filled with valid data.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a Password of 129 characters, and the same value in Confirm Password, submit | [test data, 129 characters] | Validation error is displayed indicating the password exceeds the maximum length (128 characters) |

---

## REQ-8: REG-006: Confirm Password shall exactly match Password.

Applied techniques: EP

### TC-REQ-8.1: Confirm Password identical to Password passes validation

**Precondition:** Registration page is open; the remaining mandatory fields are filled with valid data.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter the same value in Password and Confirm Password, submit | Passw0rd1 [test data] | No mismatch validation error is displayed for Confirm Password |

### TC-REQ-8.2: Confirm Password different from Password displays a mismatch validation error

**Precondition:** Registration page is open; the remaining mandatory fields are filled with valid data.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a Password value and a different value in Confirm Password, submit | Password=Passw0rd1, Confirm Password=Passw0rd2 [test data] | Validation error is displayed for Confirm Password indicating it does not match Password |

---

## REQ-9: REG-007: If security questions are enabled, the user shall provide the required question and answer.

Applied techniques: EP

### TC-REQ-9.1: Submitting without selecting a Security Question displays a validation error

**Precondition:** Security questions are enabled; registration page is open; the remaining mandatory fields are filled with valid data.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Leave Security Question unselected, fill Security Answer and other mandatory fields with valid data, submit | [test data] | Validation error is displayed for the Security Question field indicating it is required |

### TC-REQ-9.2: Submitting without a Security Answer displays a validation error

**Precondition:** Security questions are enabled; registration page is open; the remaining mandatory fields are filled with valid data.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Select a Security Question, leave Security Answer empty, fill the remaining mandatory fields with valid data, submit | [test data] | Validation error is displayed for the Security Answer field indicating it is required |

---

## REQ-10: REG-008: Registration data shall be validated by the server even when client-side validation exists.

Applied techniques: Use Case

### TC-REQ-10.1: Invalid registration data submitted directly to the server is still validated and rejected

**Precondition:** Application is available.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Send a registration request directly to the server-side registration endpoint, bypassing the UI/client-side validation, with invalid data (e.g. invalid email format) [test data/mechanism] | invalid-email [test data] | Server rejects the request; the response indicates a validation error; no account is created |

---

## REQ-11: REG-009: Valid registration data shall create exactly one customer account. The account is immediately active on creation with the default role "customer"; no email verification or activation step is required.

Applied techniques: Use Case

### TC-REQ-11.1: Submitting valid registration data creates exactly one customer account

**Precondition:** Registration page is open; email used is unique.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the registration form with valid, unique mandatory data | [test data] | Exactly one customer account is created |

### TC-REQ-11.2: The newly created account has the default role "customer"

**Precondition:** Registration was just completed with valid data (TC-REQ-11.1).

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Inspect the created account's role | — | Account role is "customer" |

### TC-REQ-11.3: The newly created account is immediately active without email verification or activation

**Precondition:** Registration was just completed with valid data (TC-REQ-11.1).

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Immediately attempt to log in with the newly registered credentials, without performing any activation or email-verification step | [test data] | Login succeeds; account is active immediately upon creation |

---

## REQ-12: REG-010: Invalid registration data shall not create an account.

Applied techniques: EP

### TC-REQ-12.1: Submitting invalid registration data does not create a customer account

**Precondition:** Registration page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the registration form with invalid data (e.g. invalid email format) | invalid-email [test data] | Registration fails; no customer account is created |

---

## REQ-13a: REG-011: After successful registration, the user shall receive a clear success indication.

Applied techniques: Use Case

### TC-REQ-13a.1: Success indication is displayed after successful registration

**Precondition:** Registration page is open; valid, unique mandatory data prepared.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the registration form with valid, unique mandatory data | [test data] | A success indication is displayed to the user |

---

## REQ-13b: REG-011: After successful registration, the user shall be redirected to the login page; the user is not automatically logged in.

Applied techniques: Use Case

### TC-REQ-13b.1: After successful registration, the user is redirected to the login page

**Precondition:** Registration page is open; valid, unique mandatory data prepared.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the registration form with valid, unique mandatory data | [test data] | User is redirected to the login page |

### TC-REQ-13b.2: After successful registration, the user is not automatically logged in

**Precondition:** Registration was just completed and redirect to login page occurred (TC-REQ-13b.1).

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Verify the user's session/authentication state after the redirect | — | User is not authenticated; the login page requires the user to enter credentials |

---

## REQ-14: REG-012: Validation failures shall display an appropriate error without exposing internal system details — no stack traces, raw database errors, or internal identifiers. A failure caused by an already-registered email shall show a generic failure message that does not reveal whether the email already exists.

Applied techniques: EP

### TC-REQ-14.1: A validation failure error contains no stack trace, raw database error, or internal identifier

**Precondition:** Registration page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the registration form with invalid data (e.g. invalid email format) | invalid-email [test data] | Error message displayed contains no stack trace, no raw database error text, and no internal identifier |

### TC-REQ-14.2: A registration failure caused by an already-registered email displays a generic failure message

**Precondition:** An account already exists with email "existing.user@example.com" [test data].

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Register with an email matching the existing account's normalized email | existing.user@example.com [test data] | A generic registration failure message is displayed; the message does not state or imply that the email is already registered |

---

## REQ-15: BR-REG-001: Email addresses must be unique after normalization, where normalization is defined as trimming whitespace and lowercasing before the uniqueness comparison (same single rule as REQ-6).

> This requirement restates the same uniqueness rule already verified under REQ-6 (see TC-REQ-6.1 – TC-REQ-6.4). No additional test cases are generated here to avoid duplication.

---

## REQ-16: BR-REG-002: Passwords shall never be stored or logged in plaintext; they are hashed at rest, never written to logs, and never returned in any API response or error output.

Applied techniques: Use Case

### TC-REQ-16.1: Password value does not appear anywhere in application logs

**Precondition:** Application logging is accessible for inspection.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Register an account using a known Password value, then inspect the application logs generated during this request | Str0ngP@ss1 [test data] | The password value does not appear anywhere in the logs |

### TC-REQ-16.2: Password value is not returned in any API response, including error responses

**Precondition:** Application is available.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit a registration request (both a successful one and one that fails validation) using a known Password value, then inspect the response bodies | Str0ngP@ss1 [test data] | The password value is not present in any response, including error responses |

### TC-REQ-16.3: Password is stored at rest in hashed form, not in plaintext

**Precondition:** Access to the stored account record is available for inspection.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Register an account using a known Password value, then inspect the stored account record at rest | Str0ngP@ss1 [test data] | The stored value is not the plaintext password; it is stored in hashed form |

---

## REQ-17: BR-REG-003: Credentials shall be transmitted securely in non-development environments.

Applied techniques: Use Case

### TC-REQ-17.1: Registration data, including Password, is transmitted over a secure connection

**Precondition:** Registration page is open in the QA environment under test; network traffic capture is available.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the registration form while capturing network traffic (e.g. browser dev tools / proxy) | [test data] | The registration request, including the Password field, is transmitted over an HTTPS/TLS connection |

---

## REQ-18: BR-REG-004: Repeated submission shall not create duplicate accounts. This covers double-click, page refresh / POST resubmission, and back-button resubmission, and is guaranteed by the same persistence-level uniqueness enforcement as REQ-6.

Applied techniques: Use Case

### TC-REQ-18.1: Double-clicking the submit action creates only one account

**Precondition:** Registration page is open; valid, unique mandatory data prepared.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Fill the form with valid, unique mandatory data and double-click the submit action | [test data] | Exactly one account is created |

### TC-REQ-18.2: Refreshing the page after a registration POST submission does not create a duplicate account

**Precondition:** Registration page is open; valid, unique mandatory data prepared.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the registration form with valid, unique mandatory data, causing an account to be created | [test data] | One account is created |
| 2 | Refresh the page to trigger a resubmission of the same POST data | — | No duplicate account is created for the resubmitted data |

### TC-REQ-18.3: Using the browser back button after successful registration and resubmitting does not create a duplicate account

**Precondition:** Registration was just completed successfully with valid data.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Use the browser back button to return to the registration form and resubmit the same data | [test data] | No duplicate account is created |

### TC-REQ-18.4: A repeat submission that does not create an account displays the generic registration failure message

**Precondition:** A repeat-submission scenario is triggered (e.g. TC-REQ-18.2 or TC-REQ-18.3) that does not result in a new account.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Observe the response to the repeat submission that does not create an account | — | The generic registration failure message defined in REQ-14 is displayed |

---

## REQ-19: BR-REG-005: User input shall be handled safely and shall not allow script or query injection. Dangerous input is safely escaped on output wherever registration data (email, security answer) is later displayed, rather than rejected outright, unless it also violates the field's own format rule.

Applied techniques: EP

### TC-REQ-19.1: A Security Answer containing script/HTML markup is accepted and safely escaped wherever later displayed

**Precondition:** Registration page is open; security questions are enabled.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a Security Answer containing script/HTML markup, submit with valid mandatory data otherwise | `<script>alert(1)</script>` | Registration succeeds; the value is accepted (not rejected by format validation) |
| 2 | View the Security Answer value wherever it is later displayed [test data — e.g. account/admin view] | — | Value is displayed as literal text (escaped); the script does not execute |

### TC-REQ-19.2: A Security Answer containing SQL-like syntax is accepted and does not cause a database error

**Precondition:** Registration page is open; security questions are enabled.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a Security Answer containing SQL-like syntax, submit with valid mandatory data otherwise | `' OR '1'='1` | Registration completes without a database error or unintended query behavior; the value is stored as literal data |

### TC-REQ-19.3: An Email containing script/HTML-like characters that violates the email format rule is rejected

**Precondition:** Registration page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter an Email value containing script/HTML-like characters that does not conform to the standard local@domain format, submit | `<script>alert(1)</script>@example.com` [test data] | Validation error is displayed for the Email field indicating an invalid format; registration is rejected by email format validation |

---

## REQ-20: Important Edge Cases (for grooming/test design coverage): empty mandatory fields; invalid email format; existing email; existing email with different letter case; leading/trailing whitespace in email; password below or above allowed length; password and confirmation mismatch; missing security question/answer when required; very long input; Unicode and special-character input; HTML/JavaScript-like or SQL-like input; multiple rapid submissions; network or backend failure during registration. Explicit maximum lengths apply — email 255, password 128, security answer 128 — and over-limit input is rejected with a validation error, never silently truncated. Unicode letters are accepted in password and security answer; email must still conform to the standard format rule in REQ-5; characters that do not break a field's own format are accepted and safely escaped on output per REQ-19. Multiple rapid submissions concern duplicate-account prevention (covered by REQ-6 and REQ-18), not rate limiting.

Applied techniques: EP, BVA

### TC-REQ-20.1: Email field accepts exactly 255 characters (maximum boundary)

**Precondition:** Registration page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter an Email value of exactly 255 characters conforming to the standard local@domain format, submit with the remaining mandatory fields valid | [test data, 255 characters] | No email-length validation error is displayed |

### TC-REQ-20.2: Email field rejects a value exceeding 255 characters, displaying a validation error rather than truncating

**Precondition:** Registration page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter an Email value of 256 characters, submit | [test data, 256 characters] | Validation error is displayed indicating the email exceeds the maximum length (255 characters); the value is not silently truncated |

### TC-REQ-20.3: Password field accepts a value containing Unicode letters

**Precondition:** Registration page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a Password containing Unicode letters (within the 8–128 character length policy), and the same value in Confirm Password, submit | Пароль123ü [test data] | Value is accepted, no validation error is displayed |

### TC-REQ-20.4: Security Answer field accepts a value containing Unicode letters

**Precondition:** Registration page is open; security questions are enabled.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a Security Answer containing Unicode letters (within the 128-character limit, non-empty after trim), submit | Відповідьü [test data] | Value is accepted, no validation error is displayed |

---

## REQ-21: AC-REG-001 (Successful Registration): Given a visitor provides a unique valid email and valid mandatory data, when registration is submitted, then exactly one account is created and registration success is shown.

Applied techniques: Use Case

### TC-REQ-21.1: End-to-end successful registration creates one account and shows success

**Precondition:** Registration page is open; Email used is unique and not registered.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the registration form with a unique valid email and valid mandatory data | [test data] | Exactly one account is created |
| 2 | Observe the registration outcome | — | Registration success indication is displayed |

---

## REQ-22: AC-REG-002 (Duplicate Email): Given an account already exists for the email, when the visitor registers with the same normalized email, then registration fails, no additional account is created, and the error shown is generic and does not reveal that the email is already registered.

Applied techniques: Use Case

### TC-REQ-22.1: Registering with an already-registered normalized email fails with a generic message and no additional account

**Precondition:** An account already exists with email "existing.user@example.com" [test data].

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Register with the same normalized email as the existing account, with valid mandatory data otherwise | existing.user@example.com [test data] | Registration fails; no additional account is created; the displayed failure message is generic and does not reveal that the email is already registered |

---

## REQ-23: AC-REG-003 (Invalid Input): Given one or more mandatory values are missing or invalid, when registration is submitted, then registration fails, all validation errors for the currently-invalid fields are displayed together (not only the first), and no account is created.

Applied techniques: EP, Use Case

### TC-REQ-23.1: Submitting with one or more mandatory values missing or invalid fails and creates no account

**Precondition:** Registration page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the form with a mandatory value missing or invalid | [test data] | Registration fails; no account is created |

### TC-REQ-23.2: Multiple invalid fields at once display validation errors for all of them together

**Precondition:** Registration page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the form with two or more mandatory fields invalid simultaneously (e.g. Email left empty and Confirm Password not matching Password) | [test data] | Validation errors are displayed for all currently-invalid fields at once, not only for the first invalid field |

---

## REQ-24: AC-REG-004 (Password Mismatch): Given Password and Confirm Password differ, when registration is submitted, then registration fails and the mismatch is communicated to the user.

Applied techniques: EP

### TC-REQ-24.1: Password/Confirm Password mismatch causes registration to fail with the mismatch communicated

**Precondition:** Registration page is open; the remaining mandatory fields are filled with valid data.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a Password value and a different value in Confirm Password, submit | Password=Passw0rd1, Confirm Password=Passw0rd2 [test data] | Registration fails; the mismatch between Password and Confirm Password is communicated to the user |

---

## REQ-25: AC-REG-005 (Backend Failure): Given valid registration data and account creation fails on the backend, when registration is submitted, then the user receives a controlled error and no partially usable account remains — no user record persists after the failed write, and the same email can be retried afterward.

Applied techniques: Use Case

### TC-REQ-25.1: Backend write failure during registration produces a controlled error, not a raw system error

**Precondition:** Registration page is open; valid registration data prepared; a backend write failure is forced [test data/environment fault-injection mechanism].

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit valid registration data while the backend account-creation write is forced to fail | [test data] | User receives a controlled error message; no raw system or server error (e.g. stack trace, default server error page) is shown |

### TC-REQ-25.2: No user record persists after a failed backend write during registration

**Precondition:** The failed backend write scenario from TC-REQ-25.1 has just occurred.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Inspect the system for a user record matching the submitted email from the failed attempt | — | No user record persists for that attempt |

### TC-REQ-25.3: The same email can be retried after a failed backend write

**Precondition:** The failed backend write scenario from TC-REQ-25.1 has just occurred; backend is functioning normally again.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Resubmit registration using the same email as the failed attempt, with the backend functioning normally | same email as TC-REQ-25.1 [test data] | Registration succeeds; an account is created using that email |

---

## Statistics

- Requirements covered: 30 (26 with dedicated test cases; 3 structural requirements — REQ-2b, REQ-2c, REQ-2d — sufficiently verified by the checklist alone, no test case needed; 1 duplicate business rule — REQ-15 — covered by REQ-6, see cross-reference note)
- Requirements needing clarification: 0
- Total number of test cases: 58
