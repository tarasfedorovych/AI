# API Tests Setup Guide

This skill needs no tracker or VCS authentication of its own — it does
not talk to your issue tracker or your PR host. It reads the test-cases
and automation-strategy files produced earlier in the pipeline, and
optionally reads a codebase folder or a Swagger/OpenAPI document you
provide.

## Input Modes

Pick whichever applies to your situation:

1. **Codebase folder** — point the skill at your API project's root
   (or a subfolder). It reads route/controller definitions and any
   existing Playwright config to generate tests that match real
   endpoints and existing conventions.
2. **Swagger/OpenAPI document** — give a URL or local file. The skill
   matches test cases to documented operations.
3. **Neither** — the skill will ask you, per test case, for the
   endpoint path, method, expected status, required fields, and auth
   requirement. It never invents these.

You can combine a codebase folder and a Swagger doc; the codebase is
also used to detect an existing Playwright setup to reuse (base URL,
auth fixtures) regardless of which discovery source you provide.

## What to Configure

If your team always uses the same auth header pattern (e.g. every
endpoint needs `Authorization: Bearer <token>` from the same env var),
you can note that convention in
`references/playwright-conventions.md` under "Config Detection and
Scaffolding" so it's applied by default when no existing codebase
fixture is found. This is optional.

## Skill Files

```
8-api-tests-template/
  SKILL.md                              — Agent definition
  setup-guide.md                        — This guide
  references/
    output-template.md                  — Output structure (spec files + summary.md)
    playwright-conventions.md           — Naming, fixtures, config-detection rules
    api-mapping-schema.md               — api-mapping.json schema and worked examples
```

## Next Steps

1. Run this skill after automation-strategy.
2. Review the generated `.spec.ts` files and `summary.md` in
   `<ISSUEKEY>/api-tests/`.
3. Answer any pending clarifications listed in summary.md, then re-run
   to generate the remaining tests.
4. Run `npx playwright test` per the instructions in summary.md.
