# Tracker Setup

> ⚠️ **CONFIGURE:** fill out this file with the issue tracker access
> method for your team. Replace all `<placeholders>` with real values.
> After filling in — delete these ⚠️ CONFIGURE blocks.

## Tracker

- **System:** `<Jira / GitHub Issues / GitLab / Linear / Azure DevOps / other>`
- **Issue key format:** `<e.g. PROJ-123, #123, TEAM-123>`
- **Access method:** `<MCP tool / CLI / REST API>`
- **Auth:** `<how credentials/tokens are provided>`

## Verify Access

```
<exact command or MCP call used to confirm read access to a single issue>
```

## Field Mapping

- `<link to or note about where the per-task-type field map lives —
  e.g. 1-task-context-skill-template/references/field-maps.md>`

## Notes

- `<any team-specific tracker conventions: custom fields, required
  permissions, rate limits, etc.>`
