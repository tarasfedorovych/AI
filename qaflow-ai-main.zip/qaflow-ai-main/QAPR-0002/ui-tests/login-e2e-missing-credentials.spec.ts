import { test, expect } from '@playwright/test';
import { LoginPage } from '../../ui-framework/pages/LoginPage';

// REQ-24: AC-LOGIN-003 (Missing Credentials) — given email or password is
// missing, login does not succeed and an appropriate validation error is
// displayed.

// TC-REQ-24.1
test('TC-REQ-24.1: Missing email or password prevents successful login and shows a validation error', async ({ page }) => {
  const loginPage = new LoginPage(page);

  await test.step('Submit the login form with Email missing', async () => {
    await loginPage.goto();
    await loginPage.fillPassword('anyPassword1'); // [test data]
    await loginPage.touchField(loginPage.emailInput);
  });

  await test.step('Verify authentication does not succeed and a validation error is displayed', async () => {
    await expect(
      loginPage.emailRequiredError,
      'expected an appropriate validation error to be displayed for the missing Email'
    ).toBeVisible();
    await expect(page, 'expected to remain on the login page').toHaveURL(/#\/login/);
  });
});
