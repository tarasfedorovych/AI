import { test, expect } from '@playwright/test';
import { RegistrationPage } from '../../ui-framework/pages/RegistrationPage';

const VALID_PASSWORD = 'Str0ngP@ssw0rd!'; // [test data] valid mandatory data

function uniqueEmail(local: string) {
  return `${local}-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per run
}

// TC-REQ-2e.2
test('TC-REQ-2e.2: Security Answer field accepts exactly 128 characters (maximum boundary)', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);
  const securityAnswer = 'A'.repeat(128); // [test data, 128 characters]
  const email = uniqueEmail('secans-128');
  let userId: number | undefined;

  await test.step('Navigate to the registration page', async () => {
    await registrationPage.goto();
  });

  await test.step('Enter a Security Answer value of exactly 128 characters', async () => {
    await registrationPage.fillSecurityAnswer(securityAnswer);
    await registrationPage.touchField(registrationPage.securityAnswerInput);
  });

  await test.step('Verify no length validation error is shown for Security Answer', async () => {
    await expect(
      registrationPage.securityAnswerRequiredError,
      'expected no validation error for a 128-character Security Answer'
    ).not.toBeVisible();
  });

  try {
    await test.step('Submit the form with the remaining mandatory fields valid', async () => {
      await registrationPage.fillEmail(email);
      await registrationPage.fillPassword(VALID_PASSWORD);
      await registrationPage.fillRepeatPassword(VALID_PASSWORD);
      await registrationPage.selectFirstSecurityQuestion();
      userId = await registrationPage.submitAndCaptureCreatedUserId();
    });

    await test.step('Verify no validation error is displayed for Security Answer', async () => {
      await expect(
        registrationPage.securityAnswerRequiredError,
        'expected no validation error for Security Answer after submitting a 128-character value'
      ).not.toBeVisible();
    });
  } finally {
    if (userId) {
      await page.request.delete(`/api/Users/${userId}`);
    }
  }
});

// TC-REQ-2e.5
test('TC-REQ-2e.5: Security Answer field accepts special characters and numbers with no additional format restriction', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);
  const securityAnswer = 'Ans@123!#'; // [test data]
  const email = uniqueEmail('secans-special');
  let userId: number | undefined;

  await test.step('Navigate to the registration page', async () => {
    await registrationPage.goto();
  });

  await test.step('Enter a Security Answer value containing special characters and numbers', async () => {
    await registrationPage.fillSecurityAnswer(securityAnswer);
    await registrationPage.touchField(registrationPage.securityAnswerInput);
  });

  await test.step('Verify no format validation error is shown', async () => {
    await expect(
      registrationPage.securityAnswerRequiredError,
      'expected no validation error for a Security Answer containing special characters and numbers'
    ).not.toBeVisible();
  });

  try {
    await test.step('Submit the form with the remaining mandatory fields valid', async () => {
      await registrationPage.fillEmail(email);
      await registrationPage.fillPassword(VALID_PASSWORD);
      await registrationPage.fillRepeatPassword(VALID_PASSWORD);
      await registrationPage.selectFirstSecurityQuestion();
      userId = await registrationPage.submitAndCaptureCreatedUserId();
    });

    await test.step('Verify no validation error is displayed for Security Answer', async () => {
      await expect(
        registrationPage.securityAnswerRequiredError,
        'expected no validation error for Security Answer after submitting special characters/numbers'
      ).not.toBeVisible();
    });
  } finally {
    if (userId) {
      await page.request.delete(`/api/Users/${userId}`);
    }
  }
});
