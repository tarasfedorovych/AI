import { test, expect } from '@playwright/test';
import { RegistrationPage } from '../../ui-framework/pages/RegistrationPage';

const VALID_PASSWORD = 'Str0ngP@ssw0rd!'; // [test data] valid mandatory data
const VALID_SECURITY_ANSWER = 'TestAnswer123'; // [test data] valid mandatory data

function uniqueEmail(local: string) {
  return `${local}-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per run, standard local@domain form
}

// TC-REQ-2a.2
test('TC-REQ-2a.2: Email field accepts a value in the standard local@domain format', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);
  const email = uniqueEmail('user');
  let userId: number | undefined;

  await test.step('Navigate to the registration page', async () => {
    await registrationPage.goto();
  });

  await test.step('Enter a value in the standard local@domain format in the Email field', async () => {
    await registrationPage.fillEmail(email);
    await registrationPage.touchField(registrationPage.emailInput);
  });

  await test.step('Verify no email-format validation error is shown', async () => {
    await expect(
      registrationPage.emailInvalidFormatError,
      'expected no email-format validation error for a standard local@domain address'
    ).not.toBeVisible();
  });

  try {
    await test.step('Submit the form with the remaining mandatory fields filled with valid data', async () => {
      await registrationPage.fillPassword(VALID_PASSWORD);
      await registrationPage.fillRepeatPassword(VALID_PASSWORD);
      await registrationPage.selectFirstSecurityQuestion();
      await registrationPage.fillSecurityAnswer(VALID_SECURITY_ANSWER);
      userId = await registrationPage.submitAndCaptureCreatedUserId();
    });

    await test.step('Verify no email-format validation error is displayed', async () => {
      await expect(
        registrationPage.emailInvalidFormatError,
        'expected no email-format validation error after submitting a valid local@domain address'
      ).not.toBeVisible();
    });
  } finally {
    if (userId) {
      await page.request.delete(`/api/Users/${userId}`);
    }
  }
});
