# AI Audit System

Automated quality audits for test automation codebases and Git workflows.  
Produces scored JSON reports + Excel workbooks with findings and an action plan.

---

## Prerequisites

- Python 3.8+: `pip install -r ai_audit/requirements.txt`
- An AI coding tool: **VS Code + GitHub Copilot Chat**, **Cursor**, or **Claude Code**

---

## Running Audits

### Option A — VS Code Copilot Agents

Open Copilot Chat (`Ctrl+Shift+I`), type `@` and pick an agent:

| Agent | Command | Output |
|---|---|---|
| Test Automation Auditor | `@Test Automation Auditor` | `reports/results_MM_DD_YY.json` + `.xlsx` |
| GitFlow Auditor | `@GitFlow Auditor` | `reports/gitflow_MM_DD_YY.json` + `.xlsx` |

The agent reads the prompt, runs all phases, validates output, generates the Excel report, and prints a completion summary.

**Examples:**
```
@Test Automation Auditor              # Excel only
@Test Automation Auditor docx html    # Excel + Word + HTML
@GitFlow Auditor                      # default repo
@GitFlow Auditor path=C:\Projects\other-repo
```

Agent definitions: `.github/agents/audit.agent.md` · `.github/agents/gitflow.agent.md`

> **Cursor / Claude Code users:** Named `@agents` are not supported, but you can run audits the same way — see below.

---

### Option A2 — Cursor / Claude Code Agents

Cursor and Claude Code support their own agent/rules files that work similarly to VS Code agents. The `.github/agents/` files contain the full execution instructions — you can reference them directly.

**Cursor (Composer):**
1. Open Composer (`Ctrl+I`)
2. Paste: `Read and follow the instructions in .github/agents/audit.agent.md and run the full audit.`
3. Composer reads the file, executes all phases, and writes the output automatically

**Claude Code:**
1. Open Claude Code in your terminal: `claude`
2. Paste: `Read and follow the instructions in .github/agents/audit.agent.md and run the full audit.`
3. Claude Code reads the file and executes the full pipeline

The agent files (`.github/agents/audit.agent.md`, `.github/agents/gitflow.agent.md`) contain everything the AI needs: scope rules, phase instructions, validation checks, and report generation commands. No copy-pasting of full prompts required.

---

### Option B — Manual Prompt (Copilot Chat / Cursor / Claude Code)

Works with any AI coding assistant. Paste the prompt into the chat panel of your tool.

**Test Automation Audit:**
1. Use the `@Test Automation Auditor` agent, or paste into your AI chat:
   > Read and follow: `ai_audit/.github/prompts/orchestrator.prompt.md`  
   > Use schema: `ai_audit/schemas/audit.schema.json`  
   > Use scorecard: `ai_audit/schemas/audit.scorecard.json`  
   > Save output to: `ai_audit/reports/results_MM_DD_YY.json`
2. Generate Excel: `python ai_audit/scripts/json_to_xlsx.py ai_audit/reports/results_MM_DD_YY.json ai_audit/reports/results_MM_DD_YY.xlsx`

**GitFlow Audit:**
1. Fetch git history: `git fetch --all --tags`
2. Paste into your AI chat:
   > Read and follow: `ai_audit/.github/prompts/audit.gitflow.prompt.md`  
   > Use schema: `ai_audit/schemas/gitflow.schema.json`  
   > Save output to: `ai_audit/reports/gitflow_MM_DD_YY.json`
3. Generate Excel: `python ai_audit/scripts/gitflow_json_to_xlsx.py ai_audit/reports/gitflow_MM_DD_YY.json ai_audit/reports/gitflow_MM_DD_YY.xlsx`

Full prompt: `.github/prompts/audit.gitflow.prompt.md`

---

### Option C — Skills Pipeline (parallel execution, large repos)

Run individual skill prompts in separate AI chat windows for lower context pressure:

```
S1: repo_discovery  →  S2–S6 (run in parallel)  →  S7: score_and_report
```

Entry point and execution order: `.github/prompts/orchestrator.prompt.md`  
Or let the AI coordinate automatically: paste the content of `orchestrator.prompt.md` into your AI chat.

---

## Report Generation

```bash
# Install dependencies (once)
pip install -r ai_audit/requirements.txt

# Test automation audit
python ai_audit/scripts/json_to_xlsx.py  ai_audit/reports/results_MM_DD_YY.json  ai_audit/reports/results_MM_DD_YY.xlsx
python ai_audit/scripts/json_to_html.py  ai_audit/reports/results_MM_DD_YY.json  ai_audit/reports/results_MM_DD_YY.html
python ai_audit/scripts/json_to_docx.py  ai_audit/reports/results_MM_DD_YY.json  ai_audit/reports/results_MM_DD_YY.docx

# GitFlow audit
python ai_audit/scripts/gitflow_json_to_xlsx.py  ai_audit/reports/gitflow_MM_DD_YY.json  ai_audit/reports/gitflow_MM_DD_YY.xlsx
```

All agents generate the Excel report automatically — run the scripts above only when using Option B/C.

---

## Reference Skills (manual prompting)

When prompting manually (Option B/C), use these skills in Copilot Chat to inject reference context:

| Skill | Invoke | Use when |
|---|---|---|
| `#audit-schema` | Type `#audit-schema` in chat | Checking required JSON fields, enum values, field constraints |
| `#scoring-guide` | Type `#scoring-guide` in chat | Deciding a score, justifying a risk_level, checking band indicators |

**Examples:**
```
#audit-schema validate this JSON output for missing fields
#scoring-guide what score would you give this reliability_flakiness area?
#audit-schema #scoring-guide review my S7 output before writing the report
```

---

## Folder Structure

```
ai_audit/
├── .github/
│   ├── agents/                           # Copilot agent definitions
│   │   ├── audit.agent.md                #   @Test Automation Auditor
│   │   └── gitflow.agent.md              #   @GitFlow Auditor
│   └── prompts/                          # Audit prompt entry points
│       ├── audit.gitflow.prompt.md       #   GitFlow audit
│       ├── orchestrator.prompt.md        #   Pipeline entry point
│       └── pipeline/                     #   Pipeline steps S1–S7
│           ├── s1_repo_discovery.prompt.md
│           ├── s2_flakiness_scan.prompt.md
│           ├── s3_quality_scan.prompt.md
│           ├── s4_architecture_scan.prompt.md
│           ├── s5_coverage_scan.prompt.md
│           ├── s6_ci_cd_scan.prompt.md
│           └── s7_score_and_report.prompt.md
├── .vscode/
│   └── settings.json
├── schemas/                              # JSON schemas + scoring criteria
│   ├── audit.schema.json
│   ├── audit.scorecard.json
│   └── gitflow.schema.json
├── scripts/                              # Report generators
│   ├── audit_scan.py
│   ├── gitflow_json_to_xlsx.py
│   ├── json_to_docx.py
│   ├── json_to_html.py
│   ├── json_to_md.py
│   └── json_to_xlsx.py
├── reports/                              # Output: JSON + Excel reports (date-stamped)
│   ├── results_MM_DD_YY.json
│   ├── results_MM_DD_YY.xlsx
│   └── backup/                           #   Archived/historical reports
├── logs/                                 # audit.log
├── requirements.txt
└── viovendi-monitoring.code-workspace
```

---

## Troubleshooting

**Invalid JSON output** — ask the AI: *"Regenerate the JSON with valid syntax, validate before outputting."*

**Missing fields** — compare against `schemas/audit.schema.json` or `schemas/gitflow.schema.json`, then ask AI to fill in missing sections.

**Script fails** — check dependencies: `pip install -r ai_audit/requirements.txt --upgrade`

**GitFlow missing data** — run `git fetch --all --tags` before auditing, or use `@GitFlow Auditor` which does this automatically.

**Validate JSON syntax:**
```bash
python -m json.tool ai_audit/reports/results_MM_DD_YY.json
python -m json.tool ai_audit/reports/gitflow_MM_DD_YY.json
```
