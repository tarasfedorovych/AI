// Page: /#/login — user login form (Juice Shop)
import type { Page, Locator } from '@playwright/test';
import { dismissOverlays } from './dismissOverlays';

export class LoginPage {
  readonly page: Page;
  readonly emailInput: Locator;
  readonly passwordInput: Locator;
  readonly loginButton: Locator;
  readonly rememberMeCheckbox: Locator;
  readonly emailRequiredError: Locator;
  readonly passwordRequiredError: Locator;
  readonly invalidCredentialsError: Locator;
  readonly accountMenuButton: Locator;
  readonly logoutMenuItem: Locator;

  constructor(page: Page) {
    this.page = page;
    this.emailInput = page.getByRole('textbox', { name: 'Text field for the login email' });
    this.passwordInput = page.getByRole('textbox', { name: 'Text field for the login password' });
    this.loginButton = page.getByRole('button', { name: 'Login', exact: true });
    // Added for QAPR-0002 (login test cases) — not present in the original
    // QAPR-0001 discovery pass, which only needed emailInput/passwordInput/
    // loginButton/goto/login for its one login-page test (TC-REQ-1.2).
    this.rememberMeCheckbox = page.getByRole('checkbox', { name: 'Checkbox to stay logged in or not logged in' });
    // MANDATORY_EMAIL / MANDATORY_PASSWORD translation strings
    // (frontend/src/assets/i18n/en.json), shown when emailControl/
    // passwordControl is touched and invalid (login.component.html).
    this.emailRequiredError = page.getByText('Please provide an email address.');
    this.passwordRequiredError = page.getByText('Please provide a password.');
    // The single generic error the server returns for both an unknown
    // email and a correct email with a wrong password (routes/login.ts),
    // rendered verbatim by login.component.html's `{{error}}` div.
    this.invalidCredentialsError = page.getByText('Invalid email or password.');
    // Navbar account menu (navbar.component.html) — used to confirm
    // authenticated state: the "Logout" menu item only renders when
    // isLoggedIn() is true.
    this.accountMenuButton = page.getByRole('button', { name: 'Show/hide account menu' });
    // Rendered as a Material mat-menu-item, whose accessible role is
    // 'menuitem' (not 'button', despite the aria-label reading "Logout")
    // — confirmed via a live ARIA-snapshot discovery pass after logging in
    // (see ui-tests/discovery/pages.json).
    this.logoutMenuItem = page.getByRole('menuitem', { name: 'Logout' });
  }

  async goto(): Promise<void> {
    // See RegistrationPage.goto() — a same-document hash-only
    // navigation is unreliable here, so force a full document load via
    // about:blank first.
    await this.page.goto('about:blank');
    await this.page.goto('/#/login');
    await dismissOverlays(this.page);
  }

  async login(email: string, password: string): Promise<void> {
    await this.emailInput.fill(email);
    await this.passwordInput.fill(password);
    await this.loginButton.click();
  }

  async fillEmail(value: string): Promise<void> {
    await this.emailInput.fill(value);
  }

  async fillPassword(value: string): Promise<void> {
    await this.passwordInput.fill(value);
  }

  async setRememberMe(checked: boolean): Promise<void> {
    const isChecked = await this.rememberMeCheckbox.isChecked();
    if (isChecked !== checked) {
      await this.rememberMeCheckbox.click();
    }
  }

  // The Login button is disabled while `!emailControl.value ||
  // !passwordControl.value` (login.component.html), so a required-field
  // mat-error can only be observed by touching the target field directly —
  // same rationale and mechanism as RegistrationPage.touchField.
  async touchField(field: Locator): Promise<void> {
    await field.focus();
    await field.blur();
  }

  // Opens the navbar account menu and reports whether the "Logout" item is
  // present (i.e. the app currently considers the user authenticated), then
  // closes the menu again so it doesn't leak into the next interaction.
  async isAuthenticated(): Promise<boolean> {
    await this.accountMenuButton.click();
    let loggedIn: boolean;
    try {
      await this.logoutMenuItem.waitFor({ state: 'visible', timeout: 2000 });
      loggedIn = true;
    } catch {
      loggedIn = false;
    }
    await this.page.keyboard.press('Escape');
    return loggedIn;
  }
}
