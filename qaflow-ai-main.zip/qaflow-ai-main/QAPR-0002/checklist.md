# QAPR-0002 - QA Checklist

Requirements: c:\src\!QA pipeline\QAPR-0002\requirements.md
Generated: 2026-09-04

## Checklist

### REQ-1: Preconditions: The application is available; the login page is accessible; a registered account exists for successful-login scenarios.
- [ ] REQ-1.1: Login page is accessible to an unauthenticated visitor.

### REQ-2a: Login Field — Email (required, must identify an eligible account).
- [ ] REQ-2a.1: Email field is present on the login form.
- [ ] REQ-2a.2: Email field accepts any string value (no client-side format restriction beyond required).

### REQ-2b: Login Field — Password (required, must match the account credential).
- [ ] REQ-2b.1: Password field is present on the login form.

### REQ-2c: Login Field — Remember Me (if supported — uses configured persistent-session behavior).
- [ ] REQ-2c.1: Remember Me control is present on the login form.
- [ ] REQ-2c.2: Remember Me control can be toggled on and off.

### REQ-3: LOGIN-001: The system shall allow unauthenticated users to access the login form.
- [ ] REQ-3.1: An unauthenticated visitor who opens the login form can view and interact with the Email and Password fields and the submit control.

### REQ-4: LOGIN-002: The system shall require email and password.
- [ ] REQ-4.1: Submitting the login form with Email left completely empty displays a validation error / prevents submission.
- [ ] REQ-4.2: Submitting the login form with Password left completely empty displays a validation error / prevents submission.
- [ ] REQ-4.3: Submitting the login form with a whitespace-only Email value is treated as empty (does not authenticate as if a value were provided).
- [ ] REQ-4.4: Submitting the login form with a whitespace-only Password value is treated as empty (does not authenticate as if a value were provided).

### REQ-5: LOGIN-003: The password field shall obscure its value by default.
- [ ] REQ-5.1: The Password field's entered value is visually obscured (masked) by default.

### REQ-6: LOGIN-004: The system shall authenticate a user when valid credentials for an eligible account are provided.
- [ ] REQ-6.1: Submitting the correct email and password for an existing account authenticates successfully.

### REQ-7: LOGIN-005: The system shall reject an unknown email or incorrect password.
- [ ] REQ-7.1: Submitting an email that does not match any existing account is rejected.
- [ ] REQ-7.2: Submitting a correct/existing email with an incorrect password is rejected.

### REQ-8: LOGIN-006: Failed authentication shall not create an authenticated session.
- [ ] REQ-8.1: After a rejected login attempt, no authenticated session exists (a subsequent request for authenticated-only data/functionality is not granted).

### REQ-9: LOGIN-007: Successful authentication shall establish a session associated with the correct user.
- [ ] REQ-9.1: After a successful login, the established session identifies the same account whose credentials were submitted (not a different or generic account).

### REQ-10: LOGIN-008: The authenticated state shall persist while the session remains valid.
- [ ] REQ-10.1: After a successful login, the user remains authenticated across subsequent navigation/requests while the session has not expired or been invalidated.

### REQ-11: LOGIN-009: Expired or invalid sessions/tokens shall not provide authenticated access.
- [ ] REQ-11.1: A malformed session/token value does not grant authenticated access.
- [ ] REQ-11.2: A tampered (altered) session/token value does not grant authenticated access.

### REQ-12: LOGIN-010: After successful login, the user shall be navigated according to the configured product flow.
- [ ] REQ-12.1: After a successful login, the user is navigated away from the login form to the configured destination.

### REQ-13: LOGIN-011: Failed login shall display an appropriate error without exposing sensitive internal details.
- [ ] REQ-13.1: A failed login attempt displays an appropriate error message.
- [ ] REQ-13.2: A failed-login error message contains no stack trace, raw database error, or internal identifier.

### REQ-14: LOGIN-012: Authentication shall be performed by a trusted server-side mechanism.
- [ ] REQ-14.1: A login request submitted directly to the server (bypassing any client-side logic) with invalid credentials is still rejected by the server.

### REQ-15: BR-LOGIN-001: Only valid credentials for an eligible account may establish an authenticated session.
This business rule restates the same authentication-gate rule already verified under REQ-6/REQ-7/REQ-8. No additional check is added here to avoid duplication.

### REQ-16: BR-LOGIN-002: Passwords shall never be stored or logged in plaintext.
- [ ] REQ-16.1: The submitted Password value is not returned in any login API response, including error responses.
- [ ] REQ-16.2: The issued session/token does not contain the plaintext Password value.

### REQ-17: BR-LOGIN-003: Credentials shall be transmitted securely in non-development environments.
- [ ] REQ-17.1: Login data, including Password, is transmitted over a secure (HTTPS/TLS) connection in the QA environment under test.

### REQ-18: BR-LOGIN-004: Authentication errors should not unnecessarily reveal whether a specific account exists.
- [ ] REQ-18.1: The error shown for an unknown email is the same generic message shown for a correct email with an incorrect password (no distinguishable "account not found" vs. "wrong password" messaging).

### REQ-19: BR-LOGIN-005: The login endpoint shall handle malicious or malformed input safely.
- [ ] REQ-19.1: A login attempt with HTML/JavaScript-like input in Email or Password does not execute as script and does not authenticate.
- [ ] REQ-19.2: A login attempt with SQL-like syntax in Email or Password does not cause a database error and does not bypass authentication.
- [ ] REQ-19.3: A login attempt with malformed input does not produce an unhandled server error (5xx).

### REQ-20: BR-LOGIN-006: Authentication tokens or session identifiers shall not contain passwords or be exposed in URLs.
- [ ] REQ-20.1: The issued session/token value does not contain the plaintext Password value.
- [ ] REQ-20.2: The session/token is not required as a query-string parameter in the URL for a normal authenticated request.

### REQ-21: Important Edge Cases (for grooming/test design coverage): empty email; empty password; unknown email; correct email with incorrect password; email with different letter case; leading/trailing whitespace in email; leading/trailing whitespace in password; very long input; Unicode and special-character input; HTML/JavaScript-like or SQL-like input; rapid repeated login attempts; network or authentication-service failure; page refresh immediately after login; expired, malformed, or tampered session/token.
- [ ] REQ-21.1: Login with the registered email in a different letter case (e.g. all-uppercase) authenticates successfully, same as the original case.
- [ ] REQ-21.2: Login with the registered email padded with leading/trailing whitespace is handled consistently (either matched after trim, or rejected the same generic way as an unknown email — not a crash or distinct error).
- [ ] REQ-21.3: Login with a very long value in Email or Password does not produce a crash or unhandled server error.
- [ ] REQ-21.4: Login with Unicode/special-character input in Email or Password does not produce a crash or unhandled server error, and is rejected the same generic way as any other non-matching credential.
- [ ] REQ-21.5: Repeated rapid login attempts with incorrect credentials do not themselves cause a crash or unhandled server error.
- [ ] REQ-21.6: Refreshing the page immediately after a successful login preserves the authenticated state.

### REQ-22: AC-LOGIN-001 (Successful Login): Given an eligible registered customer exists, when the customer submits the correct email and password, then authentication succeeds and a valid session is established for the correct customer.
- [ ] REQ-22.1: Given an eligible registered customer, submitting the correct email and password succeeds and establishes a session identifying that same customer.

### REQ-23: AC-LOGIN-002 (Invalid Credentials): Given the submitted credentials are incorrect, when login is attempted, then authentication fails, no authenticated session is created, and an appropriate error is displayed.
- [ ] REQ-23.1: Given incorrect credentials, login fails, no authenticated session is created, and an appropriate error is displayed.

### REQ-24: AC-LOGIN-003 (Missing Credentials): Given email or password is missing, when login is submitted, then authentication does not succeed and an appropriate validation error is displayed.
- [ ] REQ-24.1: Given email or password is missing, login does not succeed and an appropriate validation error is displayed.

### REQ-25: AC-LOGIN-004 (Session Persistence): Given the customer successfully logged in, when the customer navigates within the application while the session is valid, then the customer remains authenticated.
- [ ] REQ-25.1: Given a successful login, navigating within the application while the session is valid keeps the customer authenticated.

### REQ-26: AC-LOGIN-005 (Expired Session): Given the customer's session has expired, when authenticated functionality is requested, then authenticated access is rejected and the application follows the configured re-authentication behavior.
- [ ] REQ-26.1: Given an expired (or invalid/tampered, as a practical stand-in — see REQ-11 assumption) session, requesting authenticated functionality is rejected.
- [ ] REQ-26.2: Given the same scenario, the application follows its configured re-authentication behavior (e.g. returns the user to the login form).

### REQ-27: AC-LOGIN-006 (Backend Failure): Given authentication cannot be completed because of a backend failure, when login is attempted, then a controlled error is shown and the user remains unauthenticated.
- [ ] REQ-27.1: Given a backend failure prevents authentication from completing, a controlled error is shown instead of a raw system/server error.
- [ ] REQ-27.2: After such a failure, the user remains unauthenticated.
