import { test, expect } from '@playwright/test';
import { LoginPage } from '../../ui-framework/pages/LoginPage';

// REQ-2c: Login Field — Remember Me (if supported) — the control is
// present and can be toggled.

// TC-REQ-2c.1
test('TC-REQ-2c.1: Remember Me control is present and can be toggled', async ({ page }) => {
  const loginPage = new LoginPage(page);

  await test.step('Locate the Remember Me control', async () => {
    await loginPage.goto();
    await expect(loginPage.rememberMeCheckbox, 'expected the Remember Me control to be visible').toBeVisible();
  });

  await test.step('Toggle the control on', async () => {
    await loginPage.setRememberMe(true);
    await expect(loginPage.rememberMeCheckbox, 'expected the control to reflect the checked state').toBeChecked();
  });

  await test.step('Toggle the control off', async () => {
    await loginPage.setRememberMe(false);
    await expect(loginPage.rememberMeCheckbox, 'expected the control to reflect the unchecked state').not.toBeChecked();
  });
});
