# QAPR-0002 - API Tests

## Prerequisites
- Node.js (any version supported by `@playwright/test` 1.62.x, i.e. 18+)
- The application under test (Juice Shop, `juice-shop-master/`) running and reachable at `http://localhost:3000`
  — either run `juice-shop-master\runme.bat` (starts it, killing anything already on port 3000 first),
  or `npm start` from `juice-shop-master/` manually, in a separate terminal.
- **If your environment routes `localhost` through an HTTP proxy** (confirmed to be the case in the
  sandbox this suite was generated/run in — `HTTP_PROXY` was set globally and a plain request to
  `localhost:3000` was silently intercepted by a corporate Squid proxy instead of reaching the app),
  set `NO_PROXY=localhost,127.0.0.1` (PowerShell: `$env:NO_PROXY = 'localhost,127.0.0.1'`) before
  running `npm install`/`npm test`. Otherwise every request in this suite will fail against the proxy,
  not the app.

## Install

```
cd "QAPR-0002/api-tests"
npm install
```

No `playwright install` step needed — these tests only use Playwright's
`request` fixture (plain HTTP calls), not a browser.

## Run

```
npm test
```

Or run a single file:

```
npx playwright test login-injection-safety.spec.ts
```

## View Report

```
npx playwright show-report
```

Opens the HTML report from the last run in a browser (pass/fail per
test, error details, timing). The config sets `open: 'never'` so
`npm test` won't try to launch it automatically — run this command
afterward whenever you want to look at results.

Every test also attaches the full request/response exchange for each
API call it makes (see `helpers.ts`) — open any test in the report and
its attachments show exactly what was sent and what came back, not
just pass/fail.

## Notes
- Tests create real accounts via `POST /api/Users`. **No cleanup is performed** —
  `DELETE /api/Users/:id` is wired to `security.denyAll()` in this codebase's
  `server.ts` (confirmed by reading the code and empirically: even a request
  carrying a valid bearer token receives 401 `UnauthorizedError`), unlike
  `QAPR-0001/api-tests`, whose reference app snapshot had that endpoint open.
  Every test uses a unique generated email instead of a shared literal so
  re-runs never collide with a previous run's leftover accounts. See
  `summary.md`'s Cleanup Coverage section.
- 3 test cases (TC-REQ-27.1, TC-REQ-27.2) are not included in this run —
  they need a backend fault-injection mechanism that doesn't exist in this
  codebase. 1 test case (TC-REQ-21.5, rapid repeated attempts) was deferred
  by budget-driven curation, not for a discovery reason. See `summary.md`'s
  Selection and Pending sections.
- **Two genuine application security findings** were confirmed by actually
  running this suite — a SQL-injection authentication bypass (TC-REQ-19.2)
  and an unhandled 500 that leaks a full server-side stack trace on a
  malformed password type (TC-REQ-19.3) — plus a third genuine gap, login's
  email lookup being case-sensitive (TC-REQ-21.1). See `summary.md`'s Run
  Results for details; none of these assertions were weakened to force a pass.
- Endpoint/request details for every generated test are in
  `api-mapping.json`.
