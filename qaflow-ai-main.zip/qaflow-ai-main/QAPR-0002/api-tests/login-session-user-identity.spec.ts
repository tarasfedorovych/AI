import { test, expect } from '@playwright/test';
import { attachExchange, uniqueEmail } from './helpers';

// REQ-9: LOGIN-007 — successful authentication establishes a session
// associated with the correct user. Endpoints: POST /api/Users, POST
// /rest/user/login, and GET /rest/user/whoami (reads identity from the
// 'token' cookie, confirmed in routes/currentUser.ts).

const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data]

// TC-REQ-9.1
test('TC-REQ-9.1: The session established after login identifies the same account that authenticated', async ({ request }, testInfo) => {
  const email = uniqueEmail('session-identity');

  // Arrange — precondition: registration was just completed
  const registerBody = { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD };
  const registerResponse = await request.post('/api/Users', { data: registerBody });
  const registerRespBody = await attachExchange(testInfo, 'arrange: register account', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
  expect(registerResponse.status(), `expected 201 Created, got ${registerResponse.status()} - ${JSON.stringify(registerRespBody)}`).toBe(201);

  // Act — log in with the account's credentials
  const loginBody = { email, password: VALID_PASSWORD };
  const loginResponse = await request.post('/rest/user/login', { data: loginBody });
  const loginRespBody = await attachExchange(testInfo, 'act: login', { method: 'POST', url: '/rest/user/login', body: loginBody }, loginResponse);
  expect(loginResponse.status(), `expected 200 OK, got ${loginResponse.status()} - ${JSON.stringify(loginRespBody)}`).toBe(200);
  const token = loginRespBody.authentication.token;

  // Assert — inspect the identity associated with the established session
  const whoamiResponse = await request.get('/rest/user/whoami', { headers: { Cookie: `token=${token}` } });
  const whoamiRespBody = await attachExchange(testInfo, 'assert: whoami identifies the correct account', { method: 'GET', url: '/rest/user/whoami', headers: { Cookie: 'token=<redacted>' } }, whoamiResponse);

  expect(whoamiResponse.status(), `expected 200 OK from whoami, got ${whoamiResponse.status()}`).toBe(200);
  expect(whoamiRespBody.user?.email, `expected the session to identify ${email}, got ${JSON.stringify(whoamiRespBody)}`).toBe(email);
});
