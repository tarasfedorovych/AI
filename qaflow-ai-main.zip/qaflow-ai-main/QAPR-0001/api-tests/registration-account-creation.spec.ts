import { test, expect } from '@playwright/test';
import { attachExchange } from './helpers';

// REQ-11: REG-009 — valid registration data creates exactly one customer
// account, immediately active, default role "customer", no email
// verification/activation step. Endpoints: POST /api/Users
// (swagger.yml: UserCreationResponse -> { status, data: { id, email, role } })
// and POST /rest/user/login (swagger.yml: AuthenticationResponse).
//
// Discovery note: models/user.ts sets role default 'customer' and
// isActive default true at the model level, with no separate
// activation/verification step in the registration code path.
//
// Cleanup runs in `finally` (not just appended after assertions) — an
// earlier version of these tests appended cleanup after the last
// assertion, which meant it never ran if that assertion failed. This
// was confirmed empirically while validating this suite: a legitimately
// failing assertion elsewhere in this run left orphaned accounts.

const NEW_ACCOUNT_PASSWORD = 'Val1dPassw0rd!'; // [test data] valid mandatory data

function uniqueEmail(label: string) {
  return `account-${label}-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per test run
}

// TC-REQ-11.1
test('TC-REQ-11.1: Submitting valid registration data creates exactly one customer account', async ({ request }, testInfo) => {
  const email = uniqueEmail('creation');

  // Act — submit the registration form with valid, unique mandatory data
  const requestBody = { email, password: NEW_ACCOUNT_PASSWORD, passwordRepeat: NEW_ACCOUNT_PASSWORD };
  const response = await request.post('/api/Users', { data: requestBody });
  const body = await attachExchange(testInfo, 'register', { method: 'POST', url: '/api/Users', body: requestBody }, response);
  expect(response.status(), `expected 201 Created, got ${response.status()} - ${JSON.stringify(body)}`).toBe(201);
  const userId = body.data.id;

  try {
    // Assert — exactly one customer account is created
    expect(userId, `expected a created account id in the response, got ${JSON.stringify(body)}`).toBeTruthy();
    expect(body.data.email, `expected response email to equal ${email}, got ${JSON.stringify(body)}`).toBe(email);
  } finally {
    // Cleanup — remove the account created above (DELETE /api/Users/:id, confirmed available)
    await request.delete(`/api/Users/${userId}`);
  }
});

// TC-REQ-11.2
test('TC-REQ-11.2: The newly created account has the default role "customer"', async ({ request }, testInfo) => {
  // Arrange — precondition: registration was just completed with valid data (TC-REQ-11.1)
  const requestBody = { email: uniqueEmail('role'), password: NEW_ACCOUNT_PASSWORD, passwordRepeat: NEW_ACCOUNT_PASSWORD };
  const registerResponse = await request.post('/api/Users', { data: requestBody });
  const body = await attachExchange(testInfo, 'register', { method: 'POST', url: '/api/Users', body: requestBody }, registerResponse);
  expect(registerResponse.status(), `expected 201 Created, got ${registerResponse.status()} - ${JSON.stringify(body)}`).toBe(201);
  const userId = body.data.id;

  try {
    // Assert — account role is "customer" (returned directly by the registration response,
    // the only discovered read-back of a newly created account's role without additional auth)
    expect(body.data.role, `expected role 'customer', got ${JSON.stringify(body)}`).toBe('customer');
  } finally {
    // Cleanup — remove the account created above (DELETE /api/Users/:id, confirmed available)
    await request.delete(`/api/Users/${userId}`);
  }
});

// TC-REQ-11.3
test('TC-REQ-11.3: The newly created account is immediately active without email verification or activation', async ({ request }, testInfo) => {
  // Arrange — precondition: registration was just completed with valid data (TC-REQ-11.1)
  const email = uniqueEmail('active');
  const registerBody = { email, password: NEW_ACCOUNT_PASSWORD, passwordRepeat: NEW_ACCOUNT_PASSWORD };
  const registerResponse = await request.post('/api/Users', { data: registerBody });
  const registerRespBody = await attachExchange(testInfo, 'register', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
  expect(registerResponse.status(), `expected 201 Created, got ${registerResponse.status()} - ${JSON.stringify(registerRespBody)}`).toBe(201);
  const userId = registerRespBody.data.id;

  try {
    // Act — immediately attempt to log in with the newly registered credentials
    const loginBody = { email, password: NEW_ACCOUNT_PASSWORD };
    const loginResponse = await request.post('/rest/user/login', { data: loginBody });
    const loginRespBody = await attachExchange(testInfo, 'login immediately after registration', { method: 'POST', url: '/rest/user/login', body: loginBody }, loginResponse);

    // Assert — login succeeds; account is active immediately upon creation
    expect(loginResponse.status(), `expected 200 OK on immediate login, got ${loginResponse.status()} - ${JSON.stringify(loginRespBody)}`).toBe(200);
    expect(loginRespBody.authentication?.token, `expected an authentication token in the login response, got ${JSON.stringify(loginRespBody)}`).toBeTruthy();
  } finally {
    // Cleanup — remove the account created above (DELETE /api/Users/:id, confirmed available)
    await request.delete(`/api/Users/${userId}`);
  }
});
