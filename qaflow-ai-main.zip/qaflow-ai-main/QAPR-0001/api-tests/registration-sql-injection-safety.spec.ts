import { test, expect } from '@playwright/test';
import { attachExchange } from './helpers';

// REQ-19: BR-REG-005 — user input (Security Answer) must not allow SQL
// injection; it is stored as literal data via a parameterized ORM write.
// Endpoints (swagger.yml): POST /api/Users, GET /api/SecurityQuestions,
// POST /api/SecurityAnswers.
// Discovery note: models/securityAnswer.ts stores `answer` through a
// Sequelize setter (`security.hmac(answer)`) — a parameterized write, not
// string-concatenated SQL — so no database error is expected regardless
// of the answer's content.

const REGISTRATION_EMAIL = `sql-injection-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data]
const REGISTRATION_PASSWORD = 'Val1dPassw0rd!'; // [test data]
const SQL_LIKE_ANSWER = "' OR '1'='1"; // literal from test case

// TC-REQ-19.2
test('TC-REQ-19.2: A Security Answer containing SQL-like syntax is accepted and does not cause a database error', async ({ request }, testInfo) => {
  // Arrange — register an account and fetch a valid security question id
  const registerBody = { email: REGISTRATION_EMAIL, password: REGISTRATION_PASSWORD, passwordRepeat: REGISTRATION_PASSWORD };
  let userId!: number;
  await test.step('Arrange: register account', async () => {
    const registerResponse = await request.post('/api/Users', { data: registerBody });
    const respBody = await attachExchange(testInfo, 'register', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
    expect(registerResponse.status(), `expected 201 Created, got ${registerResponse.status()} - ${JSON.stringify(respBody)}`).toBe(201);
    userId = respBody.data.id;
  });

  try {
    let securityQuestionId!: number;
    await test.step('Arrange: fetch a security question id', async () => {
      const questionsResponse = await request.get('/api/SecurityQuestions');
      const questionsBody = await attachExchange(testInfo, 'list security questions', { method: 'GET', url: '/api/SecurityQuestions' }, questionsResponse);
      expect(questionsResponse.ok(), `expected security questions list to be retrievable, got ${questionsResponse.status()} - ${JSON.stringify(questionsBody)}`).toBeTruthy();
      securityQuestionId = questionsBody.data[0].id;
    });

    await test.step('Act & Assert: submit a SQL-like security answer', async () => {
      // Act — enter a Security Answer containing SQL-like syntax, submit with valid mandatory data otherwise
      const answerBody = { SecurityQuestionId: securityQuestionId, UserId: userId, answer: SQL_LIKE_ANSWER };
      const answerResponse = await request.post('/api/SecurityAnswers', { data: answerBody });
      const answerRespBody = await attachExchange(testInfo, 'submit SQL-like security answer', { method: 'POST', url: '/api/SecurityAnswers', body: answerBody }, answerResponse);

      // Assert — registration completes without a database error or unintended query behavior;
      // the value is stored as literal data
      expect(answerResponse.status(), `expected 201 Created for a SQL-like security answer (no database error), got ${answerResponse.status()} - ${JSON.stringify(answerRespBody)}`).toBe(201);
      expect(answerRespBody.status, `expected response status field 'success', got ${JSON.stringify(answerRespBody)}`).toBe('success');
    });
  } finally {
    // Cleanup — remove the account created above (DELETE /api/Users/:id, confirmed available)
    await request.delete(`/api/Users/${userId}`);
  }
});
