import { test, expect } from '@playwright/test';
import { attachExchange, uniqueEmail } from './helpers';

// REQ-21: Important edge cases — letter case, whitespace padding, very long
// input, and Unicode/special-character input in the login Email field.
// Endpoints: POST /api/Users (arrange), POST /rest/user/login (act).

const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data]

// TC-REQ-21.1
test('TC-REQ-21.1: Login with the registered email in a different letter case authenticates the same as the original case', async ({ request }, testInfo) => {
  const email = uniqueEmail('case-sensitivity'); // registered in lowercase

  const registerBody = { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD };
  const registerResponse = await request.post('/api/Users', { data: registerBody });
  const registerRespBody = await attachExchange(testInfo, 'arrange: register account (lowercase email)', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
  expect(registerResponse.status(), `expected 201 Created, got ${registerResponse.status()} - ${JSON.stringify(registerRespBody)}`).toBe(201);

  // Act — submit login with the registered email in all-uppercase
  const loginBody = { email: email.toUpperCase(), password: VALID_PASSWORD };
  const response = await request.post('/rest/user/login', { data: loginBody });
  const bodyText = await response.text();
  await attachExchange(testInfo, 'login with uppercase email', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);

  // GENUINE FINDING, confirmed by running this test: routes/login.ts's raw
  // SQL lookup compares `email = '<value>'` with no case normalization, so
  // the uppercased email does not match the stored (as-registered) row —
  // login is rejected (401) instead of succeeding. This test case assumes
  // login should behave case-insensitively on email, a reasonable reading
  // of the source document's edge-case list, which the implementation does
  // not satisfy. The assertion is left as written (expecting success)
  // rather than weakened.
  expect(response.status(), `expected 200 (case-insensitive email match) — got ${response.status()} - ${bodyText} (known gap: routes/login.ts's raw SQL email lookup is case-sensitive, no normalization)`).toBe(200);
});

// TC-REQ-21.2
test('TC-REQ-21.2: Login with the registered email padded with leading/trailing whitespace is handled consistently', async ({ request }, testInfo) => {
  const email = uniqueEmail('whitespace-padding');

  const registerBody = { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD };
  const registerResponse = await request.post('/api/Users', { data: registerBody });
  const registerRespBody = await attachExchange(testInfo, 'arrange: register account', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
  expect(registerResponse.status(), `expected 201 Created, got ${registerResponse.status()} - ${JSON.stringify(registerRespBody)}`).toBe(201);

  // Act — submit login with the email padded with leading/trailing whitespace
  const loginBody = { email: `  ${email}  `, password: VALID_PASSWORD };
  const response = await request.post('/rest/user/login', { data: loginBody });
  const bodyText = await response.text();
  await attachExchange(testInfo, 'login with whitespace-padded email', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);

  // Confirmed by running: the implementation rejects (401) rather than
  // trimming — one of the two flexible outcomes this test case allows, so
  // this assertion passes. Either way, no crash may occur.
  expect([200, 401].includes(response.status()), `expected either 200 (trimmed and matched) or 401 (rejected generically), got ${response.status()} - ${bodyText}`).toBe(true);
  expect(response.status(), 'expected no unhandled server error (5xx)').toBeLessThan(500);
});

// TC-REQ-21.3
test('TC-REQ-21.3: Very long input in Email or Password does not cause a crash or unhandled server error', async ({ request }, testInfo) => {
  const longEmail = `${'a'.repeat(10000)}@example.com`; // [test data, 10,000-character local part]

  const loginBody = { email: longEmail, password: 'anyPassword1' };
  const response = await request.post('/rest/user/login', { data: loginBody });
  const bodyText = await response.text();
  await attachExchange(testInfo, 'login with a very long email', { method: 'POST', url: '/rest/user/login', body: { email: `[10000 chars]@example.com`, password: loginBody.password } }, response);

  expect(response.status(), `expected 401 (rejected in a controlled way), got ${response.status()} - ${bodyText.slice(0, 200)}`).toBe(401);
});

// TC-REQ-21.4
test('TC-REQ-21.4: Unicode/special-character input in Email or Password does not cause a crash and is rejected generically', async ({ request }, testInfo) => {
  const unicodeEmail = 'пошта@example.com'; // [test data]

  const loginBody = { email: unicodeEmail, password: 'anyPassword1' };
  const response = await request.post('/rest/user/login', { data: loginBody });
  const bodyText = await response.text();
  await attachExchange(testInfo, 'login with a Unicode email', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);

  expect(response.status(), `expected 401 (rejected the same generic way as any other non-matching credential), got ${response.status()} - ${bodyText}`).toBe(401);
});
