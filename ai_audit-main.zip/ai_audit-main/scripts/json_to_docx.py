#!/usr/bin/env python3
"""
json_to_docx.py
Convert a test-audit JSON report into a DOCX report.

Usage:
  python json_to_docx.py input.json output.docx

Requires:
  pip install python-docx
"""
from __future__ import annotations
import json
import sys
from docx import Document
from docx.shared import Pt

def add_bullets(doc: Document, items):
    if not items:
        doc.add_paragraph("None", style="List Bullet")
        return
    for i in items:
        doc.add_paragraph(str(i), style="List Bullet")

def add_code_block(doc: Document, code: str):
    p = doc.add_paragraph()
    run = p.add_run(code.rstrip())
    font = run.font
    font.name = "Consolas"
    font.size = Pt(9)

def main():
    if len(sys.argv) != 3:
        print("Usage: python json_to_docx.py input.json output.docx", file=sys.stderr)
        sys.exit(2)

    in_path, out_path = sys.argv[1], sys.argv[2]
    with open(in_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    doc = Document()
    doc.add_heading("Test Automation Audit Report", level=0)

    meta = data.get("meta", {})
    target = meta.get("target", {})
    exec_sum = data.get("executive_summary", {})

    repo = target.get("repo", "")
    ref_type = target.get("ref_type", "")
    ref_id = target.get("ref_id", "")
    generated_at = meta.get("generated_at", "")
    tz = meta.get("timezone", "")

    if repo or (ref_type and ref_id):
        doc.add_paragraph(f"Target: {repo} {ref_type.upper()}-{ref_id}".strip())
    if generated_at:
        doc.add_paragraph(f"Generated: {generated_at} ({tz})" if tz else f"Generated: {generated_at}")

    doc.add_heading("Executive summary", level=1)
    doc.add_paragraph(f"Overall score: {exec_sum.get('overall_score', 0)}/100")
    doc.add_paragraph(f"Risk level: {exec_sum.get('risk_level', 'unknown')}")
    if exec_sum.get("headline"):
        doc.add_paragraph(f"Headline: {exec_sum.get('headline')}")

    highlights = exec_sum.get("highlights", {}) or {}
    doc.add_heading("Highlights", level=2)
    doc.add_paragraph("Strengths:")
    add_bullets(doc, highlights.get("strengths", []))
    doc.add_paragraph("Top risks:")
    add_bullets(doc, highlights.get("top_risks", []))
    doc.add_paragraph("Quick wins:")
    add_bullets(doc, highlights.get("quick_wins", []))

    doc.add_heading("Scorecard", level=1)
    # Support both new format (scorecard.areas) and old format (scorecard as array)
    scorecard_data = data.get("scorecard", []) or []
    if isinstance(scorecard_data, dict):
        scorecard = scorecard_data.get("areas", [])
    else:
        scorecard = scorecard_data
    
    if scorecard:
        table = doc.add_table(rows=1, cols=4)
        hdr = table.rows[0].cells
        hdr[0].text = "Area"
        hdr[1].text = "Score"
        hdr[2].text = "Risk"
        hdr[3].text = "Rationale"
        for s in scorecard:
            row = table.add_row().cells
            row[0].text = str(s.get("area_name", s.get("area_id", "")))
            row[1].text = str(s.get("score", 0))
            row[2].text = str(s.get("risk_level", "unknown"))
            row[3].text = str(s.get("rationale", "")).replace("\n", " ")
    else:
        doc.add_paragraph("No scorecard data.")

    doc.add_heading("Findings", level=1)
    findings = data.get("findings", []) or []
    if not findings:
        doc.add_paragraph("No findings.")
    else:
        order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
        findings.sort(key=lambda f: (order.get((f.get("severity") or "info").lower(), 99), f.get("id","")))

        for fnd in findings:
            sev = (fnd.get("severity") or "info").lower()
            fid = fnd.get("id", "UNKNOWN")
            ttl = fnd.get("title", "")
            doc.add_heading(f"{fid}: {ttl}", level=2)
            doc.add_paragraph(f"Severity: {sev}")
            doc.add_paragraph(f"Risk: {fnd.get('risk_level','unknown')}")
            doc.add_paragraph(f"Area: {fnd.get('area_id','')}")
            doc.add_paragraph(f"Category: {fnd.get('category','')}")
            effort_line = f"Effort: {fnd.get('effort','unknown')}"
            if isinstance(fnd.get("effort_days"), (int,float)):
                effort_line += f" (~{fnd.get('effort_days')} day(s))"
            doc.add_paragraph(effort_line)
            if fnd.get("confidence") is not None:
                doc.add_paragraph(f"Confidence: {fnd.get('confidence')}")

            if fnd.get("issue"):
                doc.add_heading("Issue", level=3)
                doc.add_paragraph(str(fnd.get("issue")))
            if fnd.get("impact"):
                doc.add_heading("Impact", level=3)
                doc.add_paragraph(str(fnd.get("impact")))

            doc.add_heading("Evidence", level=3)
            evidence = fnd.get("evidence") or []
            if not evidence:
                doc.add_paragraph("No evidence captured.")
            else:
                for e in evidence:
                    fp = e.get("file_path","unknown")
                    ls = e.get("line_start","?")
                    le = e.get("line_end","?")
                    ctx = e.get("context")
                    doc.add_paragraph(f"{fp}:{ls}-{le}" + (f" — {ctx}" if ctx else ""))
                    snippet = e.get("code_snippet")
                    if snippet:
                        add_code_block(doc, str(snippet))

            doc.add_heading("Recommendation", level=3)
            rec = fnd.get("recommendation") or {}
            # Support both string format and dict format for recommendations
            if isinstance(rec, str):
                doc.add_paragraph(rec)
            elif not rec:
                doc.add_paragraph("No recommendation provided.")
            else:
                if rec.get("recommendation_summary"):
                    doc.add_paragraph(str(rec.get("recommendation_summary")))
                wtd = rec.get("what_to_do") or []
                if wtd:
                    doc.add_paragraph("What to do:")
                    add_bullets(doc, wtd)
                ex = rec.get("example_fix") or []
                if ex:
                    doc.add_paragraph("Example fix:")
                    for item in ex:
                        lang = item.get("language","")
                        doc.add_paragraph(f"Language: {lang}")
                        add_code_block(doc, str(item.get("code","")))
                tr = rec.get("tradeoffs") or []
                if tr:
                    doc.add_paragraph("Tradeoffs:")
                    add_bullets(doc, tr)

    doc.add_heading("Anti-patterns found", level=1)
    anti = data.get("anti_patterns_found", []) or []
    if not anti:
        doc.add_paragraph("None detected.")
    else:
        for ap in anti:
            doc.add_heading(ap.get("name","Unknown"), level=2)
            doc.add_paragraph(f"Count: {ap.get('count',0)}")
            doc.add_paragraph(f"Severity: {ap.get('severity','unknown')}")
            if ap.get("description"):
                doc.add_paragraph(str(ap.get("description")))
            if ap.get("recommended_replacement"):
                doc.add_paragraph(f"Recommended replacement: {ap.get('recommended_replacement')}")

    doc.add_heading("Coverage insights", level=1)
    cov = data.get("coverage_insights", {}) or {}
    test_types = cov.get("test_types", []) or []
    if test_types:
        table = doc.add_table(rows=1, cols=3)
        hdr = table.rows[0].cells
        hdr[0].text = "Type"
        hdr[1].text = "Count"
        hdr[2].text = "Notes"
        for t in test_types:
            row = table.add_row().cells
            row[0].text = str(t.get("type",""))
            row[1].text = str(t.get("count",0))
            row[2].text = str(t.get("notes",""))
    else:
        doc.add_paragraph("No test type info.")

    gaps = cov.get("gaps", []) or []
    doc.add_heading("Gaps", level=2)
    if not gaps:
        doc.add_paragraph("No gaps recorded.")
    else:
        for g in gaps:
            doc.add_paragraph(f"{g.get('gap_id','GAP')} ({g.get('severity','unknown')}): {g.get('description','')}", style="List Bullet")

    doc.add_heading("Test management integration", level=1)
    tms = data.get("test_management_integration", {}) or {}
    doc.add_paragraph(f"References present: {tms.get('presence_of_reference_to_test_management_system','unknown')}")
    systems = tms.get("systems_detected", []) or []
    if systems:
        doc.add_paragraph("Systems detected: " + ", ".join(systems))
    refs = tms.get("references_detected", []) or []
    if refs:
        doc.add_heading("References detected", level=2)
        for r in refs:
            examples = ", ".join(r.get("examples", []) or [])
            doc.add_paragraph(f"{r.get('system','')} pattern {r.get('pattern','')} examples: {examples}", style="List Bullet")

    doc.add_heading("Documentation quality", level=1)
    docq = data.get("documentation_quality", {}) or {}
    doc.add_paragraph(f"How well documented: {docq.get('how_well_documented','unknown')}")
    doc.add_paragraph(f"Score: {docq.get('score',0)}/100")
    doc.add_heading("Documentation gaps", level=2)
    add_bullets(doc, docq.get("gaps", []) or [])
    drec = docq.get("recommendations", []) or []
    if drec:
        doc.add_heading("Documentation recommendations", level=2)
        for r in drec:
            # Handle both string and dict recommendations
            if isinstance(r, str):
                doc.add_paragraph(r, style="List Bullet")
            else:
                doc.add_paragraph(f"{r.get('title','')} (effort: {r.get('effort','S')}, days: {r.get('effort_days','1')})", style="List Bullet")

    doc.add_heading("Action plan", level=1)
    ap = data.get("action_plan", []) or []
    if not ap:
        doc.add_paragraph("No action plan.")
    else:
        for item in ap:
            doc.add_heading(f"P{item.get('priority','?')}: {item.get('title','')}", level=2)
            if item.get("goal"):
                doc.add_paragraph(f"Goal: {item.get('goal')}")
            if item.get("expected_impact"):
                doc.add_paragraph(f"Expected impact: {item.get('expected_impact')}")
            tasks = item.get("tasks", []) or []
            if tasks:
                doc.add_heading("Tasks", level=3)
                for t in tasks:
                    if isinstance(t, str):
                        doc.add_paragraph(t, style="List Bullet")
                    else:
                        doc.add_paragraph(
                            f"[{t.get('task_id','')}] {t.get('description','')} "
                            f"(owner: {t.get('owner_role','')}, days: {t.get('effort_days','?')})",
                            style="List Bullet"
                        )

    doc.add_heading("Appendix", level=1)
    appendix = data.get("appendix", {})
    add_code_block(doc, json.dumps(appendix, indent=2, ensure_ascii=False))

    doc.save(out_path)

if __name__ == "__main__":
    main()
