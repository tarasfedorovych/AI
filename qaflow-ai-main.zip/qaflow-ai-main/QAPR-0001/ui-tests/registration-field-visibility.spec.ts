import { test, expect } from '@playwright/test';
import { RegistrationPage } from '../../ui-framework/pages/RegistrationPage';

// TC-REQ-3.1
test('TC-REQ-3.1: Unauthenticated visitor can view and interact with all registration fields', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);

  await test.step('Navigate to the registration page', async () => {
    await registrationPage.goto();
  });

  await test.step('Verify Email field', async () => {
    await expect(registrationPage.emailInput, 'expected the Email field to be visible').toBeVisible();
    await registrationPage.fillEmail('visitor@example.com'); // [test data]
    await expect(registrationPage.emailInput, 'expected the Email field to accept input').toHaveValue('visitor@example.com');
  });

  await test.step('Verify Password field', async () => {
    await expect(registrationPage.passwordInput, 'expected the Password field to be visible').toBeVisible();
    await registrationPage.fillPassword('Str0ngP@ssw0rd!'); // [test data]
    await expect(registrationPage.passwordInput, 'expected the Password field to accept input').toHaveValue('Str0ngP@ssw0rd!');
  });

  await test.step('Verify Confirm Password field', async () => {
    await expect(registrationPage.repeatPasswordInput, 'expected the Confirm Password field to be visible').toBeVisible();
    await registrationPage.fillRepeatPassword('Str0ngP@ssw0rd!'); // [test data]
    await expect(registrationPage.repeatPasswordInput, 'expected the Confirm Password field to accept input').toHaveValue('Str0ngP@ssw0rd!');
  });

  await test.step('Verify Security Question field', async () => {
    await expect(registrationPage.securityQuestionSelect, 'expected the Security Question field to be visible').toBeVisible();
    const selectedQuestion = await registrationPage.selectFirstSecurityQuestion();
    await expect(
      registrationPage.securityQuestionSelect,
      'expected a question to be selected in the Security Question field'
    ).toContainText(selectedQuestion);
  });

  await test.step('Verify Security Answer field', async () => {
    await expect(registrationPage.securityAnswerInput, 'expected the Security Answer field to be visible').toBeVisible();
    await registrationPage.fillSecurityAnswer('TestAnswer123'); // [test data]
    await expect(registrationPage.securityAnswerInput, 'expected the Security Answer field to accept input').toHaveValue('TestAnswer123');
  });
});
