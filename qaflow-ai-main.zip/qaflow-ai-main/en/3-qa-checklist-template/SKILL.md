---
name: qa-checklist
description: >
  Third stage of task processing. Takes the requirements file created by the
  requirements-grooming skill, decomposes each requirement into atomic checks
  and creates a reference QA checklist — input for test cases and for manual
  testing. Use when the user says "build checklist", "make checklist",
  "checklist of checks", or after requirements grooming completion.
---

# QA Checklist

> ⚙️ Recommended settings: **Sonnet · Effort: Medium · Extended thinking: Off**

Decomposes numbered requirements into atomic checks
and creates a reference QA checklist — input for test cases
and for manual testing.

## Input Data

Input — file `<ISSUEKEY>/requirements.md` created by the
requirements-grooming skill. In the same chat, the file is available in the
`<ISSUEKEY>/` folder automatically. If the chat is new — the user
uploads the file to the chat.

Data sources for this skill:
- requirements file — single source of truth for requirements.
- user responses to questions before checklist generation.

First, read the requirements file completely. If something
in the requirements is unclear or ambiguous for building
checks — ask the user before starting generation.
Do not start generation while there are unresolved questions.

Do not go to the tracker, do not use external tools,
do not search the internet, do not inspect code.

Requirements file — read-only.
Do not change, do not rewrite, do not clear its contents.

If the requirements file is missing, empty, or corrupted —
stop and inform the user that the requirements-grooming
skill needs to be executed first.

## Rules

- All communication and all output file content — in English.
- Chat messages — brief.
- Checklist is built only from what is in the requirements file.
  Do not assume, do not supplement, do not interpret requirements yourself.
  Do not invent routes, selectors, roles, states, data, or expected
  behavior not in requirements.
- Do not change sense and wording of requirements. Skill decomposes
  requirements into checks, but does not rewrite or improve
  the requirements themselves.
- If requirement was left unchanged after grooming
  (user skipped question in skill 2) — build checklist
  on what exists. Do not skip such requirement or mark
  it as incomplete. Requirements file — final.
- Do not add general QA advice not tied
  to specific requirement of the task.
- After saving file — stop. Do not continue
  to code review, test cases, or planning.

## Numbering

Checklist items inherit requirement IDs from the requirements file.

Order of requirements in the checklist must match the order of requirements
in the requirements file. Do not change, do not rearrange,
do not group requirements differently than they go in the file.

One requirement may produce several checks. Each check
gets a sub-number with period: REQ-3.1, REQ-3.2, REQ-3.3.

Main number REQ-* does not change — it is the same
as in the requirements file and further in code review.

Sub-numbering is sequential, without gaps,
in order as checks appear in the checklist.

If requirement already has sub-items (REQ-5a, REQ-5b) —
each sub-item is numbered separately: REQ-5a.1, REQ-5a.2,
REQ-5b.1, REQ-5b.2.

## Checklist Building Method

Quality rules, decomposition, wording, check types,
filtering unnecessary, basic sets for typical elements,
and anti-patterns — in references/checklist-design-rules.md.

Read this file before starting checklist generation.

## Verification Before Saving

After checklist generation and before saving the file:

1. Pass the checklist through filtering of unnecessary checks.
2. Go through the checklist and verify:

- Each requirement from the requirements file has at least one
  check in the checklist. If a requirement has no checks —
  add one or explain why it is not possible.
- No checklist items without REQ-ID.
- Order of requirements in the checklist matches the order
  in the requirements file.
- No duplication: the same check does not appear twice.
- Similar items have the same basic set of checks.
- Each item is atomic: one check, one pass/fail.
- Each item is self-contained: understandable without opening
  the requirements file.
- No checks for behavior not in the requirements.

If a problem is found — fix it before saving.

## Output File

Create the folder <ISSUEKEY>/ in the working directory if it does not
exist, then create file checklist.md inside it, and give it to the
user for upload.

The file remains in <ISSUEKEY>/ — the next skill in the same chat
takes it automatically.

If the file already exists — delete it completely and create a new one.
On output always one file with the result of the last run.
Do not merge with the previous version, do not append, do not save
data from the previous run.

Before finishing, verify:
- One top-level heading
- One coherent checklist without duplicate sections

File structure template — in references/output-template.md.
Example of detail level — in references/checklist-example.md.

## Final Response

After saving the file, inform:
- Path to the saved file
- Number of checklist items
