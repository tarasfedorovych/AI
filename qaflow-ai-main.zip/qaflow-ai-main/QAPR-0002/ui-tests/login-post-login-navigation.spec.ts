import { test, expect } from '@playwright/test';
import { LoginPage } from '../../ui-framework/pages/LoginPage';

// REQ-12: LOGIN-010 — after successful login, the user is navigated
// according to the configured product flow. login.component.ts's login()
// resolves the destination as `route.snapshot.queryParamMap.get('redirectUrl')
// ?? '/search'` — confirmed in the codebase, so the default destination
// (no redirectUrl query param) is the product listing at /#/search.

const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data]

function uniqueEmail(label: string) {
  return `ui-${label}-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per run
}

// TC-REQ-12.1
test('TC-REQ-12.1: Successful login navigates the user away from the login form', async ({ page }) => {
  const loginPage = new LoginPage(page);
  const email = uniqueEmail('post-login-nav');

  await test.step('Precondition: a registered account exists (seeded directly via the API, not through the UI)', async () => {
    await page.request.post('/api/Users', { data: { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD } });
  });

  await test.step('Submit the login form with valid credentials', async () => {
    await loginPage.goto();
    await loginPage.login(email, VALID_PASSWORD);
  });

  await test.step('Verify the user is navigated away from the login form to the configured destination', async () => {
    await expect(
      page,
      'expected the app to navigate away from /#/login to its default post-login destination (/#/search)'
    ).toHaveURL(/#\/search/);
  });
});
