import { test, expect } from '@playwright/test';
import { LoginPage } from '../../ui-framework/pages/LoginPage';

// REQ-3: LOGIN-001 — an unauthenticated visitor can view and interact with
// the login fields.

// TC-REQ-3.1
test('TC-REQ-3.1: Unauthenticated visitor can view and interact with the login fields', async ({ page }) => {
  const loginPage = new LoginPage(page);
  await loginPage.goto();

  await test.step('Verify Email field', async () => {
    await expect(loginPage.emailInput, 'expected the Email field to be visible').toBeVisible();
    await loginPage.fillEmail('visitor@example.com'); // [test data]
    await expect(loginPage.emailInput, 'expected the Email field to accept input').toHaveValue('visitor@example.com');
  });

  await test.step('Verify Password field', async () => {
    await expect(loginPage.passwordInput, 'expected the Password field to be visible').toBeVisible();
    await loginPage.fillPassword('anyPassword1'); // [test data]
    await expect(loginPage.passwordInput, 'expected the Password field to accept input').toHaveValue('anyPassword1');
  });

  await test.step('Verify submit control', async () => {
    await expect(loginPage.loginButton, 'expected the Login submit control to be visible').toBeVisible();
  });
});
