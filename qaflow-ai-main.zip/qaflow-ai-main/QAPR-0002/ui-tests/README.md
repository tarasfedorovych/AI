# QAPR-0002 - UI Tests

## Prerequisites
- Node.js 18+ (any version supported by `@playwright/test` 1.62.x)
- The application under test (Juice Shop, `juice-shop-master/`) running and reachable at `http://localhost:3000`
  — either run `juice-shop-master\runme.bat` (starts it, killing anything already on port 3000 first),
  or `npm start` from `juice-shop-master/` manually, in a separate terminal.
- **If your environment routes `localhost` through an HTTP proxy** (confirmed to be the case in the
  sandbox this suite was generated/run in), set `NO_PROXY=localhost,127.0.0.1` before running
  `npm install`/`npx playwright install`/`npx playwright test` — see `QAPR-0002/api-tests/README.md`
  for the full explanation.

## Install

```
cd "QAPR-0002/ui-tests"
npm install
npx playwright install chromium
```

## Run

```
npx playwright test --workers=1
```

`--workers=1` is required, not just recommended: the default parallel-worker
run against this single Juice Shop dev-mode instance produced **7 of 13
tests failing** in this run — confirmed to be dev-server contention under
concurrent browser load (the same class of issue `QAPR-0001/ui-tests`
documents for its own suite), not a test defect. `npm test` runs the
default (parallel) config if you want to reproduce that.

Or run a single file:

```
npx playwright test login-page-access.spec.ts
```

## View Report

```
npx playwright show-report
```

Opens the HTML report from the last run. Failing tests include a trace,
a screenshot, and a video — open the trace to scrub through the exact
DOM/network/console state at each test.step.

## Notes
- Page Objects used by these tests live in the shared `ui-framework/pages/`
  folder at the repository root, not inside this folder — they're reused
  across issues targeting the same app. `LoginPage` (already existing from
  `QAPR-0001`) was extended with additional locators/methods this run
  needed (Remember Me, required-field errors, the generic invalid-
  credentials error, and an `isAuthenticated()` helper) — nothing existing
  was removed or renamed.
- Every account these tests need is seeded via a direct API call
  (`page.request.post('/api/Users', ...)`), not through the registration
  UI, since account creation is not what any of these TC-REQs exercise.
  **No cleanup is performed** for the same reason documented in
  `QAPR-0002/api-tests/summary.md`: `DELETE /api/Users/:id` is wired to
  `security.denyAll()` in this codebase and unconditionally rejects every
  request.
- All 13 UI-classified TC-REQs selected for this run were generated — none
  deferred by budget (see `summary.md`'s Selection section for why the
  budget allowed generating the full UI-classified set here, unlike the
  API suite).
- All 13 tests pass consistently with `--workers=1` (run 3 times). See
  `summary.md`'s Run Results for two discovery-driven fixes made while
  actually running the suite (not visible from reading the generated code
  alone) — neither is an application defect.
