---
name: manual-testing
description: >
  Tenth stage of task processing (optional, run independently
  after code-review and/or ui-tests). Takes QA and FAIL points
  from code review, Manual/Not-automatable rows from automation
  strategy, and anything left deferred or pending by the ui-tests
  skill, executes them in browser via Chrome extension, verifies
  expected results and forms a detailed report — the manual/
  exploratory safety net for whatever automation didn't cover, to
  mitigate the risk of shipping those points unverified. Use when
  user says "manual testing", "test in browser", "go through QA
  points", "exploratory testing", or after completing code review.
---

# Manual Testing

> Recommended settings: **Sonnet · Effort: High · Extended thinking: Off**

Executes in a real browser whatever still needs a human-style pass:
QA and FAIL points from code review, Manual/Not-automatable test
cases from automation strategy, and any UI test case the ui-tests
skill deferred or left pending. QA — points that cannot be checked
by code. FAIL — points that code review identified as problematic,
require verification in UI that bug really exists. Manual/Not-
automatable and deferred/pending — test cases nothing else in the
pipeline has verified yet. Input — code review, test cases, and
optionally automation-strategy and ui-tests summary files. Output —
detailed report with results of each test case executed in UI.

## Input Data

From the user needed:
1. Code review file `<ISSUEKEY>/code-review.md` created
   by code-review skill. In the same chat, the file is available
   in the `<ISSUEKEY>/` folder automatically. If the chat is new —
   user uploads the file to the chat.
2. Test cases file `<ISSUEKEY>/test-cases.md` created
   by qa-test-cases skill. In the same chat available automatically.

Optional input:
- Checklist file `<ISSUEKEY>/checklist.md` — for structural
  checks that were not included in test cases.
- Automation strategy file `<ISSUEKEY>/automation-strategy.md` —
  used to pull in every TC-REQ classified `Manual/Not automatable`,
  as additional scope for this skill (they have no code-review
  verdict, see Classification below for how they're scored).
- UI tests summary file `<ISSUEKEY>/ui-tests/summary.md` — used to
  pull in every TC-REQ listed there as "Deferred by user" or
  "Pending — discovery needed", as additional scope for this skill.

If code review file is not provided — ask before starting.
If test cases file is not provided — ask before starting.
If automation-strategy.md or ui-tests/summary.md are not provided —
proceed without them; simply skip that additional scope.
If any file is empty or corrupted — stop
and inform the user.

Data sources for this skill:
- code-review file — source of QA and FAIL points
- test-cases file — source of steps, test data
  and expected results
- checklist file (optional) — structural checks
- automation-strategy file (optional) — source of Manual/Not-
  automatable points
- ui-tests summary file (optional) — source of deferred/pending UI
  automation points
- UI of the product via Chrome extension — source of actual
  results
- navigation_paths.json — memory of navigation paths
- references/login-config.md — login instructions

All input files are read-only.
Do not modify, do not rewrite, do not clean their content.

Do not go to the tracker, do not use external tools,
do not inspect code.

## Rules

- All communication and all output file content — in English.
- Messages in chat are short.
- Browser tool: Claude in Chrome extension.
  Do not use Playwright MCP.
- Test cases with PASS and N/A statuses in code review
  are not executed in the browser. Only QA and FAIL are executed.
- Do not change data in the system without a direct test case step
  that requires this change. If the step says "enter value" —
  enter. If it doesn't say — don't enter. Do not create records,
  do not delete data, do not change settings if this
  is not an explicit step of the test case.
- Test data is taken from the "Test Data" column of the test case table.
  If there is a specific value — use it literally. If marked as
  `[test data]` with a realistic example — use that example.
  Do not make up test data yourself.
- After saving the file — stop. Do not continue
  to the next skills or planning.

## Chrome Extension Tools

To work with the browser, use these tools:

- **navigate** — navigate to URL.
- **find** — search for element on the page by natural language description.
  Main way to find elements.
- **read_page** — get page structure (accessibility
  tree). With `filter: "interactive"` — only interactive
  elements (buttons, fields, links).
- **computer** with `action: "screenshot"` — take screenshot.
  Use only as proof for FAIL
  and FAIL CONFIRMED. Do not take screenshots for PASS.
- **computer** with `action: "left_click"` — click on element.
- **computer** with `action: "type"` — enter text.
- **computer** with `action: "key"` — press key.
- **computer** with `action: "scroll"` — scroll page.
- **form_input** — set form field value by ref.
- **get_page_text** — get page text.
- **tabs_context_mcp** — get list of tabs.

Full interaction rules — in references/browser-rules.md.

## Workflow Order

### Step 1 — Gather Scope

Read `<ISSUEKEY>/code-review.md`. Find all test cases
with `QA` or `FAIL` status in the results table.
This is the base working list for execution in the browser.

- `QA` — requires manual verification because code review
  could not verify from code.
- `FAIL` — code review found a problem from code,
  need to confirm or refute in UI.

Test cases with PASS and N/A statuses in code review
are not included from this source — they are already verified from code.

If `<ISSUEKEY>/automation-strategy.md` was provided, add every TC-REQ
classified `Manual/Not automatable` there to the working list (source
tag: `MANUAL-STRATEGY`).

If `<ISSUEKEY>/ui-tests/summary.md` was provided, add every TC-REQ
listed under "Deferred by user" or "Pending — discovery needed" there
to the working list (source tag: `UI-DEFERRED` / `UI-PENDING`).

A TC-REQ already in scope from code review keeps its `QA`/`FAIL` tag
even if it also appears in one of the optional files — do not add it
twice.

Then read `<ISSUEKEY>/test-cases.md`. For each
test case in the working list extract full data:
- Precondition
- Table of steps (step, test data, expected result)
- Postcondition (if any)

For FAIL points additionally extract finding from code review:
file, line, what was expected, what actually in the code.
This information will help understand what exactly to check in UI.

If there are no points in scope from any source — inform
user that there are no points for manual testing and stop.

Inform user briefly:
```
Scope: [N] test cases for execution in browser.
- QA (check in UI): [N]
- FAIL (verify bug): [N]
- Manual/Not automatable (automation strategy): [N]
- Deferred/Pending (ui-tests): [N]
Starting.
```

### Step 2 — Determine Target Pages

From test cases determine which pages or sections of the product
are needed. Usually visible from preconditions or
from test case names.

Group test cases by pages. If all test cases
are about one page — one group. If different
pages — several groups, execute sequentially by groups.

For the first (or only) group extract `TARGET_PAGE_NAME`.

### Step 3 — Check Navigation Memory

Read `navigation_paths.json` from the working directory.
If the file does not exist — create an empty structure:
```json
{"navigation_paths": {}}
```

Search for `TARGET_PAGE_NAME` as a key in `navigation_paths`.

**If found:**
- Extract `url` — direct URL if available.
- Extract `login_required` — whether login is needed.
- Extract `navigation_steps` — array of navigation steps.
- Set `PATH_EXISTS = true`.

**If not found:**
- Set `PATH_EXISTS = false`.

### Step 4 — Login (if needed)

Read `references/login-config.md` from the skill directory.

**If the file is filled** (contains URL, field descriptions,
credentials source):
- Execute login according to instructions from the file.
- Login rules — in references/browser-rules.md,
  section "Login".

**If the file is not filled** (contains placeholders
`<login page URL>`, `<how to find field>` etc)
or the file is missing:
- Ask user: login URL, where username
  and password fields are, which button is submit, where credentials come from.
- Execute login according to user instructions.

### Step 5 — Navigate to Target Page

**If `PATH_EXISTS = true`:**
Execute each step from `navigation_steps` sequentially,
following rules from references/browser-rules.md.

If a step from memory doesn't work (element not found,
page changed) — ask user for a new path
and update the record in `navigation_paths.json`.

**If `PATH_EXISTS = false`:**
Ask user:
```
Path to "[TARGET_PAGE_NAME]" not found in memory.
Describe step-by-step how to navigate to this page:
1. [First step]
2. [Second step]
3. ...
```

Wait for response. Execute user's steps.
Save steps as `USER_NAVIGATION_STEPS`.
Set `IS_NEW_PATH = true`.

### Step 6 — Execute Test Cases

For each test case from scope:

1. **Verify precondition:**
   - If precondition describes page state (e.g.
     "form is open", "list is loaded") — verify
     that current state matches. If not — navigate
     to the right page or perform actions to reach
     the state.
   - If precondition describes data presence (e.g.
     "there is a record with type Individual") and such data
     doesn't exist in the system — ask user how to prepare
     data: where to create, what values to specify, or if there is
     a ready record to use. Do not create
     data without user instructions.
   - If the next test case requires another
     page — navigate to it (check memory
     or ask user).

2. **Execute steps** — for each row of the test case table,
   interpreting the step as a browser action:

   **How to interpret steps:**
   - "Open [page/form/modal]" → `navigate`
     to URL or `find` + `computer click` on element
     that opens.
   - "Enter [value] in [field]" → `find` field
     by description → `form_input` or `computer type`.
   - "Click [button]" → `find` button by text
     → `computer left_click`.
   - "Select [option] in [dropdown]" → `find` dropdown
     → `computer left_click` → `find` option
     → `computer left_click`. Or `form_input` with value.
   - "Verify that [element/text] is displayed"
     → `find` element or `get_page_text` and search text.
   - "Scroll to [element]" → `computer scroll`
     or `find` + `computer scroll_to`.

**For each step:**
   a. `read_page` or `find` — see current state.
   b. Find target element.
   c. Execute action.
   d. Verify expected result from the table column
      "Expected result": search text,
      element or state on the page via `find`,
      `read_page` or `get_page_text`.
   e. Record step result: matches
      or doesn't match.

3. **Classify test case** according to section
   "Classification".

4. **If FAIL or FAIL CONFIRMED** — take screenshot
   (`computer screenshot`) as proof. Do not take screenshot
   for PASS, BLOCKED, FAIL REJECTED.

5. **Continue to the next test case** without stopping.

### Step 7 — Save Navigation Path (if new)

If `IS_NEW_PATH = true`:
- Read `navigation_paths.json`.
- Add new record:
```json
"[TARGET_PAGE_NAME]": {
  "url": "[URL if there is direct]",
  "login_required": true,
  "navigation_steps": ["step 1", "step 2", "..."],
  "last_used": "[ISO timestamp]"
}
```
- Save the file, do not overwrite existing records.

### Step 8 — Generate Report

Create file `<ISSUEKEY>-manual-testing.md` with results.

Template — in references/output-template.md.

Report should be detailed:
- Table of results for each test case.
- For each FAIL and FAIL CONFIRMED — specifically:
  which step, what was expected, what agent actually saw.
- For each FAIL REJECTED — what code review finding showed
  and why UI works correctly.
- For each BLOCKED — reason and what agent saw.
- For each OBSERVATION — what exactly was noticed.
- Summary statistics.

## Classification

Each test case receives one status:

- `PASS` — UI behavior matches expected result
  from the test case. All steps executed successfully.
- `FAIL` — UI behavior does not match expected result.
  There is a specific discrepancy between expected and actual.
  Used for test cases that came with QA status
  from code review.
- `FAIL CONFIRMED` — test case came with FAIL status
  from code review and UI confirms: bug really appears
  in the interface. Include finding from code review + what agent saw
  in UI.
- `FAIL REJECTED` — test case came with FAIL status
  from code review but UI shows correct work. Bug from code
  does not appear in UI — possibly compensated by another
  mechanism, or code review was wrong.
- `BLOCKED` — test case cannot be executed. Element
  not found, page didn't load, no access,
  precondition unreachable.
- `OBSERVATION` — test case passed (PASS), but noticed
  defect or anomaly outside requirements scope.

Rules:
- Do not set PASS if there are doubts — better FAIL with description.
- Do not set FAIL without specific description of discrepancy.
- BLOCKED is not FAIL. Test didn't fail, it couldn't be executed.
- OBSERVATION does not replace FAIL. If expected result
  doesn't match — it's FAIL, not OBSERVATION.
- For points with FAIL from code review use only
  FAIL CONFIRMED or FAIL REJECTED — not regular FAIL/PASS.
  This allows seeing in the report what exactly was bug verification
  and what was new UI check.
- For points sourced from automation-strategy (`MANUAL-STRATEGY`) or
  ui-tests (`UI-DEFERRED`/`UI-PENDING`) — there is no prior code-review
  finding to confirm or refute, so use only `PASS`, `FAIL`, `BLOCKED`,
  or `OBSERVATION`. Never use `FAIL CONFIRMED`/`FAIL REJECTED` for
  these — that pair is reserved for points that came with a `FAIL`
  verdict from code review.

## Browser Error Handling

- Page didn't load (timeout, 500, blank) —
  try to reload once via `navigate`.
  If didn't help — BLOCKED for all test cases
  on this page.
- Session expired during execution — repeat login
  according to step 4, continue from current test case.
- Element not found after 2 attempts (including scroll) —
  BLOCKED for this test case with description of what was searched and where.
- Alert or dialog appears — read text,
  record, close and continue. If dialog
  blocks execution — BLOCKED.
- Chrome extension doesn't respond — stop, inform
  user.

## Additional Checks (exploratory)

After executing all test cases, if agent noticed
something suspicious during navigation or step execution
that is not covered by test cases — record in "Observations"
section of the output file.

Do not search for bugs specially. Record only what
struck during test case execution.

## Verification Before Saving

Before saving, verify:

- Number of test cases in the report equals the number of
  QA + FAIL points from code review file, plus any Manual/Not
  automatable points from automation-strategy.md and any
  Deferred/Pending points from ui-tests/summary.md that were in
  scope. If doesn't match — find missing and add.
- Test case order matches test-cases file order.
- Each FAIL and FAIL CONFIRMED has: which step,
  expected result, actual result.
- Each FAIL REJECTED has: code review finding and what
  agent saw in UI.
- Each BLOCKED has reason.
- No test cases without status.
- For points with FAIL from code review — used
  FAIL CONFIRMED or FAIL REJECTED, not PASS/FAIL.

## Output File

Create file `<ISSUEKEY>-manual-testing.md` in working
directory and give to user for download.

File remains in working directory.

If file already exists — delete completely and create new.
On output always one file with result of last run.
Do not merge with previous version, do not append, do not save
data from previous write.

Before finishing verify:
- One header of top level
- One integral document without duplicate sections

Template — in references/output-template.md.

## Final Response

After saving the file inform:
- Path to saved file
- PASS / FAIL / FAIL CONFIRMED / FAIL REJECTED / BLOCKED / OBSERVATION counters
- Overall verdict: manual testing successful
  (all PASS and FAIL REJECTED) or unsuccessful
  (there are FAIL or FAIL CONFIRMED)
- If there are FAIL or FAIL CONFIRMED — briefly list
  found problems
- If there are OBSERVATION — briefly list observations
- If there are BLOCKED — list what failed to execute and why
