# QAPR-0001 - API Tests Summary

Test cases: c:\src\!QA pipeline\QAPR-0001\test-cases.md
Automation strategy: c:\src\!QA pipeline\QAPR-0001\automation-strategy.md
Codebase reference: c:\src\!QA pipeline\juice-shop-master
Swagger reference: c:\src\!QA pipeline\juice-shop-master\swagger.yml
API mapping: c:\src\!QA pipeline\QAPR-0001\api-tests\api-mapping.json
Generated: 2026-08-31 (cleanup patch applied 2026-08-31; test-output traceability patch applied 2026-09-01)

## Test Output Traceability

Every generated test attaches the full request/response exchange for
every call it makes (via `helpers.ts`'s `attachExchange`) and every
`expect()` on a response carries a descriptive message with the actual
observed value. This means a failure — or a passing run someone wants
to audit — is understandable directly from the HTML report
(`npx playwright show-report`) or JSON reporter output, without
opening the test source. Verified by running with `--reporter=json`
and confirming all 26 request/response exchanges across the suite are
captured with real input parameters and response bodies, not just
pass/fail booleans.

## Traceability

| TC-REQ | Scenario | Test File | Test Name | Status |
|--------|----------|-----------|-----------|--------|
| TC-REQ-2e.4 | Security Answer comparison is case-sensitive | security-answer-case-sensitivity.spec.ts | TC-REQ-2e.4: Security Answer comparison is case-sensitive | Generated |
| TC-REQ-6.1 | Registering with an email identical to an existing account's email is rejected | registration-email-uniqueness.spec.ts | TC-REQ-6.1: Registering with an email identical to an existing account's email is rejected | Generated |
| TC-REQ-6.2 | Registering with an email differing only by leading/trailing whitespace is rejected | registration-email-uniqueness.spec.ts | TC-REQ-6.2: Registering with an email differing only by leading/trailing whitespace from an existing account's email is rejected | Generated |
| TC-REQ-6.3 | Registering with an email differing only by letter case is rejected | registration-email-uniqueness.spec.ts | TC-REQ-6.3: Registering with an email differing only by letter case from an existing account's email is rejected | Generated |
| TC-REQ-6.4 | Concurrent registration submissions for the same normalized email — exactly one succeeds | registration-email-uniqueness.spec.ts | TC-REQ-6.4: Concurrent registration submissions for the same normalized email — exactly one succeeds | Generated |
| TC-REQ-10.1 | Invalid registration data submitted directly to the server is still validated and rejected | registration-server-side-validation.spec.ts | TC-REQ-10.1: Invalid registration data submitted directly to the server is still validated and rejected | Generated |
| TC-REQ-11.1 | Submitting valid registration data creates exactly one customer account | registration-account-creation.spec.ts | TC-REQ-11.1: Submitting valid registration data creates exactly one customer account | Generated |
| TC-REQ-11.2 | The newly created account has the default role "customer" | registration-account-creation.spec.ts | TC-REQ-11.2: The newly created account has the default role "customer" | Generated |
| TC-REQ-11.3 | The newly created account is immediately active without email verification or activation | registration-account-creation.spec.ts | TC-REQ-11.3: The newly created account is immediately active without email verification or activation | Generated |
| TC-REQ-12.1 | Submitting invalid registration data does not create a customer account | registration-invalid-data-rejection.spec.ts | TC-REQ-12.1: Submitting invalid registration data does not create a customer account | Generated |
| TC-REQ-16.1 | Password value does not appear anywhere in application logs | — | — | Pending — no log-inspection mechanism |
| TC-REQ-16.2 | Password value is not returned in any API response, including error responses | password-response-exposure.spec.ts | TC-REQ-16.2: Password value is not returned in any API response, including error responses | Generated |
| TC-REQ-16.3 | Password is stored at rest in hashed form, not in plaintext | — | — | Pending — no data-at-rest inspection mechanism |
| TC-REQ-19.2 | A Security Answer containing SQL-like syntax is accepted and does not cause a database error | registration-sql-injection-safety.spec.ts | TC-REQ-19.2: A Security Answer containing SQL-like syntax is accepted and does not cause a database error | Generated |
| TC-REQ-23.1 | Submitting with one or more mandatory values missing or invalid fails and creates no account | registration-mandatory-field-validation.spec.ts | TC-REQ-23.1: Submitting with one or more mandatory values missing or invalid fails and creates no account | Generated |
| TC-REQ-25.1 | Backend write failure during registration produces a controlled error, not a raw system error | — | — | Pending — no fault-injection mechanism |
| TC-REQ-25.2 | No user record persists after a failed backend write during registration | — | — | Pending — no fault-injection mechanism |
| TC-REQ-25.3 | The same email can be retried after a failed backend write | — | — | Pending — no fault-injection mechanism |

## Cleanup Coverage

| TC-REQ | Creates persistent data? | Cleanup |
|--------|---------------------------|---------|
| TC-REQ-2e.4 | Yes (account) | DELETE /api/Users/:id |
| TC-REQ-6.1 | Yes (arrange-step account) | DELETE /api/Users/:id |
| TC-REQ-6.2 | Yes (arrange-step account) | DELETE /api/Users/:id |
| TC-REQ-6.3 | Yes (arrange-step account) | DELETE /api/Users/:id |
| TC-REQ-6.4 | Yes (whichever submission wins the race) | DELETE /api/Users/:id |
| TC-REQ-10.1 | No (rejected before creation) | N/A |
| TC-REQ-11.1 | Yes (account) | DELETE /api/Users/:id |
| TC-REQ-11.2 | Yes (account) | DELETE /api/Users/:id |
| TC-REQ-11.3 | Yes (account) | DELETE /api/Users/:id |
| TC-REQ-12.1 | No (rejected before creation) | N/A |
| TC-REQ-16.2 | Yes (successful-branch account only) | DELETE /api/Users/:id |
| TC-REQ-19.2 | Yes (account) | DELETE /api/Users/:id |
| TC-REQ-23.1 | No (rejected before creation) | N/A |

All generated tests that create a persistent account now clean it up via `DELETE /api/Users/:id` (confirmed available and unauthenticated in the discovered codebase — no `security.isAuthorized()`/`denyAll()` guard found on it, unlike most other models). This also fixes a real ordering bug in `registration-email-uniqueness.spec.ts`: TC-REQ-6.1–6.3 each independently registered the same `existing.user@example.com` as their "arrange" precondition without removing it afterward — a second run would have left that account behind, silently breaking the arrange step's assumption, and TC-REQ-6.4's "no account currently exists / fresh run" precondition for `race.user@example.com` had the same problem.

## How to Run

See `README.md` for install/run instructions.

Existing Playwright setup detected: no — scaffolded new `playwright.config.ts` and a self-contained `package.json` (`@playwright/test` 1.62.1, no browsers needed) since no `playwright.config.ts`/`.js` or existing install was found anywhere under `juice-shop-master`.

## Verified Run Results (2026-08-31)

This suite was actually installed and run against a live instance of the app (`npm start` in `juice-shop-master/`, `http://localhost:3000`) three times in a row to confirm it's genuinely runnable and repeatable, not just syntactically generated:

- **12 of 13 tests pass consistently**, including full cleanup (no leftover accounts across repeated runs).
- **TC-REQ-6.3 fails consistently, and this is a real finding, not a test bug:** registering with an email that differs only by letter case from an existing account **succeeds** instead of being rejected. Confirmed in `models/user.ts` — the `email` field is `unique: true` with no lowercase/normalization transform; only whitespace is trimmed (in `server.ts`'s registration handler, which is why TC-REQ-6.2 correctly passes). So the current implementation does **not** satisfy REQ-6/REQ-15's case-insensitive uniqueness rule. Left as a legitimately failing assertion (not weakened) so this stays visible; cleanup still runs correctly for it via `finally`.
- Two bugs were found and fixed by actually running the suite (not visible from reading the generated code alone):
  1. **Cross-test race**: TC-REQ-6.1/6.2/6.3 originally shared one hardcoded email literal; Playwright's default parallel workers raced to register it simultaneously, causing spurious `undefined` crashes. Fixed by giving each test its own unique generated email (these values are marked `[test data]` in test-cases.md, not fixed requirement values, so this is a safe fix).
  2. **Cleanup placed after assertions instead of in `finally`**: a cleanup call that only runs on success never runs on a legitimate failure — confirmed empirically when TC-REQ-6.3's first fix attempt left orphaned accounts in the dev DB. All cleanup is now inside `try/finally`.

## Pending Clarifications

- TC-REQ-16.1 (Password value does not appear anywhere in application logs): the test case's own step is "inspect the application logs generated during this request." No HTTP endpoint, log-streaming API, or file path for reading server-side application logs was found in swagger.yml or in the juice-shop-master codebase (server.ts / lib). This requires either direct filesystem/log-aggregator access to the running instance, or the user pointing to a specific log-retrieval mechanism (e.g. a log file path, a logging service API) before a test can be generated.
- TC-REQ-16.3 (Password is stored at rest in hashed form, not in plaintext): the test case's own step is "inspect the stored account record at rest." The only discovered read path for User records (`GET /api/Users/:id`, auto-generated via finale-rest) explicitly excludes the `password` attribute (`exclude: ['password', 'totpSecret']` in server.ts's `autoModels` configuration), and that same list requires bearer-token authorization (`security.isAuthorized()`) even for the fields it does return. No API-accessible way to read the raw stored password value was found. This requires direct database access (e.g. a DB connection string/credentials, or an authorized diagnostic endpoint) before a test can be generated.
- TC-REQ-25.1 (Backend write failure during registration produces a controlled error, not a raw system error): the test case's own precondition requires "a backend write failure is forced [test data/environment fault-injection mechanism]." No fault-injection endpoint, header, query parameter, or test-mode flag for forcing the account-creation write to fail was found in swagger.yml or in the juice-shop-master codebase. This requires the user to specify how the fault should be induced (e.g. a chaos-testing hook, an environment toggle, a mocked DB failure) before a test can be generated.
- TC-REQ-25.2 (No user record persists after a failed backend write during registration): depends on the same forced-failure precondition as TC-REQ-25.1 having "just occurred" — without a discoverable way to force that failure, this test cannot be constructed. Same clarification needed as TC-REQ-25.1, plus a way to check for the absence of a user record (see TC-REQ-16.3's clarification on record inspection).
- TC-REQ-25.3 (The same email can be retried after a failed backend write): also depends on the TC-REQ-25.1 forced-failure precondition having "just occurred." Same clarification needed as TC-REQ-25.1.

## Discovery Notes (not pending, but relevant to generated tests)

- POST /rest/user/reset-password and GET /rest/user/security-question (routes/resetPassword.ts, routes/securityQuestion.ts, wired in server.ts) are not documented in swagger.yml but were found in the codebase; reset-password is the real "security-answer verification mechanism" used for TC-REQ-2e.4.
- For TC-REQ-10.1, TC-REQ-12.1, and TC-REQ-23.1, the test cases' own example invalid data is "invalid email format" (e.g. `invalid-email`), but no email-format validation exists server-side in the discovered registration code path (server.ts, lines ~427-441) — only a presence/non-empty check on `email`/`password` (400 "Invalid email/password cannot be empty" when either is empty). Since this literal is marked `[test data]` (an illustrative example, not a fixed value), these three tests instead use an empty Password value as the invalid/missing mandatory data — the concrete, code-confirmed rejection path — so the generated assertions are grounded in actual discovered server behavior rather than an unverified assumption about email-format validation.
