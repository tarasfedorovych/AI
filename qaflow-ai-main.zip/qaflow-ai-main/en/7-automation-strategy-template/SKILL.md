---
name: automation-strategy
description: >
  Seventh stage of task processing. Takes test cases created by the
  qa-test-cases skill (and optionally the code-review results) and
  classifies each test case into a recommended automation approach —
  API, UI, or Manual/Not automatable — with a short rationale grounded
  in what the test case actually describes. Use when the user says
  "automation strategy", "classify test cases for automation",
  "what should be automated", or after code review completion.
---

# Automation Strategy

> ⚙️ Recommended settings: **Sonnet · Effort: Medium · Extended thinking: Off**

Classifies every test case from the test-cases file into one automation
recommendation — API, UI, or Manual/Not automatable — with a one-to-two
sentence rationale per item, so the next skill (api-tests) knows exactly
which TC-REQ-IDs to turn into Playwright API tests, and so the team
knows which items still need UI automation or human judgment.

## Input Data

Input — test cases file `<ISSUEKEY>/test-cases.md` created by the
qa-test-cases skill. In the same chat, the file is available in the
`<ISSUEKEY>/` folder automatically. If the chat is new — the user
uploads the file to the chat.

Optional — code review file `<ISSUEKEY>/code-review.md` created by the
code-review skill. Used only to note which TC-REQ items are already
`N/A` for the current PR (so the strategy doc can flag them as lower
priority to automate right now) — never used to re-judge or override
the automation classification itself.

Both files — read-only. Do not change, do not rewrite, do not clear
their contents.

If the test-cases file is missing, empty, or corrupted — stop and
inform the user that the qa-test-cases skill needs to be executed first.

If the code-review file is missing — proceed without it. Simply do not
annotate priority.

Do not go to the tracker, do not inspect actual PR code, do not use
external tools, do not search the internet. Classification is based
purely on what the test case text says it verifies — not on how it is
currently implemented.

## Rules

- All communication and all output file content — in English.
- Chat messages — brief.
- Classify only from what is written in the test case (preconditions,
  steps, expected results). Do not invent behavior, do not assume there
  is a backend API for something the test case doesn't describe, do not
  assume there is a UI screen for something purely described as backend
  state.
- Do not change the wording, steps, or REQ/TC-REQ numbering of the
  source test cases — this skill produces a parallel classification
  document, not an edited test-cases file.
- Classify by where the test case's **verification** actually happens,
  not by where the trigger/action happens (see Classification Method).
- If genuinely ambiguous — ask the user rather than guessing. Do not
  silently default to Manual for ambiguous cases just because it seems
  like the safe answer — that defeats the purpose of the exercise.
- After saving the file — stop. Do not continue to api-tests or
  planning.

## Classification Method

For each test case (TC-REQ-X.Y), classify using this decision order.

### Step 1 — Identify what the Expected Result actually verifies

Read every row of the test case's Steps table. Find where the test
case's verification happens — not where the action/trigger happens. A
test case is defined by what it checks, not by what it does to get
there.

### Step 2 — Apply these criteria in order

1. **API** — recommend when all of the following hold:
   - Every expected result can be confirmed by inspecting a response
     body/status code, a database/backend state, or a received event
     payload — with no dependency on how it is rendered.
   - Every step can be performed via a direct request (HTTP call,
     webhook trigger, backend event) without needing to click through a
     UI to set up preconditions that themselves require visual
     verification.
   - Signal phrases: "verify ... in the backend", "webhook event",
     "API returns", "subscription status" as a data state (not as UI
     text), "database record", "event is processed".
   - Example: a test case titled "checkout.session.completed activates
     the subscription" whose steps trigger a webhook event and verify
     "Subscription is active" as backend state → **API**.

2. **UI** — recommend when any of the following hold, even if part of
   the flow is API-driven:
   - The expected result requires reading rendered page content: a
     message, label, redirect, visual state, enabled/disabled control,
     or navigation outcome ("I should see...", "message is displayed",
     "redirected to...", "page shows...").
   - The test case exercises a multi-step user journey through actual
     screens where the sequence of UI interactions is itself part of
     what's being verified, not just a means to reach a state.
   - Signal phrases: "verify page message", "is displayed", "redirected
     to", "returned to the application", "success message".
   - If a test case has both API-verifiable and UI-verifiable expected
     results, classify it **UI** overall (UI is the stricter/superset
     requirement — an API test cannot confirm rendered content), but
     note in the rationale that a subset of its assertions is also
     API-checkable.

3. **Manual / Not automatable** — recommend when:
   - The expected result requires subjective/visual judgment that can't
     be reduced to a deterministic assertion (e.g. "layout looks
     correct", "design matches mockup").
   - The test case depends on a real third-party system's own hosted
     UI/behavior outside the product's control in a way that can't be
     scripted reliably (e.g. verifying rendering inside a third-party
     hosted checkout page, not the product's own UI).
   - The expected result is genuinely underspecified for automation
     either way.
   - Signal phrases: "visually", "looks correct", "appropriate", "as
     expected" without a concrete deterministic value.
   - Do not force a classification the text doesn't support. If
     underspecified, mark Manual/Not automatable with a rationale of
     "expected result too subjective/underspecified to assert
     deterministically" rather than guessing API or UI.

### Step 3 — Cross-check against the code-review file (if provided)

If the optional code-review file is available and a TC-REQ item has
status `N/A` there, still classify it normally (its automation approach
does not change), but add a note: "Currently N/A for this PR — lower
priority to automate now." Do not change classification based on
PASS/FAIL/QA/N/A status — those reflect current implementation state,
not what approach best fits the test case's nature.

## Numbering

Keep the exact `TC-REQ-X.Y` ID from the source test-cases file for
every row. Do not renumber, do not group multiple TC-REQ items under
one row unless they are literally the same scenario. One requirement
group section, one row per TC-REQ within it, in the same order as the
test-cases file.

## Verification Before Saving

Before saving, verify:

- Every TC-REQ from the test-cases file has exactly one row.
- Order matches the order of test cases in the test-cases file.
- Every row has a one-to-two sentence rationale, not just a label.
- No row is classified API or UI without a rationale tied to specific
  wording in the test case.

## Output File

Create the folder `<ISSUEKEY>/` in the working directory if it does not
exist, then create file `automation-strategy.md` inside it, and give it
to the user for download.

The file remains in `<ISSUEKEY>/` — the next skill in the same chat
(api-tests) takes it automatically.

If the file already exists — delete it completely and create a new
one. Always output one file with the result of the latest run. Do not
merge with the previous version, do not append, do not save data from
the previous run.

File structure template is in references/output-template.md.
Worked examples for calibration — in references/classification-examples.md.

## Final Response

After saving the file, inform:
- Path to the saved file
- Counts: API / UI / Manual (Not automatable)
