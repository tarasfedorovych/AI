import { test, expect } from '@playwright/test';
import { attachExchange } from './helpers';

// REQ-12: REG-010 — invalid registration data does not create an account.
// Endpoint: POST /api/Users.
//
// Discovery note: as in registration-server-side-validation.spec.ts
// (REQ-10), an email-format-only violation is not confirmed to be
// rejected server-side by the discovered code (server.ts has no
// email-format check), so this test uses an empty Password value —
// the code-confirmed rejection path (400 "Invalid email/password
// cannot be empty").

const VALID_EMAIL = `invalid-data-${Date.now()}@example.com`; // [test data]
const INVALID_PASSWORD = ''; // [test data] — empty, confirmed server-side rejection path

// TC-REQ-12.1
test('TC-REQ-12.1: Submitting invalid registration data does not create a customer account', async ({ request }, testInfo) => {
  // Act — submit the registration form with invalid data
  const requestBody = { email: VALID_EMAIL, password: INVALID_PASSWORD, passwordRepeat: INVALID_PASSWORD };
  const response = await request.post('/api/Users', { data: requestBody });
  const body = await attachExchange(testInfo, 'invalid registration attempt', { method: 'POST', url: '/api/Users', body: requestBody }, response);

  // Assert — registration fails; no customer account is created
  expect(response.ok(), `expected registration to be rejected for an empty password, got ${response.status()} - ${JSON.stringify(body)}`).toBeFalsy();
});
