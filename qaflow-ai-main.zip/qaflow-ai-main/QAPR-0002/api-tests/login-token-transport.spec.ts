import { test, expect } from '@playwright/test';
import { attachExchange, uniqueEmail } from './helpers';

// REQ-20: BR-LOGIN-006 — authentication tokens/session identifiers shall
// not be exposed in URLs. Verified by confirming a normal authenticated
// request succeeds via the Cookie header alone, with no token ever placed
// in the request URL. (The token-does-not-contain-the-plaintext-password
// half of this requirement is already covered by TC-REQ-16.2 — see
// test-cases.md's cross-reference note.)

const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data]

// TC-REQ-20.2
test('TC-REQ-20.2: The session/token is not required as a URL query-string parameter for a normal authenticated request', async ({ request }, testInfo) => {
  const email = uniqueEmail('token-transport');

  const registerBody = { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD };
  const registerResponse = await request.post('/api/Users', { data: registerBody });
  const registerRespBody = await attachExchange(testInfo, 'arrange: register account', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
  expect(registerResponse.status(), `expected 201 Created, got ${registerResponse.status()} - ${JSON.stringify(registerRespBody)}`).toBe(201);

  const loginBody = { email, password: VALID_PASSWORD };
  const loginResponse = await request.post('/rest/user/login', { data: loginBody });
  const loginRespBody = await attachExchange(testInfo, 'login', { method: 'POST', url: '/rest/user/login', body: loginBody }, loginResponse);
  expect(loginResponse.status(), `expected 200 OK, got ${loginResponse.status()} - ${JSON.stringify(loginRespBody)}`).toBe(200);
  const token: string = loginRespBody.authentication.token;

  // Act — request authenticated-only data via the standard mechanism
  // (Cookie header), with no token anywhere in the URL
  const url = '/rest/user/whoami';
  const response = await request.get(url, { headers: { Cookie: `token=${token}` } });
  const body = await attachExchange(testInfo, 'whoami via Cookie header, token never in the URL', { method: 'GET', url, headers: { Cookie: 'token=<redacted>' } }, response);

  // Assert — succeeds without the token appearing as a URL query-string parameter
  expect(response.status(), `expected 200 OK, got ${response.status()}`).toBe(200);
  expect(body.user?.email, `expected the correct user to be resolved without a URL-embedded token, got ${JSON.stringify(body)}`).toBe(email);
  expect(url.includes('token='), 'expected the request URL itself to carry no token parameter').toBe(false);
});
