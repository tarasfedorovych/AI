# QAPR-0001 - User Registration

Source: Local file `juice-shop-sample-reqs/QAPR-0001 - User-registration-requirements-simplified.md`
Type: Requirements document (no tracker integration configured)
Generated: 2026-08-31

## Goal
Allow an unauthenticated visitor to create a customer account (Feature ID: AUTH-REG, Priority: High) so they can log in and use customer functionality.

## Scope
- In scope: registration form access, mandatory field validation, email format and uniqueness validation, password policy validation, confirm-password matching, security question/answer (if supported), server-side validation, account creation behavior, success/error feedback, and the associated business/security rules and edge cases listed below.
- Out of scope: Not specified in source document.

## Requirements
- Preconditions: The application is available; the user is not authenticated; the registration page is accessible.
- Registration Fields: Email (required, valid format and unique); Password (required, must satisfy configured password policy); Confirm Password (required, must match Password); Security Question (required if supported — user selects an available question); Security Answer (required if supported — required when security question is used).
- REG-001: The system shall allow an unauthenticated visitor to open the registration form.
- REG-002: The system shall require all mandatory registration fields.
- REG-003: The system shall validate the email format.
- REG-004: The system shall not allow two accounts with the same email address. Email comparison shall be case-insensitive.
- REG-005: The system shall validate the password against the configured password policy.
- REG-006: Confirm Password shall exactly match Password.
- REG-007: If security questions are enabled, the user shall provide the required question and answer.
- REG-008: Registration data shall be validated by the server even when client-side validation exists.
- REG-009: Valid registration data shall create exactly one customer account.
- REG-010: Invalid registration data shall not create an account.
- REG-011: After successful registration, the user shall receive a clear success indication and follow the configured post-registration flow.
- REG-012: Validation failures shall display an appropriate error without exposing internal system details.
- BR-REG-001: Email addresses must be unique after normalization.
- BR-REG-002: Passwords shall never be stored or logged in plaintext.
- BR-REG-003: Credentials shall be transmitted securely in non-development environments.
- BR-REG-004: Repeated submission shall not create duplicate accounts.
- BR-REG-005: User input shall be handled safely and shall not allow script or query injection.
- Important Edge Cases (for grooming/test design coverage): empty mandatory fields; invalid email format; existing email; existing email with different letter case; leading/trailing whitespace in email; password below or above allowed length; password and confirmation mismatch; missing security question/answer when required; very long input; Unicode and special-character input; HTML/JavaScript-like or SQL-like input; multiple rapid submissions; network or backend failure during registration.
- AC-REG-001 (Successful Registration): Given a visitor provides a unique valid email and valid mandatory data, when registration is submitted, then exactly one account is created and registration success is shown.
- AC-REG-002 (Duplicate Email): Given an account already exists for the email, when the visitor registers with the same normalized email, then registration fails and no additional account is created.
- AC-REG-003 (Invalid Input): Given one or more mandatory values are missing or invalid, when registration is submitted, then registration fails, the relevant validation error is shown, and no account is created.
- AC-REG-004 (Password Mismatch): Given Password and Confirm Password differ, when registration is submitted, then registration fails and the mismatch is communicated to the user.
- AC-REG-005 (Backend Failure): Given valid registration data and account creation fails on the backend, when registration is submitted, then the user receives a controlled error and no partially usable account remains.
