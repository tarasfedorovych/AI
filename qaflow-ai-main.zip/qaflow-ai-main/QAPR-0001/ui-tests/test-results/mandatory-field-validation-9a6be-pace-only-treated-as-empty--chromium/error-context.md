# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mandatory-field-validation.spec.ts >> TC-REQ-4.2: Submitting with a mandatory field containing only whitespace displays a validation error (whitespace-only treated as empty)
- Location: mandatory-field-validation.spec.ts:61:5

# Error details

```
Error: expected a required-field validation error for Email, since a whitespace-only value must be treated as empty per REQ-4

expect(locator).toBeVisible() failed

Locator: getByText('Please provide an email address.')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - expected a required-field validation error for Email, since a whitespace-only value must be treated as empty per REQ-4 with timeout 5000ms
  - waiting for getByText('Please provide an email address.')

```

```yaml
- button "Open Sidenav"
- button "Back to homepage":
  - img "OWASP Juice Shop"
  - text: OWASP Juice Shop
- button "Open search"
- textbox
- button "Close search"
- button "Show/hide account menu": Account
- button "Show the shopping cart": Your Basket 0
- button "Language selection menu": EN
- heading "User Registration" [level=1]
- text: Email
- textbox "Email address field" [invalid]
- text: Email address is not valid. Password
- textbox "Field for the password": Str0ngP@ssw0rd!
- emphasis: Password must be 5-40 characters long.
- text: 15/20 Repeat Password
- textbox "Field to confirm the password": Str0ngP@ssw0rd!
- text: 15/40
- switch "Show password advice"
- text: Show password advice
- progressbar
- text: Security Question
- combobox "Selection list for the security question": Your eldest siblings middle name?
- emphasis: This cannot be changed later!
- text: Answer
- textbox "Field for the answer to the security question":
  - /placeholder: Answer to your security question
  - text: TestAnswer123
- button "Button to complete the registration" [disabled]: Register
- link "Already a customer?":
  - /url: "#/login"
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import { RegistrationPage } from '../../ui-framework/pages/RegistrationPage';
  3  | 
  4  | const VALID_PASSWORD = 'Str0ngP@ssw0rd!'; // [test data] valid mandatory data
  5  | const VALID_SECURITY_ANSWER = 'TestAnswer123'; // [test data] valid mandatory data
  6  | const VALID_EMAIL = 'validator@example.com'; // [test data] valid mandatory data
  7  | 
  8  | // TC-REQ-4.1
  9  | test('TC-REQ-4.1: Submitting with Email, Password, or Confirm Password left completely empty displays a validation error for that field', async ({ page }) => {
  10 |   const registrationPage = new RegistrationPage(page);
  11 | 
  12 |   await test.step('Leave Email empty, fill the remaining mandatory fields with valid data', async () => {
  13 |     await registrationPage.goto();
  14 |     await registrationPage.fillPassword(VALID_PASSWORD);
  15 |     await registrationPage.fillRepeatPassword(VALID_PASSWORD);
  16 |     await registrationPage.selectFirstSecurityQuestion();
  17 |     await registrationPage.fillSecurityAnswer(VALID_SECURITY_ANSWER);
  18 |     await registrationPage.touchField(registrationPage.emailInput);
  19 |   });
  20 | 
  21 |   await test.step('Verify a validation error is displayed for the Email field indicating it is required', async () => {
  22 |     await expect(
  23 |       registrationPage.emailRequiredError,
  24 |       'expected a required-field validation error for Email'
  25 |     ).toBeVisible();
  26 |   });
  27 | 
  28 |   await test.step('Fill Email with valid data, leave Password empty, fill the remaining fields with valid data', async () => {
  29 |     await registrationPage.goto();
  30 |     await registrationPage.fillEmail(VALID_EMAIL);
  31 |     await registrationPage.selectFirstSecurityQuestion();
  32 |     await registrationPage.fillSecurityAnswer(VALID_SECURITY_ANSWER);
  33 |     await registrationPage.touchField(registrationPage.passwordInput);
  34 |   });
  35 | 
  36 |   await test.step('Verify a validation error is displayed for the Password field indicating it is required', async () => {
  37 |     await expect(
  38 |       registrationPage.passwordRequiredError,
  39 |       'expected a required-field validation error for Password'
  40 |     ).toBeVisible();
  41 |   });
  42 | 
  43 |   await test.step('Fill Email and Password with valid data, leave Confirm Password empty, fill the remaining fields with valid data', async () => {
  44 |     await registrationPage.goto();
  45 |     await registrationPage.fillEmail(VALID_EMAIL);
  46 |     await registrationPage.fillPassword(VALID_PASSWORD);
  47 |     await registrationPage.selectFirstSecurityQuestion();
  48 |     await registrationPage.fillSecurityAnswer(VALID_SECURITY_ANSWER);
  49 |     await registrationPage.touchField(registrationPage.repeatPasswordInput);
  50 |   });
  51 | 
  52 |   await test.step('Verify a validation error is displayed for the Confirm Password field indicating it is required', async () => {
  53 |     await expect(
  54 |       registrationPage.repeatPasswordRequiredError,
  55 |       'expected a required-field validation error for Confirm Password'
  56 |     ).toBeVisible();
  57 |   });
  58 | });
  59 | 
  60 | // TC-REQ-4.2
  61 | test('TC-REQ-4.2: Submitting with a mandatory field containing only whitespace displays a validation error (whitespace-only treated as empty)', async ({ page }) => {
  62 |   const registrationPage = new RegistrationPage(page);
  63 | 
  64 |   await test.step('Enter a whitespace-only value in the Email field, fill the remaining mandatory fields with valid data', async () => {
  65 |     await registrationPage.goto();
  66 |     await registrationPage.fillEmail('   '); // [test data, 3 spaces]
  67 |     await registrationPage.fillPassword(VALID_PASSWORD);
  68 |     await registrationPage.fillRepeatPassword(VALID_PASSWORD);
  69 |     await registrationPage.selectFirstSecurityQuestion();
  70 |     await registrationPage.fillSecurityAnswer(VALID_SECURITY_ANSWER);
  71 |     await registrationPage.touchField(registrationPage.emailInput);
  72 |   });
  73 | 
  74 |   await test.step('Verify a validation error is displayed for the Email field indicating it is required (whitespace-only value is treated as empty)', async () => {
  75 |     await expect(
  76 |       registrationPage.emailRequiredError,
  77 |       'expected a required-field validation error for Email, since a whitespace-only value must be treated as empty per REQ-4'
> 78 |     ).toBeVisible();
     |       ^ Error: expected a required-field validation error for Email, since a whitespace-only value must be treated as empty per REQ-4
  79 |   });
  80 | });
  81 | 
```