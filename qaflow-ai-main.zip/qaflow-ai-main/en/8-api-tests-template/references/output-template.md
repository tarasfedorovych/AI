# API Tests — Output Structure

## `api-mapping.json`

Schema, fields, and worked examples (single-request, multi-step chain,
concurrent steps, pending entry) — in references/api-mapping-schema.md.
Generate this before any `.spec.ts` file; the Playwright files are
rendered from it.

## `package.json` (only when scaffolding a self-contained folder)

```json
{
  "name": "<issuekey-lowercase>-api-tests",
  "private": true,
  "version": "1.0.0",
  "scripts": {
    "test": "playwright test"
  },
  "devDependencies": {
    "@playwright/test": "<pinned exact version, e.g. 1.62.1 — check the current release, don't guess>"
  }
}
```

Do not add browser/`playwright install` steps — the `request` fixture
needs no browser binaries.

## `README.md`

```
# <ISSUEKEY> - API Tests

## Prerequisites
- Node.js <version used/assumed>
- The application under test running and reachable at <baseURL>

## Install
<cd <ISSUEKEY>/api-tests && npm install>
  — or, if reusing an existing codebase install: <cd <path> && npm install>

## Run
<npm test>
  — or the equivalent command for an existing codebase's test script

## View Report
<npx playwright show-report>
  — opens the HTML report from the last run (configured via `reporter: [['html', ...]]`
  in playwright.config.ts, or pass `--reporter=html` if reusing an existing config
  that doesn't already set one).

## Notes
- <any environment variable, auth token, or seed-data requirement
  the tests assume>
- Pending test cases (see summary.md) are not included in this run.
```

Keep this file short — it's the copy-paste path for a person who has
never seen this folder before, not a restatement of summary.md.

## `helpers.ts`

The shared `attachExchange` function (full definition in
references/playwright-conventions.md, "Traceability in Test Output"),
plus any shared multi-step setup helpers. Imported by every `.spec.ts`
file — do not redefine `attachExchange` per file.

## Generated `.spec.ts` file shape

See references/playwright-conventions.md for the full generation rules.
Each file starts with the Playwright import and an import from
`./helpers`, any `[test data]` constants, then one `test()` block per
TC-REQ item in that REQ group. Every test takes `testInfo` as its
second parameter and attaches every request/response exchange before
asserting on it.

## `summary.md`

```
# <ISSUEKEY> - API Tests Summary

Test cases: <path to test-cases file>
Automation strategy: <path to automation-strategy file>
Codebase reference: <path, or "not provided">
Swagger reference: <URL/path, or "not provided">
API mapping: <ISSUEKEY>/api-tests/api-mapping.json
Generated: <YYYY-MM-DD>

## Traceability

| TC-REQ | Scenario | Test File | Test Name | Status |
|--------|----------|-----------|-----------|--------|
| TC-REQ-6.1 | checkout.session.completed activates the subscription | checkout-webhooks.spec.ts | TC-REQ-6.1: checkout.session.completed activates the subscription | Generated |
| TC-REQ-6.4 | invoice.payment_failed keeps the subscription inactive | checkout-webhooks.spec.ts | TC-REQ-6.4: invoice.payment_failed keeps the subscription inactive | Pending — endpoint details needed |

## Cleanup Coverage

| TC-REQ | Creates persistent data? | Cleanup |
|--------|--------------------------|---------|
| TC-REQ-11.1 | Yes (account) | DELETE /api/Users/:id |
| TC-REQ-10.1 | No (rejected before creation) | N/A |

Omit rows for TC-REQ items whose steps create no persistent resource,
or keep the section short by only listing exceptions — always include
this section if at least one generated test creates persistent data.

## How to Run

See `README.md` for install/run instructions.

Existing Playwright setup detected: <yes, at <path> / no — scaffolded new config and package.json>

## Pending Clarifications

- TC-REQ-X.Y: <what was asked, still unanswered>
```

Section Rules:
- Traceability table — one row per API-classified TC-REQ item, including pending ones.
- Pending Clarifications — only present when at least one item is pending; omit the section entirely otherwise.
- How to Run — always present, must state whether an existing config was reused or a new one scaffolded.
