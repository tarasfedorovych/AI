import { test, expect } from '@playwright/test';
import { attachExchange } from './helpers';

// REQ-23: AC-REG-003 — one or more missing/invalid mandatory values causes
// registration to fail with no account created. Endpoint: POST /api/Users.
//
// Discovery note: as in REQ-10/REQ-12, server.ts's registration handler
// has no email-format check, only a presence/non-empty check on email and
// password (400 "Invalid email/password cannot be empty" when either is
// an empty string). This test uses an empty Password value as the
// missing/invalid mandatory value — the code-confirmed rejection path.

const VALID_EMAIL = `mandatory-field-${Date.now()}@example.com`; // [test data]
const MISSING_PASSWORD = ''; // [test data] — empty, confirmed server-side rejection path

// TC-REQ-23.1
test('TC-REQ-23.1: Submitting with one or more mandatory values missing or invalid fails and creates no account', async ({ request }, testInfo) => {
  // Act — submit the form with a mandatory value missing or invalid
  const requestBody = { email: VALID_EMAIL, password: MISSING_PASSWORD, passwordRepeat: MISSING_PASSWORD };
  const response = await request.post('/api/Users', { data: requestBody });
  const body = await attachExchange(testInfo, 'registration with missing password', { method: 'POST', url: '/api/Users', body: requestBody }, response);

  // Assert — registration fails; no account is created
  expect(response.ok(), `expected registration to fail for a missing mandatory field, got ${response.status()} - ${JSON.stringify(body)}`).toBeFalsy();
});
