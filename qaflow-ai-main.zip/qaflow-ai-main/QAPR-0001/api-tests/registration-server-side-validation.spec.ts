import { test, expect } from '@playwright/test';
import { attachExchange } from './helpers';

// REQ-10: REG-008 — registration data is validated by the server even when
// client-side validation exists. Endpoint: POST /api/Users.
//
// Discovery note: the test case's own example of invalid data is
// "invalid email format", but server.ts's registration handler (lines
// ~427-438) contains no email-format check — only a presence/non-empty
// check on email and password, which responds 400 "Invalid email/password
// cannot be empty" when either is an empty string. An email-format-only
// violation is not confirmed to be rejected server-side in the discovered
// code, so this test uses an empty Password value as the invalid data —
// the concrete, code-confirmed rejection path for "invalid data submitted
// directly to the server, bypassing client-side validation".

const VALID_EMAIL = `server-validation-${Date.now()}@example.com`; // [test data]
const INVALID_PASSWORD = ''; // [test data] — empty, confirmed server-side rejection path

// TC-REQ-10.1
test('TC-REQ-10.1: Invalid registration data submitted directly to the server is still validated and rejected', async ({ request }, testInfo) => {
  // Act — send a registration request directly to the server-side registration endpoint
  const requestBody = { email: VALID_EMAIL, password: INVALID_PASSWORD, passwordRepeat: INVALID_PASSWORD };
  const response = await request.post('/api/Users', { data: requestBody });
  const body = await attachExchange(testInfo, 'direct server-side registration attempt', { method: 'POST', url: '/api/Users', body: requestBody }, response);

  // Assert — server rejects the request; the response indicates a validation error
  expect(response.status(), `expected 400 for an empty password submitted directly to the server, got ${response.status()} - ${JSON.stringify(body)}`).toBe(400);
});
