#!/usr/bin/env python3
"""
json_to_md.py
Convert a test-audit JSON report into a readable Markdown report.

Usage:
  python json_to_md.py input.json output.md
"""
from __future__ import annotations
import json
import sys

def _md_escape(s: str) -> str:
    if s is None:
        return ""
    return str(s).replace("\r\n", "\n").replace("\r", "\n")

def _fmt_list(items):
    if not items:
        return "_None_"
    return "\n".join([f"- { _md_escape(i) }" for i in items])

def _group_findings(findings):
    groups = {"critical": [], "high": [], "medium": [], "low": [], "info": []}
    for f in findings or []:
        sev = (f.get("severity") or "info").lower()
        if sev not in groups:
            sev = "info"
        groups[sev].append(f)
    for k in groups:
        groups[k].sort(key=lambda x: (x.get("area_id") or "", x.get("id") or ""))
    return groups

def _render_evidence(evidence_list):
    if not evidence_list:
        return "_No evidence captured._"
    out = []
    for e in evidence_list:
        fp = e.get("file_path", "unknown")
        ls = e.get("line_start", "?")
        le = e.get("line_end", "?")
        ctx = e.get("context")
        snippet = e.get("code_snippet")
        out.append(f"**{fp}:{ls}-{le}**" + (f" — {ctx}" if ctx else ""))
        if snippet:
            out.append("```")
            out.append(str(snippet).rstrip())
            out.append("```")
    return "\n".join(out)

def _render_recommendation(rec):
    if not rec:
        return "_No recommendation provided._"
    
    # Handle string recommendations (simple format)
    if isinstance(rec, str):
        return _md_escape(rec)
    
    # Handle dictionary recommendations (structured format)
    lines = []
    if rec.get("recommendation_summary"):
        lines.append(rec["recommendation_summary"])
    wtd = rec.get("what_to_do") or []
    if wtd:
        lines.append("\n**What to do**\n" + _fmt_list(wtd))
    ex = rec.get("example_fix") or []
    if ex:
        lines.append("\n**Example fix**")
        for item in ex:
            lang = item.get("language", "")
            code = item.get("code", "")
            fence = f"```{lang}".rstrip()
            lines.append(fence)
            lines.append(str(code).rstrip())
            lines.append("```")
    tr = rec.get("tradeoffs") or []
    if tr:
        lines.append("\n**Tradeoffs**\n" + _fmt_list(tr))
    return "\n".join(lines).strip() or "_No recommendation provided._"

def main():
    if len(sys.argv) != 3:
        print("Usage: python json_to_md.py input.json output.md", file=sys.stderr)
        sys.exit(2)

    in_path, out_path = sys.argv[1], sys.argv[2]
    with open(in_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    meta = data.get("meta", {})
    target = meta.get("target", {})
    exec_sum = data.get("executive_summary", {})

    title = "Test Automation Audit Report"
    repo = target.get("repo") or ""
    ref_type = target.get("ref_type") or ""
    ref_id = target.get("ref_id") or ""
    generated_at = meta.get("generated_at") or ""
    tz = meta.get("timezone") or ""

    overall_score = exec_sum.get("overall_score", 0)
    risk_level = exec_sum.get("risk_level", "unknown")
    headline = exec_sum.get("headline", "")

    highlights = exec_sum.get("highlights", {}) or {}
    strengths = highlights.get("strengths", [])
    top_risks = highlights.get("top_risks", [])
    quick_wins = highlights.get("quick_wins", [])

    md = []
    md.append(f"# {title}")
    if repo or (ref_type and ref_id):
        md.append("")
        md.append(f"**Target:** {repo} {ref_type.upper()}-{ref_id}".strip())
    if generated_at:
        tz_part = f" ({tz})" if tz else ""
        md.append(f"**Generated:** {generated_at}{tz_part}")
    md.append("")
    md.append("## Executive summary")
    md.append(f"- **Overall score:** {overall_score}/100")
    md.append(f"- **Risk level:** {risk_level}")
    if headline:
        md.append(f"- **Headline:** {headline}")
    md.append("")
    md.append("### Highlights")
    md.append("**Strengths**\n" + _fmt_list(strengths))
    md.append("")
    md.append("**Top risks**\n" + _fmt_list(top_risks))
    md.append("")
    md.append("**Quick wins**\n" + _fmt_list(quick_wins))

    # Scorecard - support both new format (scorecard.areas) and old format (scorecard as array)
    scorecard_data = data.get("scorecard", []) or []
    if isinstance(scorecard_data, dict):
        scorecard = scorecard_data.get("areas", [])
    else:
        scorecard = scorecard_data
    
    md.append("")
    md.append("## Scorecard")
    if scorecard:
        md.append("| Area | Score | Risk | Rationale |")
        md.append("|---|---:|---|---|")
        for s in scorecard:
            area = s.get("area_name", s.get("area_id", ""))
            score = s.get("score", 0)
            rsk = s.get("risk_level", "unknown")
            rat = (s.get("rationale") or "").replace("\n", " ")
            rat = rat.replace("|", "\\|")
            md.append(f"| {area} | {score} | {rsk} | {rat} |")
    else:
        md.append("_No scorecard data._")

    # Findings
    findings = data.get("findings", []) or []
    md.append("")
    md.append("## Findings")
    if not findings:
        md.append("_No findings._")
    else:
        groups = _group_findings(findings)
        for sev in ["critical", "high", "medium", "low", "info"]:
            items = groups.get(sev) or []
            if not items:
                continue
            md.append("")
            md.append(f"### {sev.title()} ({len(items)})")
            for fnd in items:
                fid = fnd.get("id", "UNKNOWN")
                title = fnd.get("title", "")
                area = fnd.get("area_id", "")
                cat = fnd.get("category", "")
                risk = fnd.get("risk_level", "unknown")
                effort = fnd.get("effort", "unknown")
                effort_days = fnd.get("effort_days", None)
                impact = fnd.get("impact", "")
                issue = fnd.get("issue", "")
                conf = fnd.get("confidence", None)

                md.append("")
                md.append(f"#### {fid}: {title}")
                md.append(f"- **Area:** {area}")
                md.append(f"- **Category:** {cat}")
                md.append(f"- **Severity:** {sev}")
                md.append(f"- **Risk:** {risk}")
                effort_line = f"- **Effort:** {effort}"
                if isinstance(effort_days, (int, float)):
                    effort_line += f" (~{effort_days} day(s))"
                md.append(effort_line)
                if conf is not None:
                    md.append(f"- **Confidence:** {conf}")
                if issue:
                    md.append(f"\n**Issue**\n\n{_md_escape(issue)}")
                if impact:
                    md.append(f"\n**Impact**\n\n{_md_escape(impact)}")

                md.append("\n**Evidence**\n\n" + _render_evidence(fnd.get("evidence")))
                md.append("\n**Recommendation**\n\n" + _render_recommendation(fnd.get("recommendation")))

    # Anti-patterns
    anti = data.get("anti_patterns_found", []) or []
    md.append("")
    md.append("## Anti-patterns found")
    if not anti:
        md.append("_None detected._")
    else:
        for ap in anti:
            name = ap.get("name", "Unknown anti-pattern")
            desc = ap.get("description", "")
            count = ap.get("count", 0)
            sev = ap.get("severity", "unknown")
            repl = ap.get("recommended_replacement", "")
            md.append("")
            md.append(f"### {name} (count: {count}, severity: {sev})")
            if desc:
                md.append(desc)
            if repl:
                md.append(f"\n**Recommended replacement:** {repl}")

    # Coverage insights
    cov = data.get("coverage_insights", {}) or {}
    md.append("")
    md.append("## Coverage insights")
    test_types = cov.get("test_types", []) or []
    if test_types:
        md.append("### Test types")
        md.append("| Type | Count | Notes |")
        md.append("|---|---:|---|")
        for t in test_types:
            notes = (t.get("notes", "") or "").replace("|", "\\|")
            md.append(f"| {t.get('type','')} | {t.get('count',0)} | {notes} |")
    else:
        md.append("_No test type info._")

    gaps = cov.get("gaps", []) or []
    md.append("")
    md.append("### Gaps")
    if not gaps:
        md.append("_No gaps recorded._")
    else:
        for g in gaps:
            md.append(f"- **{g.get('gap_id','GAP')}** ({g.get('severity','unknown')}): {g.get('description','')}")

    # Test management integration
    tms = data.get("test_management_integration", {}) or {}
    md.append("")
    md.append("## Test management integration")
    md.append(f"- **References present:** {tms.get('presence_of_reference_to_test_management_system','unknown')}")
    systems = tms.get("systems_detected", []) or []
    if systems:
        md.append(f"- **Systems detected:** {', '.join(systems)}")
    refs = tms.get("references_detected", []) or []
    if refs:
        md.append("\n### References detected")
        for r in refs:
            ex = ", ".join(r.get("examples", []) or [])
            md.append(f"- {r.get('system','')} pattern `{r.get('pattern','')}` examples: {ex}")

    # Documentation
    docq = data.get("documentation_quality", {}) or {}
    md.append("")
    md.append("## Documentation quality")
    md.append(f"- **How well documented:** {docq.get('how_well_documented','unknown')}")
    md.append(f"- **Score:** {docq.get('score',0)}/100")
    dgaps = docq.get("gaps", []) or []
    md.append("\n### Documentation gaps\n" + _fmt_list(dgaps))
    drec = docq.get("recommendations", []) or []
    if drec:
        md.append("\n### Documentation recommendations")
        for r in drec:
            if isinstance(r, str):
                md.append(f"- {r}")
            else:
                md.append(f"- **{r.get('title','')}** (effort: {r.get('effort','S')}, days: {r.get('effort_days','1')})")

    # Action plan
    ap = data.get("action_plan", []) or []
    md.append("")
    md.append("## Action plan")
    if not ap:
        md.append("_No action plan._")
    else:
        for item in ap:
            md.append("")
            md.append(f"### P{item.get('priority','?')}: {item.get('title','')}")
            if item.get("goal"):
                md.append(f"**Goal:** {item.get('goal')}")
            if item.get("expected_impact"):
                md.append(f"**Expected impact:** {item.get('expected_impact')}")
            tasks = item.get("tasks", []) or []
            if tasks:
                md.append("\n**Tasks**")
                for t in tasks:
                    md.append(f"- [{t.get('task_id','')}] {t.get('description','')} (owner: {t.get('owner_role','')}, days: {t.get('effort_days','?')})")

    # Appendix
    md.append("")
    md.append("## Appendix")
    md.append("```json")
    md.append(json.dumps(data.get("appendix", {}), indent=2, ensure_ascii=False))
    md.append("```")

    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(md).rstrip() + "\n")

if __name__ == "__main__":
    main()
