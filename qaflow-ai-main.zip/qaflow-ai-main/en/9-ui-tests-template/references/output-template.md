# UI Tests — Output Structure

## `ui-mapping.json`

Schema, fields, and worked examples (single-page, multi-page flow,
reused vs. created Page Object, pending entry) — in
references/ui-mapping-schema.md. Generate this before any `.spec.ts`
file; the Playwright files are rendered from it.

## `package.json` (only when scaffolding a self-contained folder)

```json
{
  "name": "<issuekey-lowercase>-ui-tests",
  "private": true,
  "version": "1.0.0",
  "scripts": {
    "test": "playwright test"
  },
  "devDependencies": {
    "@playwright/test": "<pinned exact version, e.g. 1.62.1 — check the current release, don't guess>"
  }
}
```

Unlike API tests, this needs real browser binaries — note the install
step in `README.md` (`npx playwright install chromium`).

## `README.md`

```
# <ISSUEKEY> - UI Tests

## Prerequisites
- Node.js <version used/assumed>
- The application under test running and reachable at <baseURL>

## Install
<cd <ISSUEKEY>/ui-tests && npm install>
  — or, if reusing an existing codebase install: <cd <path> && npm install>
<npx playwright install chromium>
  — installs the browser binary; skip only if the reused codebase
  install already has it.

## Run
<npm test>
  — or the equivalent command for an existing codebase's test script

## View Report
<npx playwright show-report>
  — opens the HTML report from the last run. Failing tests include a
  trace, a screenshot, and a video — open the trace to scrub through
  the exact DOM/network/console state at each test.step.

## Notes
- <any environment variable, login, or seed-data requirement the tests
  assume>
- Page Objects used by these tests live in the shared `ui-framework/pages/`
  folder at the repository root, not inside this folder — they're
  reused across issues.
- Deferred and pending test cases (see summary.md) are not included in
  this run.
```

Keep this file short — it's the copy-paste path for a person who has
never seen this folder before, not a restatement of summary.md.

## Generated `.spec.ts` file shape

See references/playwright-ui-conventions.md for the full generation
rules. Each file starts with the Playwright import and an import of the
Page Object(s) it needs from `../../ui-framework/pages/...`, any
`[test data]` constants, then one `test()` block per TC-REQ item in
that REQ group, each with `test.step` phases and Page-Object-backed
assertions.

## `summary.md`

```
# <ISSUEKEY> - UI Tests Summary

Test cases: <path to test-cases file>
Automation strategy: <path to automation-strategy file>
Codebase reference: <path, or "not provided">
Live discovery: <yes, see discovery/pages.json / not needed / not provided>
UI mapping: <ISSUEKEY>/ui-tests/ui-mapping.json
Generated: <YYYY-MM-DD>

## Selection Checkpoint

UI-classified test cases available: <N>
Selected for this run: <N>
Deferred by user: <N>

| TC-REQ | Scenario | Decision |
|--------|----------|----------|
| TC-REQ-1.1 | Registration page is accessible to an unauthenticated visitor | Selected |
| TC-REQ-2a.2 | Email field accepts a value in the standard local@domain format | Deferred by user |

## Traceability

| TC-REQ | Scenario | Test File | Test Name | Status |
|--------|----------|-----------|-----------|--------|
| TC-REQ-1.1 | Registration page is accessible to an unauthenticated visitor | registration-page-access.spec.ts | TC-REQ-1.1: Registration page is accessible to an unauthenticated visitor | Generated |
| TC-REQ-8.3 | Password strength meter updates as the user types | password-strength.spec.ts | — | Pending — selector needed |

## Page Objects

| Page Object | File | Status | Used By |
|-------------|------|--------|---------|
| RegistrationPage | ui-framework/pages/RegistrationPage.ts | Reused (extended) | TC-REQ-1.1, TC-REQ-4.1 |
| LoginPage | ui-framework/pages/LoginPage.ts | Created | TC-REQ-1.2 |

## Selector Fragility Notes

Omit this section entirely if no CSS/XPath selector was used.

| TC-REQ | Element | Selector | Why not role/label/testid |
|--------|---------|----------|----------------------------|
| TC-REQ-8.3 | strength meter bar | `.password-strength-bar` | No accessible name, label, or test id distinguishes it from the input |

## Cleanup Coverage

| TC-REQ | Creates persistent data? | Cleanup |
|--------|--------------------------|---------|
| TC-REQ-1.2 | Yes (account, via prior login precondition) | DELETE /api/Users/:id (confirmed available) |
| TC-REQ-1.1 | No | N/A |

Omit rows for TC-REQ items whose steps create no persistent resource,
or keep the section short by only listing exceptions — always include
this section if at least one generated test creates persistent data.

## How to Run

See `README.md` for install/run instructions.

Existing Playwright setup detected: <yes, at <path> / no — scaffolded new config and package.json>

## Pending Clarifications

- TC-REQ-X.Y: <what was asked, still unanswered>
```

Section Rules:
- Selection Checkpoint — always present; lists every UI-classified
  TC-REQ item with its Selected/Deferred decision.
- Traceability table — one row per *selected* TC-REQ item, including
  pending ones.
- Page Objects table — always present when at least one test was
  generated; lists every Page Object touched this run, whether reused
  or newly created.
- Selector Fragility Notes — only present when at least one CSS/XPath
  selector was used; omit otherwise.
- Pending Clarifications — only present when at least one item is
  pending; omit the section entirely otherwise.
- How to Run — always present, must state whether an existing config
  was reused or a new one scaffolded.
