# VCS Setup

> ⚠️ **CONFIGURE:** fill out this file with the Git CLI setup for your
> version control system. Replace all `<placeholders>` with real values.
> After filling in — delete these ⚠️ CONFIGURE blocks.

## CLI

- **VCS:** `<GitHub / GitLab / Bitbucket / Azure DevOps / other>`
- **CLI tool:** `<gh / glab / az devops / other>`
- **Install command:** `<how your team installs the CLI>`
- **Auth command:** `<e.g. gh auth login>`
- **Verify access command:** `<e.g. gh pr view --help>`

## PR / Merge Request Access

- **PR URL format:** `<e.g. https://github.com/owner/repo/pull/123>`
- **View PR command:** `<e.g. gh pr view <URL>>`
- **Diff command:** `<e.g. gh pr diff <URL>>`
- **Read file at ref command:** `<e.g. gh api ... ?ref={branch}>`

## Notes

- `<any team-specific VCS conventions: default branch name, required
  permissions, proxy/VPN requirements, etc.>`
