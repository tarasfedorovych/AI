# QAPR-0002 - UI Tests Summary

Test cases: c:\src\!QA pipeline\QAPR-0002\test-cases.md
Automation strategy: c:\src\!QA pipeline\QAPR-0002\automation-strategy.md
Codebase reference: c:\src\!QA pipeline\juice-shop-master (read-only)
Live discovery: yes, see discovery/pages.json
UI mapping: QAPR-0002/ui-tests/ui-mapping.json
Generated: 2026-09-04

## Selection (budget-driven curation — silent/autonomous run)

This run had no human checkpoint (the ui-tests skill's own Selection
Checkpoint, and the coordinator's, were both intentionally skipped for
this autonomous run — see the task's "silent mode" instructions). 13
TC-REQ items are classified `UI` in automation-strategy.md. Combined with
the 22 API tests generated in `../api-tests/`, the running total was 35 of
the at-most-50 budget — comfortably enough headroom to generate **all 13**
UI-classified items rather than curating further, unlike the API suite
(which did need to defer/skip 3 of its 25 classified items). None deferred.

| TC-REQ | Scenario | Decision |
|--------|----------|----------|
| TC-REQ-1.1 | Login page is accessible to an unauthenticated visitor | Selected |
| TC-REQ-2c.1 | Remember Me control present and toggleable | Selected |
| TC-REQ-3.1 | Unauthenticated visitor can view/interact with login fields | Selected |
| TC-REQ-4.1 | Email/Password empty displays a validation error | Selected |
| TC-REQ-4.2 | Whitespace-only Email treated as empty/non-matching | Selected |
| TC-REQ-5.1 | Password field masked by default | Selected |
| TC-REQ-12.1 | Successful login navigates away from the login form | Selected |
| TC-REQ-13.1 | Failed login displays an appropriate error | Selected |
| TC-REQ-13.2 | Failed-login error has no internal details | Selected |
| TC-REQ-21.6 | Refresh after login preserves authenticated state | Selected |
| TC-REQ-23.1 | AC-002 invalid credentials — fails, no session, error shown | Selected |
| TC-REQ-24.1 | AC-003 missing credentials — validation error shown | Selected |
| TC-REQ-26.1 | AC-005 expired/invalid session — access rejected | Selected |

## Traceability

| TC-REQ | Scenario | Test File | Test Name | Status |
|--------|----------|-----------|-----------|--------|
| TC-REQ-1.1 | Login page is accessible to an unauthenticated visitor | login-page-access.spec.ts | TC-REQ-1.1: ... | Generated |
| TC-REQ-2c.1 | Remember Me control is present and can be toggled | remember-me-field.spec.ts | TC-REQ-2c.1: ... | Generated |
| TC-REQ-3.1 | Unauthenticated visitor can view and interact with the login fields | login-field-visibility.spec.ts | TC-REQ-3.1: ... | Generated |
| TC-REQ-4.1 | Submitting with Email or Password left completely empty does not authenticate | login-mandatory-field-validation.spec.ts | TC-REQ-4.1: ... | Generated |
| TC-REQ-4.2 | Submitting with a mandatory field containing only whitespace is treated as empty | login-mandatory-field-validation.spec.ts | TC-REQ-4.2: ... | Generated |
| TC-REQ-5.1 | Password field masks its entered value by default | password-field-masking.spec.ts | TC-REQ-5.1: ... | Generated |
| TC-REQ-12.1 | Successful login navigates the user away from the login form | login-post-login-navigation.spec.ts | TC-REQ-12.1: ... | Generated |
| TC-REQ-13.1 | A failed login attempt displays an appropriate error message | login-error-messaging.spec.ts | TC-REQ-13.1: ... | Generated |
| TC-REQ-13.2 | A failed-login error contains no stack trace, raw database error, or internal identifier | login-error-messaging.spec.ts | TC-REQ-13.2: ... | Generated |
| TC-REQ-21.6 | Refreshing the page immediately after a successful login preserves the authenticated state | login-refresh-session-persistence.spec.ts | TC-REQ-21.6: ... | Generated |
| TC-REQ-23.1 | Incorrect credentials fail login, create no session, and display an appropriate error | login-e2e-invalid-credentials.spec.ts | TC-REQ-23.1: ... | Generated |
| TC-REQ-24.1 | Missing email or password prevents successful login and shows a validation error | login-e2e-missing-credentials.spec.ts | TC-REQ-24.1: ... | Generated |
| TC-REQ-26.1 | Expired/invalid session rejects authenticated access and triggers the re-authentication flow | login-e2e-expired-session.spec.ts | TC-REQ-26.1: ... | Generated |

## Page Objects

| Page Object | File | Status | Used By |
|-------------|------|--------|---------|
| LoginPage | ui-framework/pages/LoginPage.ts | Extended (pre-existing from QAPR-0001) | All 13 TC-REQs except TC-REQ-26.1 |
| (helper) dismissOverlays | ui-framework/pages/dismissOverlays.ts | Reused (pre-existing) | LoginPage.goto, and directly in login-e2e-expired-session.spec.ts |

`LoginPage` already existed (created by `QAPR-0001` for its one login-page
test case, TC-REQ-1.2 there) with `emailInput`, `passwordInput`,
`loginButton`, `goto()`, `login()`. This run **extended** it — never
removed or renamed anything — adding: `rememberMeCheckbox`,
`emailRequiredError`, `passwordRequiredError`, `invalidCredentialsError`,
`accountMenuButton`, `logoutMenuItem`, `fillEmail()`, `fillPassword()`,
`setRememberMe()`, `touchField()`, and `isAuthenticated()`.

TC-REQ-26.1 is the one test with no dedicated Page Object: it checks a
route guard (`LoginGuard`) on a page (`/#/address/saved`) that isn't the
login page itself, using a one-off inline `getByText` locator plus the
shared `dismissOverlays` helper — a dedicated Page Object for that page
would be needless for a single guard-check assertion.

## Discovered Selector Facts (why they differ from a generic reference doc)

- Live discovery (`discovery/pages.json`) confirmed the login page's
  control names exactly as `QAPR-0001`'s own discovery pass found them
  (Email: "Text field for the login email"; Password: "Text field for the
  login password"; submit: "Login"; Remember Me: "Checkbox to stay logged
  in or not logged in") — reused as-is, no new selectors needed there.
- A second live discovery pass (also in `discovery/pages.json`, entry
  `"account-menu-authenticated"`) was run specifically for this issue,
  after logging in and opening the navbar account menu. It revealed that
  the menu's "Logout" control — despite having `aria-label="Logout"` in
  `navbar.component.html` — is rendered as an Angular Material
  `mat-menu-item`, whose accessible **role is `menuitem`, not `button`**.
  An initial version of `LoginPage.logoutMenuItem` used
  `getByRole('button', ...)` and would not have matched; fixed to
  `getByRole('menuitem', ...)` based on this discovery, before any test
  was run against it.
- `MANDATORY_EMAIL` / `MANDATORY_PASSWORD` / the raw server error text
  were confirmed by reading `login.component.html` and
  `frontend/src/assets/i18n/en.json` directly (source: codebase), the
  same convention `RegistrationPage`'s error locators already use.

## Selector Fragility Notes

One CSS/XPath-free exception aside, every locator uses `getByRole`
(confirmed accessible name/role) or `getByText` (confirmed literal/
translated string) — no CSS/XPath selector was used anywhere in this run.

## Cleanup Coverage

| TC-REQ | Creates persistent data? | Cleanup |
|--------|---------------------------|---------|
| TC-REQ-12.1, TC-REQ-21.6 | Yes (account, seeded via direct API call) | None available — see below |
| TC-REQ-1.1, 2c.1, 3.1, 4.1, 4.2, 5.1, 13.1, 13.2, 23.1, 24.1, 26.1 | No | N/A |

**No cleanup mechanism is available**, for the same reason documented in
`QAPR-0002/api-tests/summary.md`: `DELETE /api/Users/:id` is wired to
`security.denyAll()` in `server.ts` and unconditionally rejects every
request, including one carrying a valid bearer token. Every account is
seeded with a unique generated email so re-runs never collide with a
previous run's leftovers, but the accounts themselves are never removed.

## How to Run

See `README.md` for install/run instructions, including the required
`--workers=1` flag and (in a proxied environment) `NO_PROXY`.

Existing Playwright setup detected: no — `juice-shop-master` uses Cypress
for e2e, not Playwright. A new `playwright.config.ts` and `package.json`
were scaffolded in this folder, matching `QAPR-0001/ui-tests`'s convention.

## Run Results (confirmed, `npx playwright test --workers=1`)

**13 of 13 tests pass consistently**, run 3 times in a row.

The default parallel-worker run (`npm test`, 3 workers) was also tried, to
compare against `--workers=1`: it produced **7 of 13 tests failing** with
timeouts on account-menu/field interactions — the same class of dev-server
contention under concurrent browser load that `QAPR-0001/ui-tests/summary.md`
documents for its own suite. `--workers=1` is required here, not just
recommended, and is called out as such in `README.md`.

**Two issues were found and fixed by actually running the suite** (not
visible from reading the generated code alone):

1. **`logoutMenuItem`'s accessible role.** The initial locator used
   `getByRole('button', { name: 'Logout' })` based on the aria-label alone.
   A live discovery snapshot (see Discovered Selector Facts above) showed
   the menu item's actual role is `menuitem` (an Angular Material
   `mat-menu-item`); fixed before running any test against it.
2. **TC-REQ-26.1's assertion target.** The first version asserted
   `expect(page).toHaveURL(/#\/403/)`, which failed: `LoginGuard.forbidRoute()`
   calls `router.navigate(['403'], { skipLocationChange: true, ... })`, and
   `skipLocationChange: true` means the URL bar never actually changes —
   only the rendered component does. The fix asserts on the rendered "403"
   page's own message text instead of the URL. A second, smaller issue
   surfaced in the same test: `error-page.component.html` renders "403"
   and the translated `{{error}}` message ("Please login to view this
   page.") as two separate DOM elements, so a `getByText` search for the
   combined string ("403 Please login to view this page.", as an ARIA
   snapshot's flattened text line might suggest is one node) found nothing;
   fixed to search for the message span's own text alone. Neither issue was
   an application defect — both were test-locator mistakes caught and
   fixed by actually running the suite against the live app, exactly the
   kind of thing this pipeline's "run it, don't just generate it" rule
   exists to catch.

No genuinely failing assertion remains in this suite (unlike the API
suite's 3 documented findings) — every discovered gap here was a test
construction issue, not an application behavior gap. One requirement-level
discovery did correct an assumption without producing a test failure: see
`login-e2e-expired-session.spec.ts`'s comment on `LoginGuard`'s actual
re-authentication behavior (an in-place 403 message, not a navigation back
to `/#/login` as `requirements.md`'s REQ-26 originally assumed).

Run `npx playwright show-report` for the full report, including a
trace/screenshot/video for every step of every test.

## Pending Clarifications

None. Every UI-classified TC-REQ selected for this run had a confirmed
selector/page and was generated.

## Discovery Notes (not pending, but relevant to generated tests)

- `login.component.ts`'s `login()` redirects to
  `route.snapshot.queryParamMap.get('redirectUrl') ?? '/search'` after a
  successful login — confirmed in the codebase and used directly for
  TC-REQ-12.1's assertion, resolving `requirements.md`'s REQ-12 "exact
  destination TBD" assumption to a concrete destination (`/#/search`).
- `login.component.ts`'s `emailControl`/`passwordControl` use only
  `Validators.required` (no trim), and the Login button's `[disabled]`
  binding checks the raw truthy value of each control — a whitespace-only
  string is truthy, so it neither triggers the required-error nor keeps
  the button disabled. This is why TC-REQ-4.2 asserts the whitespace-only
  Email is rejected the same generic way as any other non-matching
  credential, rather than by a "required" message — the test case's own
  wording allows this outcome, so no assertion needed weakening.
- `LoginGuard` (`frontend/src/app/app.guard.ts`) checks only
  `localStorage.getItem('token')` truthiness — it does not decode or
  validate the token client-side at all. A malformed/tampered token would
  still pass this client-side guard (unlike the server's own
  `isAuthorized()` middleware, which does verify the signature — see
  `QAPR-0002/api-tests/summary.md`'s TC-REQ-11.1/11.2). This is why
  TC-REQ-26.1 uses a **missing** token (not a malformed one) as its
  practical stand-in for "expired/invalid" — a malformed token would not
  actually trigger this particular guard the way the test case intends.
