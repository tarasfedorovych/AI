import type { APIResponse, TestInfo } from '@playwright/test';

// Attaches the full request/response exchange to the test's own output
// (visible in the HTML report and as a testInfo attachment) so a failure
// is understandable from the test's own output alone - no need to open
// the source file or re-run it. Call once per request, with a short
// label describing that specific call's intent. Returns the parsed body -
// use it for subsequent assertions instead of calling .json()/.text()
// again on the same response.
export async function attachExchange(
  testInfo: TestInfo,
  label: string,
  requestInfo: { method: string; url: string; body?: unknown; headers?: Record<string, string> },
  response: APIResponse
): Promise<any> {
  const responseBody = await response.json().catch(() => response.text());
  await testInfo.attach(label, {
    body: JSON.stringify({ request: requestInfo, status: response.status(), response: responseBody }, null, 2),
    contentType: 'application/json',
  });
  return responseBody;
}

// Generates a unique, throwaway registration email for a given test label.
// No cleanup endpoint is available in this codebase (see summary.md /
// README.md — DELETE /api/Users/:id is `security.denyAll()`, confirmed in
// server.ts and empirically), so every test uses its own unique email
// instead of a shared literal, both to avoid cross-run collisions and to
// avoid depending on a previous run's leftover account.
export function uniqueEmail(label: string): string {
  return `qapr0002-${label}-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`;
}

// Decodes a JWT's payload (base64url, no signature verification - this
// helper is only used to inspect token *content* for assertions, never to
// trust it as authentic).
export function decodeJwtPayload(token: string): any {
  const payloadSegment = token.split('.')[1];
  const base64 = payloadSegment.replace(/-/g, '+').replace(/_/g, '/');
  const json = Buffer.from(base64, 'base64').toString('utf8');
  return JSON.parse(json);
}
