# QAPR-0002 - Automation Strategy

Test cases: c:\src\!QA pipeline\QAPR-0002\test-cases.md
Code review: not provided
Generated: 2026-09-04

---

## REQ-1: Preconditions: The application is available; the login page is accessible; a registered account exists for successful-login scenarios.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-1.1 | Login page is accessible to an unauthenticated visitor | UI | Expected result is "Login page loads and is displayed" — verifiable only by reading rendered page content. |

---

## REQ-2c: Login Field — Remember Me (if supported — uses configured persistent-session behavior).

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-2c.1 | Remember Me control is present and can be toggled | UI | Expected results are "Control is visible" and "Control reflects the checked/unchecked state" — rendered-control checks. |

---

## REQ-3: LOGIN-001: The system shall allow unauthenticated users to access the login form.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-3.1 | Unauthenticated visitor can view and interact with the login fields | UI | Every expected result is a visibility/interactability check ("Field is visible and accepts input", "Control is visible") — inherently rendered-page verification. |

---

## REQ-4: LOGIN-002: The system shall require email and password.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-4.1 | Submitting with Email or Password left completely empty does not authenticate | UI | Expected result is "a validation error is displayed or submission is prevented" — rendered-form/control state. |
| TC-REQ-4.2 | Submitting with a mandatory field containing only whitespace is treated as empty | UI | Expected result concerns whether whitespace is "treated as valid input" at the form level — rendered/control state, same pattern as TC-REQ-4.1. |

---

## REQ-5: LOGIN-003: The password field shall obscure its value by default.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-5.1 | Password field masks its entered value by default | UI | Verifying that characters are "rendered obscured" is inherently a rendered-page/visual-state check — cannot be confirmed from a response body. |

---

## REQ-6: LOGIN-004: The system shall authenticate a user when valid credentials for an eligible account are provided.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-6.1 | Valid credentials for an existing account authenticate successfully | API | Expected result is "Authentication succeeds" — a backend/session state, confirmable via the login endpoint's response (status/token), with no rendered content referenced. |

---

## REQ-7: LOGIN-005: The system shall reject an unknown email or incorrect password.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-7.1 | Submitting an email that does not match any existing account is rejected | API | Expected result "Login is rejected" is a backend/response state, with no displayed content referenced. |
| TC-REQ-7.2 | Submitting a correct/existing email with an incorrect password is rejected | API | Same pattern — "Login is rejected" is a backend/response state. |

---

## REQ-8: LOGIN-006: Failed authentication shall not create an authenticated session.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-8.1 | A rejected login attempt does not establish an authenticated session | API | Expected result "Request is not granted as authenticated" is confirmed by making a subsequent request and inspecting its response/status — no rendered content involved. |

---

## REQ-9: LOGIN-007: Successful authentication shall establish a session associated with the correct user.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-9.1 | The session established after login identifies the same account that authenticated | API | Step is to "inspect the identity associated with the established session" — a backend/token-payload or response-field check, not rendered content. |

---

## REQ-10: LOGIN-008: The authenticated state shall persist while the session remains valid.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-10.1 | Authenticated state persists across subsequent navigation/requests while the session is valid | API | Expected result "User remains authenticated" is verifiable by issuing a subsequent authenticated request and checking its response, independent of how anything is rendered. |

---

## REQ-11: LOGIN-009: Expired or invalid sessions/tokens shall not provide authenticated access.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-11.1 | A malformed session/token value does not grant authenticated access | API | Step explicitly "presents" a token value on a direct request to authenticated-only data; expected result "the request is treated as unauthenticated" is a response/status check. |
| TC-REQ-11.2 | A tampered session/token value does not grant authenticated access | API | Same pattern — a crafted token value is presented directly on a request, and the response/status is checked. |

---

## REQ-12: LOGIN-010: After successful login, the user shall be navigated according to the configured product flow.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-12.1 | Successful login navigates the user away from the login form | UI | Expected result "User is navigated away from the login form to the ... destination" is a navigation/rendered-page outcome. |

---

## REQ-13: LOGIN-011: Failed login shall display an appropriate error without exposing sensitive internal details.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-13.1 | A failed login attempt displays an appropriate error message | UI | Expected result is explicitly "An appropriate error message is displayed to the user" — rendered content. |
| TC-REQ-13.2 | A failed-login error contains no stack trace, raw database error, or internal identifier | UI | The test case's own step says "inspect the displayed/returned error content", leaving displayed-vs-returned ambiguous. Resolved autonomously: classified UI, consistent with the equivalent registration requirement (TC-REQ-14.1 in QAPR-0001), since the rendered error is the stricter/superset check and the raw response body is separately API-checkable as part of the same assertion. |

---

## REQ-14: LOGIN-012: Authentication shall be performed by a trusted server-side mechanism.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-14.1 | A login request bypassing client-side logic with invalid credentials is still rejected server-side | API | Step explicitly bypasses the UI ("Send a login request directly to the server-side login endpoint, bypassing the UI/client-side logic"), and the expected result ("no session is established") is a response/backend-state check. |

---

## REQ-15: BR-LOGIN-001: Only valid credentials for an eligible account may establish an authenticated session.

No test cases in this requirement group — it restates the authentication-gate rule already covered by REQ-6/REQ-7/REQ-8, per the cross-reference note in test-cases.md.

---

## REQ-16: BR-LOGIN-002: Passwords shall never be stored or logged in plaintext; they are hashed at rest, never written to logs, and never returned in any API response or error output.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-16.1 | The submitted Password value is not returned in any login API response, including error responses | API | Step explicitly says "inspect the response bodies", and the expected result concerns API response content directly. |
| TC-REQ-16.2 | The issued session/token does not contain the plaintext Password value | API | Step is to "inspect the content of the issued session/token" — a token-payload check, not rendered content. |

---

## REQ-17: BR-LOGIN-003: Credentials shall be transmitted securely in non-development environments.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-17.1 | Login data, including Password, is transmitted over a secure connection | Manual / Not automatable | Verification requires capturing and inspecting network traffic ("browser dev tools / proxy") for TLS/HTTPS usage — a transport-layer check that fits neither a rendered-UI assertion nor a response-body/status inspection, and is typically verified as environment/infrastructure configuration rather than scripted per test case. Resolved autonomously: Manual, consistent with QAPR-0001's precedent for the equivalent registration requirement (BR-REG-003 / TC-REQ-17.1 there). |

---

## REQ-18: BR-LOGIN-004: Authentication errors should not unnecessarily reveal whether a specific account exists.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-18.1 | The error for an unknown email is indistinguishable from the error for a correct email with an incorrect password | API | The check is a deterministic string-equality comparison between two response bodies/status codes, which doesn't require rendered content to confirm. Resolved autonomously: classified API since the comparison is most reliably automated at the response level; the frontend renders the same server-provided text one-for-one, so this is separately UI-observable but not the stricter requirement here. |

---

## REQ-19: BR-LOGIN-005: The login endpoint shall handle malicious or malformed input safely.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-19.1 | HTML/JavaScript-like input in Email or Password does not execute as script and does not authenticate | API | Expected result "the script does not execute; no session is established" is checkable via the response/session state — this app's failed-login error does not echo the submitted input back into rendered content, so there is no rendered-reflection risk to check separately. Resolved autonomously: classified API on that basis. |
| TC-REQ-19.2 | SQL-like syntax in Email or Password does not cause a database error or bypass authentication | API | Expected result ("no database error occurs; authentication is not bypassed") is a backend/response state, with no rendered content referenced. |
| TC-REQ-19.3 | Malformed input does not produce an unhandled server error | API | Step explicitly sends the request "directly to the server", and the expected result concerns the response status class (no 5xx) — a response check. |

---

## REQ-20: BR-LOGIN-006: Authentication tokens or session identifiers shall not contain passwords or be exposed in URLs.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-20.2 | The session/token is not required as a URL query-string parameter for a normal authenticated request | API | Expected result concerns the request mechanics of an authenticated call (header/cookie vs. URL) — a backend/protocol-level check, not rendered content. |

---

## REQ-21: Important Edge Cases (for grooming/test design coverage): empty email; empty password; unknown email; correct email with incorrect password; email with different letter case; leading/trailing whitespace in email; leading/trailing whitespace in password; very long input; Unicode and special-character input; HTML/JavaScript-like or SQL-like input; rapid repeated login attempts; network or authentication-service failure; page refresh immediately after login; expired, malformed, or tampered session/token.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-21.1 | Login with the registered email in a different letter case authenticates the same as the original case | API | Expected result "Authentication succeeds" is a backend/session state, with no rendered content referenced. |
| TC-REQ-21.2 | Login with the registered email padded with leading/trailing whitespace is handled consistently | API | Expected result ("either authenticated ... or rejected ...; no crash or unhandled error") is entirely a response/status-class check. |
| TC-REQ-21.3 | Very long input in Email or Password does not cause a crash or unhandled server error | API | Expected result concerns the response status class (no 5xx) for a direct submission — a response check. |
| TC-REQ-21.4 | Unicode/special-character input in Email or Password does not cause a crash and is rejected generically | API | Expected result ("rejected the same generic way...no crash") is a response/status-class and body-content check. |
| TC-REQ-21.5 | Repeated rapid login attempts with incorrect credentials do not cause a crash or unhandled server error | API | Expected result concerns response status class across repeated direct requests — no rendered content involved. |
| TC-REQ-21.6 | Refreshing the page immediately after a successful login preserves the authenticated state | UI | The step is specifically "refresh the page" — a literal browser action only exercisable through an actual browser/page, not a direct request, matching the same reasoning QAPR-0001 applied to its browser-gesture-driven repeat-submission test cases (e.g. TC-REQ-18.2 there). |

---

## REQ-22: AC-LOGIN-001 (Successful Login): Given an eligible registered customer exists, when the customer submits the correct email and password, then authentication succeeds and a valid session is established for the correct customer.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-22.1 | End-to-end successful login authenticates and establishes a session for the correct customer | API | Both expected results ("Authentication succeeds", "a valid session is established, identifying the correct customer") are backend/session states, with no displayed content referenced — unlike QAPR-0001's equivalent registration test case, which explicitly required a displayed success indication. |

---

## REQ-23: AC-LOGIN-002 (Invalid Credentials): Given the submitted credentials are incorrect, when login is attempted, then authentication fails, no authenticated session is created, and an appropriate error is displayed.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-23.1 | Incorrect credentials fail login, create no session, and display an appropriate error | UI | Expected result explicitly includes "an appropriate error is displayed" — rendered content, making UI the overall (stricter) classification even though the no-session part is separately API-checkable. |

---

## REQ-24: AC-LOGIN-003 (Missing Credentials): Given email or password is missing, when login is submitted, then authentication does not succeed and an appropriate validation error is displayed.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-24.1 | Missing email or password prevents successful login and shows a validation error | UI | Expected result explicitly includes "an appropriate validation error is displayed" — rendered content. |

---

## REQ-25: AC-LOGIN-004 (Session Persistence): Given the customer successfully logged in, when the customer navigates within the application while the session is valid, then the customer remains authenticated.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-25.1 | Customer remains authenticated while navigating with a valid session | API | Expected result "Customer remains authenticated" is a session-state check confirmable via a subsequent authenticated request, independent of how navigation itself is rendered. Resolved autonomously: classified API on the same basis as TC-REQ-10.1, since no specific rendered content is named as part of the check. |

---

## REQ-26: AC-LOGIN-005 (Expired Session): Given the customer's session has expired, when authenticated functionality is requested, then authenticated access is rejected and the application follows the configured re-authentication behavior.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-26.1 | Expired/invalid session rejects authenticated access and triggers the re-authentication flow | UI | Step 2's expected result explicitly names a navigation/rendered outcome ("the application follows its configured re-authentication behavior (e.g. returns the user to the login form)"), making UI the overall classification even though step 1's rejection is separately API-checkable. |

---

## REQ-27: AC-LOGIN-006 (Backend Failure): Given authentication cannot be completed because of a backend failure, when login is attempted, then a controlled error is shown and the user remains unauthenticated.

| TC-REQ | Scenario | Recommendation | Rationale |
|--------|----------|-----------------|-----------|
| TC-REQ-27.1 | Backend failure during login produces a controlled error, not a raw system error | API | The scenario is driven by a backend fault-injection mechanism and the expected result concerns an error's content/type ("no raw system or server error ... is displayed"), naturally checked via the response body/status. Resolved autonomously: classified API, consistent with QAPR-0001's precedent for the equivalent registration acceptance criterion (AC-REG-005), where the same reasoning was applied and the test ultimately needed a fault-injection mechanism that was not discoverable. |
| TC-REQ-27.2 | The user remains unauthenticated after a backend failure during login | API | Step is to "inspect the user's authentication state" — a backend/session-state check, with no display referenced. |

---

## Statistics

| Recommendation | Count |
|-----------------|-------|
| API | 25 |
| UI | 13 |
| Manual / Not automatable | 1 |
| Total | 39 |
