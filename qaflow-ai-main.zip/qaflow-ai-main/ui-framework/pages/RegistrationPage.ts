// Page: /#/register — user registration form (Juice Shop)
import type { Page, Locator } from '@playwright/test';
import { dismissOverlays } from './dismissOverlays';

export class RegistrationPage {
  readonly page: Page;
  readonly emailInput: Locator;
  readonly passwordInput: Locator;
  readonly repeatPasswordInput: Locator;
  readonly securityQuestionSelect: Locator;
  readonly securityAnswerInput: Locator;
  readonly registerButton: Locator;
  readonly alreadyCustomerLink: Locator;
  readonly emailRequiredError: Locator;
  readonly emailInvalidFormatError: Locator;
  readonly passwordRequiredError: Locator;
  readonly repeatPasswordRequiredError: Locator;
  readonly securityAnswerRequiredError: Locator;

  constructor(page: Page) {
    this.page = page;
    this.emailInput = page.getByRole('textbox', { name: 'Email address field' });
    this.passwordInput = page.getByRole('textbox', { name: 'Field for the password' });
    this.repeatPasswordInput = page.getByRole('textbox', { name: 'Field to confirm the password' });
    this.securityQuestionSelect = page.getByRole('combobox', { name: 'Selection list for the security question' });
    this.securityAnswerInput = page.getByRole('textbox', { name: 'Field for the answer to the security question' });
    this.registerButton = page.getByRole('button', { name: 'Button to complete the registration' });
    this.alreadyCustomerLink = page.getByRole('link', { name: 'Already a customer?' });
    this.emailRequiredError = page.getByText('Please provide an email address.');
    this.emailInvalidFormatError = page.getByText('Email address is not valid.');
    this.passwordRequiredError = page.getByText('Please provide a password.');
    this.repeatPasswordRequiredError = page.getByText('Please repeat your password.');
    this.securityAnswerRequiredError = page.getByText('Please provide an answer to your security question.');
  }

  async goto(): Promise<void> {
    // A same-document, hash-only navigation (e.g. from /#/search or from
    // /#/register to itself) is unreliable here — confirmed empirically:
    // page.goto('/#/register') from another hash route left the browser
    // on the previous URL with no error and no reload, silently leaving
    // the Angular reactive form's previous state/route in place. Routing
    // through about:blank first forces a genuine full-document load
    // every time, regardless of where the page currently is.
    await this.page.goto('about:blank');
    await this.page.goto('/#/register');
    await dismissOverlays(this.page);
  }

  async isRegistrationFormVisible(): Promise<boolean> {
    return this.emailInput.isVisible();
  }

  async fillEmail(value: string): Promise<void> {
    await this.emailInput.fill(value);
  }

  async fillPassword(value: string): Promise<void> {
    await this.passwordInput.fill(value);
  }

  async fillRepeatPassword(value: string): Promise<void> {
    await this.repeatPasswordInput.fill(value);
  }

  async fillSecurityAnswer(value: string): Promise<void> {
    await this.securityAnswerInput.fill(value);
  }

  async selectFirstSecurityQuestion(): Promise<string> {
    // A pointer click on the trigger is unreliable here: the mat-select's
    // own floating <mat-label> overlaps the clickable area until it
    // animates away, which Playwright's actionability check (correctly)
    // treats as "intercepts pointer events". Opening via keyboard (the
    // same interaction Material's own combobox pattern supports) avoids
    // depending on that animation's timing — but empirically still
    // occasionally fails to open on the first key press, so retry a
    // few times against the real opened-panel state rather than a
    // fixed sleep.
    const listbox = this.page.getByRole('listbox');
    let opened = false;
    for (let attempt = 0; attempt < 3 && !opened; attempt++) {
      await this.securityQuestionSelect.press('Enter');
      try {
        await listbox.waitFor({ state: 'visible', timeout: 3000 });
        opened = true;
      } catch {
        // try again
      }
    }
    if (!opened) {
      throw new Error('Security Question dropdown did not open after 3 attempts');
    }
    const firstOption = this.page.getByRole('option').first();
    const questionText = (await firstOption.textContent())?.trim() ?? '';
    await firstOption.click();
    // Selecting closes the panel, but its close animation can still
    // intercept clicks elsewhere on the page for a moment — wait for it
    // to actually detach before handing control back.
    await listbox.waitFor({ state: 'hidden', timeout: 3000 }).catch(() => {});
    return questionText;
  }

  async fillMandatoryFields(data: { email: string; password: string; securityAnswer: string }): Promise<void> {
    await this.fillEmail(data.email);
    await this.fillPassword(data.password);
    await this.fillRepeatPassword(data.password);
    await this.selectFirstSecurityQuestion();
    await this.fillSecurityAnswer(data.securityAnswer);
  }

  // The Register button stays disabled while any mandatory control is
  // invalid, so a required/format error can only be observed by
  // touching the target field directly — clicking the (disabled)
  // submit button would just time out waiting to become actionable.
  // Uses focus() rather than click(): an empty field's own floating
  // <mat-label> (with its required-marker asterisk) rests directly
  // over the input's clickable area until the field is focused, which
  // makes a plain click's pointer hit-test intercept on that label.
  // focus() sets focus directly without that hit-test.
  async touchField(field: Locator): Promise<void> {
    await field.focus();
    await field.blur();
  }

  async submitAndCaptureCreatedUserId(): Promise<number> {
    const [response] = await Promise.all([
      this.page.waitForResponse((res) => res.url().includes('/api/Users') && res.request().method() === 'POST'),
      this.registerButton.click(),
    ]);
    const body = await response.json();
    return body.data.id;
  }

  async registerNewAccount(data: { email: string; password: string; securityAnswer: string }): Promise<number> {
    await this.goto();
    await this.fillMandatoryFields(data);
    return this.submitAndCaptureCreatedUserId();
  }
}
