# API Mapping Schema — reference

`api-mapping.json` is a framework-agnostic array, one entry per
API-classified TC-REQ item (including pending ones). It captures the
endpoint-discovery decisions before any Playwright-specific code is
written, so they're reviewable on their own and reusable by a
different renderer later.

Do not force every test case into a single request/response shape —
several of the cases this skill actually has to cover are multi-step
chains or concurrent races. Use `steps: [...]` (one or more) for all
entries, even single-request ones, so the shape is uniform.

## Fields

```jsonc
{
  "tcReqId": "TC-REQ-11.1",
  "reqGroup": "REQ-11",
  "title": "Submitting valid registration data creates exactly one customer account",
  "status": "generated",          // "generated" | "pending"
  "reason": null,                  // required, non-null when status is "pending"
  "source": "swagger",             // "swagger" | "codebase" | "user-provided"
  "variables": {
    "email": "[test data] unique per run",
    "password": "[test data] valid mandatory data"
  },
  "steps": [
    {
      "name": "register",
      "method": "POST",
      "endpoint": "/api/Users",
      "body": { "email": "${email}", "password": "${password}", "passwordRepeat": "${password}" },
      "expectedStatus": 201,
      "capture": { "userId": "response.data.id" },
      "assertions": ["response.data.email equals ${email}"]
    }
  ],
  "concurrency": null,             // null, or see "Concurrent steps" below
  "cleanup": [
    { "method": "DELETE", "endpoint": "/api/Users/${userId}", "source": "codebase", "note": "confirmed available, no auth required" }
  ],
  "notes": []                       // e.g. substituted [test data] literals, discovery caveats
}
```

- `tcReqId` / `reqGroup` / `title` — copied verbatim from test-cases.md
  / automation-strategy.md. Never reworded.
- `status` — `"pending"` means no confident endpoint/mechanism was
  found; `reason` must explain what access or mechanism is missing (do
  not generate a `.spec.ts` test for this entry).
- `source` — where the step's endpoint/schema came from. Use
  `"user-provided"` only when the user answered a batched
  clarification question for this specific TC-REQ.
- `variables` — every `${placeholder}` used anywhere in `steps` or
  `cleanup` must be declared here, tagged `[test data]` when it's a
  realistic example rather than a literal value from the requirement.
- `steps` — ordered list. `capture` names values pulled from a step's
  response for use in a later step's `body`/`endpoint` (via the same
  `${name}` placeholder syntax). `assertions` are short, concrete,
  natural-language checks (mirroring the test case's own Expected
  Result) — not vague words like "correctly"/"appropriately".
- `cleanup` — one or more steps to run after the test, for any
  resource a step created. Omit the key entirely (not an empty array)
  only when the entry's steps create no persistent resource at all
  (e.g. a rejected-registration test). If a resource is created but no
  cleanup mechanism was found, keep the key with an empty array and
  say so in `notes` — don't just leave it out silently.

## Concurrent steps

For a race-condition test case, name the steps that must fire together
and set the mode:

```jsonc
"steps": [
  { "name": "submitA", "method": "POST", "endpoint": "/api/Users", "body": { "email": "${raceEmail}", "...": "..." } },
  { "name": "submitB", "method": "POST", "endpoint": "/api/Users", "body": { "email": "${raceEmail}", "...": "..." } }
],
"concurrency": { "parallelSteps": ["submitA", "submitB"] }
```

A renderer fires `parallelSteps` together (e.g. `Promise.all` in
Playwright) instead of sequentially.

## Pending entry example

```jsonc
{
  "tcReqId": "TC-REQ-16.1",
  "reqGroup": "REQ-16",
  "title": "Password value does not appear anywhere in application logs",
  "status": "pending",
  "reason": "No HTTP-accessible log-retrieval endpoint or file path was found in swagger.yml or the codebase. Requires direct filesystem/log-aggregator access or a user-specified log-retrieval mechanism.",
  "source": null,
  "variables": {},
  "steps": [],
  "concurrency": null,
  "notes": []
}
```

## Verification before writing `.spec.ts` files

- Every entry has `status` set.
- Every non-pending entry's `steps` reference only endpoints actually
  confirmed via swagger/codebase/user-answer (matches SKILL.md's
  "never invent" rule).
- Every `${placeholder}` used in `steps`/`cleanup` is declared in
  `variables` or produced by an earlier step's `capture`.
- Every entry whose steps create a persistent resource has a
  non-omitted `cleanup` key (populated, or empty with a `notes` entry
  explaining why).
