import { test, expect } from '@playwright/test';
import { attachExchange } from './helpers';

// REQ-2e: Registration Field — Security Answer must be compared case-sensitively.
//
// Endpoints discovered in juice-shop-master (not in swagger.yml):
//   POST /rest/user/reset-password  (routes/resetPassword.ts, wired in server.ts)
//     body: { email, answer, new, repeat }
//     - answer is compared via security.hmac(answer) === stored hmac(answer) — case-sensitive.
//     - mismatch -> 401 "Wrong answer to security question."
//     - match    -> 200 { user: <updated user> }
// Registration setup uses the swagger-documented flow:
//   POST /api/Users -> GET /api/SecurityQuestions -> POST /api/SecurityAnswers

const REGISTERED_EMAIL = `sec-answer-case-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per run
const REGISTRATION_PASSWORD = 'Val1dPassw0rd!'; // [test data]
const SECURITY_ANSWER = 'TestAnswer123'; // literal from test case precondition
const SECURITY_ANSWER_WRONG_CASE = 'testanswer123'; // literal from test case step 1
// reset-password requires a new/repeat password; not part of the test case's own data,
// but mandatory fields of the discovered endpoint contract.
const RESET_NEW_PASSWORD = 'ResetPassw0rd1';

// TC-REQ-2e.4
test('TC-REQ-2e.4: Security Answer comparison is case-sensitive', async ({ request }, testInfo) => {
  let userId!: number;

  await test.step('Arrange: register account with a security answer', async () => {
    const registerBody = { email: REGISTERED_EMAIL, password: REGISTRATION_PASSWORD, passwordRepeat: REGISTRATION_PASSWORD };
    const registerResponse = await request.post('/api/Users', { data: registerBody });
    const registerRespBody = await attachExchange(testInfo, 'register', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
    expect(registerResponse.status(), `expected 201 Created, got ${registerResponse.status()} - ${JSON.stringify(registerRespBody)}`).toBe(201);
    userId = registerRespBody.data.id;
  });

  try {
    let securityQuestionId!: number;
    await test.step('Arrange: fetch a security question id and set the security answer', async () => {
      const questionsResponse = await request.get('/api/SecurityQuestions');
      const questionsBody = await attachExchange(testInfo, 'list security questions', { method: 'GET', url: '/api/SecurityQuestions' }, questionsResponse);
      expect(questionsResponse.ok(), `expected security questions list to be retrievable, got ${questionsResponse.status()} - ${JSON.stringify(questionsBody)}`).toBeTruthy();
      securityQuestionId = questionsBody.data[0].id;

      const answerBody = { SecurityQuestionId: securityQuestionId, UserId: userId, answer: SECURITY_ANSWER };
      const answerResponse = await request.post('/api/SecurityAnswers', { data: answerBody });
      const answerRespBody = await attachExchange(testInfo, 'set security answer', { method: 'POST', url: '/api/SecurityAnswers', body: answerBody }, answerResponse);
      expect(answerResponse.status(), `expected 201 Created when setting the security answer, got ${answerResponse.status()} - ${JSON.stringify(answerRespBody)}`).toBe(201);
    });

    await test.step('Act & Assert: wrong-case answer is rejected', async () => {
      // Act (step 1) — provide the answer with a different letter case via the reset-password
      // verification mechanism
      const wrongCaseBody = { email: REGISTERED_EMAIL, answer: SECURITY_ANSWER_WRONG_CASE, new: RESET_NEW_PASSWORD, repeat: RESET_NEW_PASSWORD };
      const wrongCaseResponse = await request.post('/rest/user/reset-password', { data: wrongCaseBody });
      const wrongCaseRespBody = await attachExchange(testInfo, 'reset-password with wrong-case answer', { method: 'POST', url: '/rest/user/reset-password', body: wrongCaseBody }, wrongCaseResponse);

      // Assert (step 1) — value does not match; verification fails
      expect(wrongCaseResponse.status(), `expected 401 for a wrong-case security answer, got ${wrongCaseResponse.status()} - ${JSON.stringify(wrongCaseRespBody)}`).toBe(401);
    });

    await test.step('Act & Assert: original-case answer succeeds', async () => {
      // Act (step 2) — provide the answer in the original letter case via the same mechanism
      const originalCaseBody = { email: REGISTERED_EMAIL, answer: SECURITY_ANSWER, new: RESET_NEW_PASSWORD, repeat: RESET_NEW_PASSWORD };
      const originalCaseResponse = await request.post('/rest/user/reset-password', { data: originalCaseBody });
      const originalCaseRespBody = await attachExchange(testInfo, 'reset-password with original-case answer', { method: 'POST', url: '/rest/user/reset-password', body: originalCaseBody }, originalCaseResponse);

      // Assert (step 2) — value matches; verification succeeds
      expect(originalCaseResponse.ok(), `expected the original-case security answer to be accepted, got ${originalCaseResponse.status()} - ${JSON.stringify(originalCaseRespBody)}`).toBeTruthy();
    });
  } finally {
    // Cleanup — remove the account created above (DELETE /api/Users/:id, confirmed available)
    await request.delete(`/api/Users/${userId}`);
  }
});
