# UI Mapping Schema — reference

`ui-mapping.json` is a framework-agnostic array, one entry per selected
UI-classified TC-REQ item (including pending ones). It captures the
page/selector-discovery decisions before any Playwright-specific code is
written, so they're reviewable on their own and reusable by a different
renderer later.

Do not force every test case into a single-page shape — some flows span
more than one page or need a precondition set up on a different page
first. Use `steps: [...]` (one or more) for all entries, even
single-page ones, so the shape is uniform.

## Fields

```jsonc
{
  "tcReqId": "TC-REQ-4.1",
  "reqGroup": "REQ-4",
  "title": "Submitting with Email left completely empty displays a validation error for that field",
  "status": "generated",           // "generated" | "pending"
  "reason": null,                   // required, non-null when status is "pending"
  "source": "codebase",             // "codebase" | "live-discovery" | "user-provided"
  "page": {
    "name": "registration",
    "url": "/#/register",
    "pageObject": "RegistrationPage",
    "pageObjectStatus": "reused"    // "reused" | "created"
  },
  "variables": {
    "password": "[test data] valid mandatory data"
  },
  "steps": [
    {
      "name": "navigate",
      "action": "goto",
      "target": "registration page"
    },
    {
      "name": "submit-empty-email",
      "action": "fillMandatoryFields + submit",
      "target": "registration form",
      "data": { "email": "", "password": "${password}" }
    }
  ],
  "locators": [
    { "element": "emailInput", "strategy": "getByLabel", "value": "Email" },
    { "element": "errorMessage", "strategy": "getByRole", "value": "alert" }
  ],
  "assertions": ["error message contains 'Email'"],
  "cleanup": [],
  "notes": []
}
```

- `tcReqId` / `reqGroup` / `title` — copied verbatim from test-cases.md /
  automation-strategy.md. Never reworded.
- `status` — `"pending"` means no confident page/selector was found;
  `reason` must explain what discovery attempted and what's missing (do
  not generate a `.spec.ts` test for this entry).
- `source` — where the page/selector information came from. Use
  `"user-provided"` only when the user answered a batched clarification
  question for this specific TC-REQ.
- `page.pageObjectStatus` — `"reused"` when an existing Page Object in
  `ui-framework/pages/` already covered this page (possibly extended with
  new locators/methods); `"created"` when this run created the file for
  the first time.
- `variables` — every `${placeholder}` used anywhere in `steps` must be
  declared here, tagged `[test data]` when it's a realistic example
  rather than a literal value from the requirement.
- `locators` — every locator this entry's test needs, with its
  selector strategy (see the priority order in
  playwright-ui-conventions.md) and the value used to build it. If a
  locator already exists on the reused Page Object, list it anyway so
  the mapping stays a complete picture of what the generated test
  actually touches. Flag `"strategy": "css"` or `"xpath"` entries — they
  must also appear in the fragility notes in `summary.md`.
- `assertions` — short, concrete, natural-language checks (mirroring
  the test case's own Expected Result) — not vague words like
  "correctly"/"appropriately".
- `cleanup` — one or more steps to run after the test, for any
  resource created through the UI during this entry's steps. Omit the
  key entirely (not an empty array) only when the entry's steps create
  no persistent resource at all. If a resource is created but no
  cleanup mechanism was found, keep the key with an empty array and say
  so in `notes` — don't just leave it out silently.

## Pending entry example

```jsonc
{
  "tcReqId": "TC-REQ-8.3",
  "reqGroup": "REQ-8",
  "title": "Password strength meter updates as the user types",
  "status": "pending",
  "reason": "No codebase was provided and the running app's password field has no accessible name, label, or test id distinguishing the strength meter from the input itself — needs a user-confirmed selector or a codebase reference.",
  "source": null,
  "page": null,
  "variables": {},
  "steps": [],
  "locators": [],
  "assertions": [],
  "cleanup": [],
  "notes": []
}
```

## Verification before writing `.spec.ts` files

- Every entry has `status` set.
- Every non-pending entry's `page`/`locators` reference only pages and
  selectors actually confirmed via codebase/live-discovery/user-answer
  (matches SKILL.md's "never invent" rule).
- Every `${placeholder}` used in `steps` is declared in `variables`.
- Every entry whose steps create a persistent resource has a
  non-omitted `cleanup` key (populated, or empty with a `notes` entry
  explaining why).
- Every `"strategy": "css"` or `"xpath"` locator has a matching note in
  `notes` explaining why a higher-priority strategy didn't work.
