import { test, expect } from '@playwright/test';
import { attachExchange } from './helpers';

// REQ-16: BR-REG-002 — passwords are never returned in any API response.
// Endpoint: POST /api/Users. Discovery note: server.ts wires the User
// model into finale-rest with `exclude: ['password', 'totpSecret']`
// (server.ts autoModels list), so the generic create/read responses for
// this model never include the password field.
//
// TC-REQ-16.1 (password does not appear in application logs) and
// TC-REQ-16.3 (password is stored hashed at rest) are NOT covered in this
// file — see summary.md Pending Clarifications: no HTTP-accessible
// mechanism to inspect server logs or the raw stored record was found in
// the codebase or swagger doc.

const KNOWN_PASSWORD = 'Str0ngP@ss1'; // literal from test case
const SUCCESS_EMAIL = `password-exposure-success-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data]
const FAILURE_EMAIL = ''; // [test data] — empty, guarantees the 400 validation-error branch

// TC-REQ-16.2
test('TC-REQ-16.2: Password value is not returned in any API response, including error responses', async ({ request }, testInfo) => {
  // Act — submit a successful registration request using the known Password value
  const successRequestBody = { email: SUCCESS_EMAIL, password: KNOWN_PASSWORD, passwordRepeat: KNOWN_PASSWORD };
  const successResponse = await request.post('/api/Users', { data: successRequestBody });
  const successBodyText = await successResponse.text();
  await testInfo.attach('successful registration', {
    body: JSON.stringify({ request: { method: 'POST', url: '/api/Users', body: successRequestBody }, status: successResponse.status(), response: successBodyText }, null, 2),
    contentType: 'application/json',
  });
  expect(successResponse.status(), `expected 201 Created, got ${successResponse.status()} - ${successBodyText}`).toBe(201);
  const userId = JSON.parse(successBodyText).data.id;

  try {
    // Act — submit a registration request that fails validation, using the same known Password value
    const failureRequestBody = { email: FAILURE_EMAIL, password: KNOWN_PASSWORD, passwordRepeat: KNOWN_PASSWORD };
    const failureResponse = await request.post('/api/Users', { data: failureRequestBody });
    const failureBodyText = await failureResponse.text();
    await testInfo.attach('failed registration (empty email)', {
      body: JSON.stringify({ request: { method: 'POST', url: '/api/Users', body: failureRequestBody }, status: failureResponse.status(), response: failureBodyText }, null, 2),
      contentType: 'application/json',
    });
    expect(failureResponse.ok(), `expected registration to be rejected for an empty email, got ${failureResponse.status()} - ${failureBodyText}`).toBeFalsy();

    // Assert — the password value is not present in either response body
    expect(successBodyText, `expected the success response body to not contain the plaintext password`).not.toContain(KNOWN_PASSWORD);
    expect(failureBodyText, `expected the failure response body to not contain the plaintext password`).not.toContain(KNOWN_PASSWORD);
  } finally {
    // Cleanup — remove the account created by the successful registration above
    // (DELETE /api/Users/:id, confirmed available); the failed attempt created no account.
    await request.delete(`/api/Users/${userId}`);
  }
});
