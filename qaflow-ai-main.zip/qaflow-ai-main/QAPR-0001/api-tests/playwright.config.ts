import { defineConfig } from '@playwright/test';

// No playwright.config.ts / .js was found in the provided codebase folder
// (juice-shop-master), so this minimal config is scaffolded here.
// baseURL is the app's confirmed default dev port, not a placeholder.
export default defineConfig({
  reporter: [['html', { open: 'never' }]],
  use: {
    baseURL: 'http://localhost:3000',
  },
});
