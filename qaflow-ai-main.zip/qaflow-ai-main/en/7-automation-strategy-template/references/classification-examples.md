# Classification Examples — reference

Worked examples for calibration. Use the same reasoning shape, not the
same wording, when classifying real test cases.

## Example 1 — Clear API

**Test case:** "customer.subscription.created activates the
subscription" — precondition: a `customer.subscription.created` event
is received by the backend. Step: trigger the event. Expected result:
"Subscription is active in the backend."

**Recommendation:** API

**Rationale:** Trigger and verification are both backend-only — an
event is fired and the expected result is a backend state, with no
dependency on any rendered page.

## Example 2 — Clear UI

**Test case:** "Label 'State' is displayed above State select" —
precondition: page is open. Step: find the label. Expected result:
"Label with text 'State' is displayed above State select."

**Recommendation:** UI

**Rationale:** The expected result can only be confirmed by reading
rendered page content (a visible label and its position).

## Example 3 — Mixed, classified UI

**Test case:** "Successful subscription purchase" — steps: select
plan, submit payment, verify subscription is active (backend state),
verify a success message is displayed (rendered content), verify a
confirmation email is sent.

**Recommendation:** UI

**Rationale:** Two of the three expected results require reading
rendered content (page message) or an external side effect not
confirmable via a single API response (email sent), so UI is the
overall recommendation — the API-checkable subset (subscription
active) can still be covered as part of the same UI flow or reused by
an API test if convenient.

## Example 4 — Manual / Not automatable

**Test case:** "3D Secure authentication challenge" — expected result:
"Customer sees Stripe's hosted 3D Secure verification screen and can
complete or cancel it."

**Recommendation:** Manual

**Rationale:** The screen and its behavior are rendered and controlled
by a third-party (Stripe), not the product's own UI — scripting it
reliably is outside the team's control.
