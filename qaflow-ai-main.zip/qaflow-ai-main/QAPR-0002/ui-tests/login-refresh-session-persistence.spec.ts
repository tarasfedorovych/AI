import { test, expect } from '@playwright/test';
import { LoginPage } from '../../ui-framework/pages/LoginPage';

// REQ-21 edge case: refreshing the page immediately after a successful
// login preserves the authenticated state. This is the one edge case in
// REQ-21 classified UI (the browser-refresh action is only exercisable
// through an actual browser/page) — see automation-strategy.md.

const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data]

function uniqueEmail(label: string) {
  return `ui-${label}-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per run
}

// TC-REQ-21.6
test('TC-REQ-21.6: Refreshing the page immediately after a successful login preserves the authenticated state', async ({ page }) => {
  const loginPage = new LoginPage(page);
  const email = uniqueEmail('refresh-persistence');

  await test.step('Precondition: a registered account exists (seeded directly via the API)', async () => {
    await page.request.post('/api/Users', { data: { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD } });
  });

  await test.step('A successful login has just occurred', async () => {
    await loginPage.goto();
    await loginPage.login(email, VALID_PASSWORD);
    expect(await loginPage.isAuthenticated(), 'expected the account menu to show Logout right after login').toBe(true);
  });

  await test.step('Refresh the page immediately after the successful login', async () => {
    await page.reload();
  });

  await test.step('Verify the user remains authenticated after the refresh', async () => {
    expect(await loginPage.isAuthenticated(), 'expected the account menu to still show Logout after a page refresh').toBe(true);
  });
});
