import type { APIResponse, TestInfo } from '@playwright/test';

// Attaches the full request/response exchange to the test's own output
// (visible in the HTML report and as a testInfo attachment) so a failure
// is understandable from the test's own output alone - no need to open
// the source file or re-run it. Call once per request, with a short
// label describing that specific call's intent. Returns the parsed body -
// use it for subsequent assertions instead of calling .json()/.text()
// again on the same response.
export async function attachExchange(
  testInfo: TestInfo,
  label: string,
  requestInfo: { method: string; url: string; body?: unknown },
  response: APIResponse
): Promise<any> {
  const responseBody = await response.json().catch(() => response.text());
  await testInfo.attach(label, {
    body: JSON.stringify({ request: requestInfo, status: response.status(), response: responseBody }, null, 2),
    contentType: 'application/json',
  });
  return responseBody;
}
