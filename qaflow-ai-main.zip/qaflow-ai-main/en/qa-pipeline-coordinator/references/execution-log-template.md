# QA Pipeline Coordinator — Execution Log Template

Use this template to track coordinator execution and debug issues.

## Execution Snapshot

```
Issue Key:           PROJ-123
PR URL:              https://github.com/owner/repo/pull/456
Started At:          2026-07-29 14:32:00
Coordinator Model:   Haiku 4.5
Working Directory:   ./artifacts   (per-issue files live under ./artifacts/PROJ-123/)
```

## Step-by-Step Log

### Step 1: Task Context
- **Status:** ✅ PASS / ❌ FAIL / ⚠️ WARNING
- **Skill Called:** task-context
- **Output File:** PROJ-123/context.md
- **File Size:** XXX bytes
- **Duration:** XX seconds
- **Notes:** 

### Step 2: Requirements Grooming
- **Status:** ✅ PASS / ❌ FAIL / ⚠️ WARNING
- **Skill Called:** requirements-grooming
- **Output File:** PROJ-123/requirements.md
- **REQ Count:** X requirements extracted (REQ-1 to REQ-X)
- **Duration:** XX seconds
- **Notes:** 

### Step 3: QA Checklist
- **Status:** ✅ PASS / ❌ FAIL / ⚠️ WARNING
- **Skill Called:** qa-checklist
- **Output File:** PROJ-123/checklist.md
- **Check Count:** X checks total (REQ-1.1, REQ-1.2, ...)
- **Duration:** XX seconds
- **Notes:** 

### Step 4: Test Cases
- **Status:** ✅ PASS / ❌ FAIL / ⚠️ WARNING
- **Skill Called:** qa-test-cases
- **Output File:** PROJ-123/test-cases.md
- **Test Count:** X test cases (TC-REQ-1.1, TC-REQ-1.2, ...)
- **Duration:** XX seconds
- **Notes:** 

### Step 5: PR Summary
- **Status:** ✅ PASS / ❌ FAIL / ⚠️ WARNING
- **Skill Called:** pr-summary
- **Output File:** PROJ-123/pr-summary.md
- **PR URL/Branch:** (as provided)
- **Files Changed:** X files
- **Duration:** XX seconds
- **Notes:** 

### Step 6: Code Review
- **Status:** ✅ PASS / ❌ FAIL / ⚠️ WARNING
- **Skill Called:** code-review
- **Output File:** PROJ-123/code-review.md
- **Verdicts:** 
  - PASS: X test cases
  - FAIL: X test cases
  - QA: X test cases
- **Duration:** XX seconds
- **Notes:** 

### Step 7: Automation Strategy
- **Status:** ✅ PASS / ❌ FAIL / ⚠️ WARNING
- **Skill Called:** automation-strategy
- **Output File:** PROJ-123/automation-strategy.md
- **Classification Counts:** API: X, UI: X, Manual: X
- **Duration:** XX seconds
- **Notes:** 

### Step 8: API Tests
- **Status:** ✅ PASS / ❌ FAIL / ⚠️ WARNING
- **Skill Called:** api-tests
- **Output Folder:** PROJ-123/api-tests/
- **Tests Generated:** X spec files, X test() blocks
- **Pending Clarifications:** X
- **Duration:** XX seconds
- **Notes:** 

## Summary

**Overall Status:** ✅ COMPLETE / ❌ FAILED AT STEP X

**Generated Files:**
```
✅ PROJ-123/context.md
✅ PROJ-123/requirements.md
✅ PROJ-123/checklist.md
✅ PROJ-123/test-cases.md
✅ PROJ-123/pr-summary.md
✅ PROJ-123/code-review.md
✅ PROJ-123/automation-strategy.md
✅ PROJ-123/api-tests/ (spec files + summary.md)
```

**Total Duration:** XX minutes
**Total Cost (approx):** $X.XX

## Troubleshooting Notes

If coordinator failed:

1. **Which step failed?** Step X
2. **What was the error?** [Copy error message]
3. **What to check:**
   - [ ] Tracker access works
   - [ ] Git CLI authorized
   - [ ] Issue key format correct
   - [ ] PR URL valid
   - [ ] All 8 skills available

4. **Next action:** [Describe fix applied]
