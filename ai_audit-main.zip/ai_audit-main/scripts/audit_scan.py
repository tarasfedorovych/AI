#!/usr/bin/env python3
"""
audit_scan.py
Run all 16 Phase-2 anti-pattern searches across a test codebase and output
a compact JSON summary. Replaces 14+ individual grep_search calls with a
single script execution, reducing context-window consumption by ~50K tokens.

Usage:
    python scripts/audit_scan.py <repo_root> [--max-examples 5]

Output (stdout):
    JSON object with one key per pattern category:
    {
      "fixed_delays":  { "count": 230, "files": 30, "examples": ["path:line: snippet"] },
      ...
    }

Token cost of full grep output:  ~56 000 tokens  (14 calls × 200 results × 20 tokens)
Token cost of this script output: ~2 000 tokens   (~97% reduction)
"""
from __future__ import annotations
import json
import os
import re
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

MAX_EXAMPLES = 5

EXCLUDE_DIRS = {
    "target", "build", "dist", "out", "bin", "obj",
    "reports", "serenity-reports", "allure-results",
    "node_modules", ".venv", "venv", "__pycache__",
    ".git", ".idea", ".vscode", ".settings",
    "drivers", "ai_audit",
}

INCLUDE_EXTENSIONS = {
    ".java", ".py", ".ts", ".tsx", ".js", ".jsx",
    ".feature", ".properties", ".yml", ".yaml", ".xml",
    ".json", ".md", ".kt", ".groovy", ".scala",
}

# ---------------------------------------------------------------------------
# Pattern categories (mirrors audit.prompt.md Phase 2, categories 1–16)
# ---------------------------------------------------------------------------

PATTERNS: dict[str, dict] = {

    # 1. Fixed delays & sleeps
    "fixed_delays": {
        "label": "Fixed Delays & Sleeps",
        "regex": re.compile(
            r"Thread\.sleep\s*\("
            r"|TimeUnit\.(SECONDS|MILLISECONDS|MINUTES)\.sleep\s*\("
            r"|time\.sleep\s*\("
            r"|await\s+.*sleep\s*\("
            r"|cy\.wait\s*\(\s*\d+"
            r"|browser\.sleep\s*\("
            r"|waitABit\s*\("
            r"|waitFor\s*\(\s*\d+"
        ),
        "scope": None,
    },

    # 2. WebDriver anti-patterns
    "webdriver_antipatterns": {
        "label": "WebDriver Anti-Patterns",
        "regex": re.compile(
            r"implicitlyWait\s*\("
            r"|driver\.manage\(\)\.timeouts\(\)"
            r"|new\s+\w+Driver\s*\("
        ),
        "scope": None,
    },

    # 3. Console / debug logging
    "console_logging": {
        "label": "Console / Debug Logging",
        "regex": re.compile(
            r"System\.out\.print"
            r"|console\.(log|error|warn)\s*\("
            r"(?<![a-zA-Z])print\s*\("    # Python print, not part of longer name
        ),
        "scope": None,
    },

    # 4. Technical debt markers
    "tech_debt_markers": {
        "label": "Technical Debt Markers (TODO/FIXME/HACK)",
        "regex": re.compile(
            r"\b(TODO|FIXME|XXX|HACK)\b"
            r"|@Disabled"
            r"|@Ignore"
            r"|\.skip\s*\("
            r"|\.only\s*\("
            r"|@Test\s*\(.*enabled\s*=\s*false"
        ),
        "scope": None,
    },

    # 5. Exception handling anti-patterns
    "exception_antipatterns": {
        "label": "Catch-All Exception Handling",
        "regex": re.compile(
            r"catch\s*\(\s*(Exception|Throwable)"
            r"|except\s*:"
            r"|except\s+Exception\s*:"
            r"|catch\s*\(\s*e\s*\)\s*\{"
        ),
        "scope": None,
    },

    # 6. Non-determinism & hardcoded credentials
    "nondeterminism_credentials": {
        "label": "Non-Determinism & Hardcoded Credentials",
        "regex": re.compile(
            r"Math\.random\s*\("
            r"|new\s+Date\s*\(\s*\)"
            r"|Date\.now\s*\("
            r"|UUID\.random"
            # code files: quoted value  e.g.  password = "secret"
            r"|password\s*=\s*['\"]"
            r"|api[_-]?key\s*=\s*['\"]"
            # .properties files: unquoted value, not a variable reference ${...} or ENC(
            r"|[a-z._]*password\s*=\s*(?!ENC\(|\$\{|#|\\)[^\s]{3,}"
        ),
        "scope": None,
    },

    # 7. Assertion leakage into page/action layer (scoped to pages/ and actions/)
    "assertion_leakage": {
        "label": "Assertion Leakage Into Page / Action Layer",
        "regex": re.compile(
            r"\bassert\b|verify|assertEquals|assertTrue|assertFalse|assertThat|assertNotNull"
        ),
        "scope": re.compile(r"[/\\](pages|actions)[/\\]"),
    },

    # 8. Serenity BDD anti-patterns
    "serenity_antipatterns": {
        "label": "Serenity BDD Anti-Patterns",
        "regex": re.compile(
            r"Serenity\.setSessionVariable\s*\("
            r"|Serenity\.sessionVariableCalled\s*\("
            r"|net\.serenitybdd\.core\.Serenity\.getDriver\s*\("
            r"|@Steps.*static|static.*@Steps"
            r"|new\s+\w+Steps\s*\(\)"
            r"|new\s+\w+Page\s*\(\)"
            r"|pendingStep\s*\(\)"
            r"|PendingException"
            r"|withDriver\s*\(|useDriver\s*\("
        ),
        "scope": None,
    },

    # 9. Cucumber / BDD anti-patterns
    "cucumber_antipatterns": {
        "label": "Cucumber / BDD Anti-Patterns",
        "regex": re.compile(
            r"throw\s+new\s+PendingException\s*\("
            r"|@Given.*@When|@When.*@Then"
        ),
        "scope": None,
    },

    # 10. Shared / global state
    "shared_global_state": {
        "label": "Mutable Static / Shared Global State",
        "regex": re.compile(
            r"\bstatic\b.*=\s*new\s"   # static <type> <var> = new ... (any form)
            r"|@BeforeAll"
            r"|@BeforeClass"
        ),
        "scope": None,
    },

    # 11. Vacuous assertions
    "vacuous_assertions": {
        "label": "Vacuous / Trivially-Passing Assertions",
        "regex": re.compile(
            r"assertTrue\s*\(\s*true\s*\)"
            r"|assertTrue\s*\(\s*false\s*\)"
            r"|assertNotNull\s*\(\s*new\s"
            r"|expect\s*\(.*\)\.toBeTruthy\s*\(\)"
        ),
        "scope": None,
    },

    # 12. Retry / masking patterns
    "retry_masking": {
        "label": "Retry / Failure-Masking Patterns",
        "regex": re.compile(
            r"\bretry\s*\("
            r"|Mockito\.verify"
            r"|verify\s*\(.*Mockito"
        ),
        "scope": None,
    },

    # 13. Fragile locators
    "fragile_locators": {
        "label": "Fragile Locators",
        "regex": re.compile(
            r'By\.xpath\s*\(\s*"(/html|//body)'
            r'|xpath\s*\(\s*"(//|\.//)[\w]+\[\d+\]"'
            r'|By\.cssSelector\s*\(\s*"body\s'
            r'|querySelector\s*\(\s*"body\s'
            r"|\.findElements\s*\(.*\)\.get\s*\(\s*\d+"
        ),
        "scope": None,
    },

    # 14. Test ordering & execution dependency
    "test_ordering": {
        "label": "Test Ordering & Execution Dependency",
        "regex": re.compile(
            r"@TestMethodOrder|@FixMethodOrder"
            r"|dependsOnMethods|dependsOnGroups"
            r"|@Order\s*\(\s*\d+"
            r"|pytest-ordering|@pytest\.mark\.order"
        ),
        "scope": None,
    },

    # 16. TMS / traceability references (positive signal — presence is good)
    "tms_references": {
        "label": "TMS / Traceability References",
        "regex": re.compile(
            r"@TmsLink|@Issue|@TestCaseId|@Feature|@Story"
            r"|JIRA-\d{2,}"                 # explicit JIRA- prefix
            r"|\b[A-Z]{2,10}-\d{3,}\b"      # project key + 3-digit ticket number (excludes UTF-8, v1.0)
            r"|TestRail|Xray|Zephyr|qTest|PractiTest"
            r"|testCaseId|test_case_id|\btcId\b|\btc_id\b"
        ),
        "scope": None,
    },
}

# Category 15 (assertion-free test methods) is handled separately below.


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def is_excluded(path: Path) -> bool:
    """Return True if any component of path is in EXCLUDE_DIRS."""
    return any(part in EXCLUDE_DIRS for part in path.parts)


def truncate(text: str, max_len: int = 120) -> str:
    text = text.strip()
    return text[:max_len] + "…" if len(text) > max_len else text


def collect_files(root: Path) -> list[Path]:
    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        p = Path(dirpath)
        # Prune excluded directories in-place to skip descent
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
        for fname in filenames:
            fp = p / fname
            if fp.suffix.lower() in INCLUDE_EXTENSIONS and not is_excluded(fp):
                files.append(fp)
    return files


# ---------------------------------------------------------------------------
# Phase-2 scan
# ---------------------------------------------------------------------------

def scan_patterns(files: list[Path], repo_root: Path, max_examples: int) -> dict:
    results: dict[str, dict] = {}

    for cat_id, cat in PATTERNS.items():
        regex: re.Pattern = cat["regex"]
        scope: re.Pattern | None = cat["scope"]
        count = 0
        file_set: set[str] = set()
        examples: list[str] = []

        for fp in files:
            rel = str(fp.relative_to(repo_root)).replace("\\", "/")
            # Apply directory scope filter
            if scope and not scope.search(rel):
                continue
            try:
                text = fp.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue

            file_hits = 0
            for lineno, line in enumerate(text.splitlines(), start=1):
                if regex.search(line):
                    file_hits += 1
                    if len(examples) < max_examples:
                        examples.append(f"{rel}:{lineno}: {truncate(line)}")

            if file_hits:
                count += file_hits
                file_set.add(rel)

        results[cat_id] = {
            "label": cat["label"],
            "count": count,
            "files": len(file_set),
            "examples": examples,
        }

    return results


# ---------------------------------------------------------------------------
# Category 15 — Assertion-free test methods
# ---------------------------------------------------------------------------

TEST_METHOD_PATTERN = re.compile(r"@Test\b|def test_|^\s*it\s*\(|^\s*test\s*\(")
ASSERTION_PATTERN = re.compile(r"\bassert\b|expect\s*\(|verify\s*\(|should\b")


def scan_assertion_free(files: list[Path], repo_root: Path, max_examples: int) -> dict:
    suspicious: list[str] = []
    file_count = 0

    for fp in files:
        if fp.suffix.lower() not in {".java", ".py", ".ts", ".tsx", ".js", ".jsx", ".kt"}:
            continue
        try:
            text = fp.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        test_hits = len(TEST_METHOD_PATTERN.findall(text))
        assert_hits = len(ASSERTION_PATTERN.findall(text))

        if test_hits > 0 and assert_hits == 0:
            rel = str(fp.relative_to(repo_root)).replace("\\", "/")
            file_count += 1
            if len(suspicious) < max_examples:
                suspicious.append(f"{rel}: {test_hits} test method(s), 0 assertions")

    return {
        "label": "Assertion-Free Test Files (Silent Pass Risk)",
        "count": file_count,
        "files": file_count,
        "examples": suspicious,
    }


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python audit_scan.py <repo_root> [--max-examples N]", file=sys.stderr)
        sys.exit(1)

    repo_root = Path(sys.argv[1]).resolve()
    if not repo_root.is_dir():
        print(f"Error: '{repo_root}' is not a directory.", file=sys.stderr)
        sys.exit(1)

    max_ex = MAX_EXAMPLES
    if "--max-examples" in sys.argv:
        idx = sys.argv.index("--max-examples")
        try:
            max_ex = int(sys.argv[idx + 1])
        except (IndexError, ValueError):
            pass

    files = collect_files(repo_root)

    results = scan_patterns(files, repo_root, max_ex)
    results["assertion_free_tests"] = scan_assertion_free(files, repo_root, max_ex)

    output = {
        "scan_root": str(repo_root),
        "scanned_at": datetime.now(timezone.utc).isoformat(),
        "files_scanned": len(files),
        "patterns": results,
    }

    print(json.dumps(output, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
