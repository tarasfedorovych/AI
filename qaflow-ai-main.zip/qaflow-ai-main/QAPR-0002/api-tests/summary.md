# QAPR-0002 - API Tests Summary

Test cases: c:\src\!QA pipeline\QAPR-0002\test-cases.md
Automation strategy: c:\src\!QA pipeline\QAPR-0002\automation-strategy.md
Codebase reference: c:\src\!QA pipeline\juice-shop-master
Swagger reference: c:\src\!QA pipeline\juice-shop-master\swagger.yml
API mapping: c:\src\!QA pipeline\QAPR-0002\api-tests\api-mapping.json
Generated: 2026-09-04

## Selection (budget-driven curation — silent/autonomous run)

This run had no human checkpoint (the coordinator's Test Case Selection
checkpoint was intentionally skipped for this autonomous run — see the
task's "silent mode" instructions) and a combined API+UI budget of at most
50 generated `test()` cases. 25 TC-REQ items are classified `API` in
automation-strategy.md; 22 were selected for generation here, prioritizing
the primary acceptance criteria, the BR-LOGIN-* security rules, and a
representative sample of edge cases, per the same reasoning QAPR-0001's
ui-tests applied for its own Selection Checkpoint.

| TC-REQ | Scenario | Decision |
|--------|----------|----------|
| TC-REQ-6.1 | Valid credentials authenticate successfully | Selected |
| TC-REQ-7.1 | Unknown email is rejected | Selected |
| TC-REQ-7.2 | Correct email, wrong password is rejected | Selected |
| TC-REQ-8.1 | Rejected login creates no session | Selected |
| TC-REQ-9.1 | Session identifies the correct user | Selected |
| TC-REQ-10.1 | Authenticated state persists | Selected |
| TC-REQ-11.1 | Malformed token denied | Selected |
| TC-REQ-11.2 | Tampered token denied | Selected |
| TC-REQ-14.1 | Server-side rejection, bypassing the UI | Selected |
| TC-REQ-16.1 | Password not returned in any response | Selected |
| TC-REQ-16.2 | Token does not contain the plaintext password | Selected |
| TC-REQ-18.1 | Generic error, no account-existence disclosure | Selected |
| TC-REQ-19.1 | Script-like input does not authenticate | Selected |
| TC-REQ-19.2 | SQL-like input does not bypass authentication | Selected |
| TC-REQ-19.3 | Malformed input does not crash the server | Selected |
| TC-REQ-20.2 | Token not required in the URL | Selected |
| TC-REQ-21.1 | Different-case email | Selected |
| TC-REQ-21.2 | Whitespace-padded email | Selected |
| TC-REQ-21.3 | Very long input | Selected |
| TC-REQ-21.4 | Unicode/special-character input | Selected |
| TC-REQ-22.1 | AC-001 end-to-end successful login | Selected |
| TC-REQ-25.1 | AC-004 end-to-end session persistence | Selected |
| TC-REQ-21.5 | Rapid repeated login attempts | Deferred — budget-driven; largely redundant coverage-wise with TC-REQ-21.1–21.4's "no crash under adverse input" checks, and repeated-attempt timing is better suited to a dedicated load/rate-limit investigation than a single functional test |
| TC-REQ-27.1 | Backend failure produces a controlled error | Attempted, not generated — see Pending Clarifications |
| TC-REQ-27.2 | User remains unauthenticated after backend failure | Attempted, not generated — see Pending Clarifications |

## Test Output Traceability

Every generated test attaches the full request/response exchange for
every call it makes (via `helpers.ts`'s `attachExchange`) and every
`expect()` on a response carries a descriptive message with the actual
observed value. This means a failure — or a passing run someone wants
to audit — is understandable directly from the HTML report
(`npx playwright show-report`) or terminal output, without opening the
test source.

## Traceability

| TC-REQ | Scenario | Test File | Status |
|--------|----------|-----------|--------|
| TC-REQ-6.1 | Valid credentials authenticate successfully | login-successful-authentication.spec.ts | Generated |
| TC-REQ-7.1 | Unknown email is rejected | login-invalid-credentials-rejection.spec.ts | Generated |
| TC-REQ-7.2 | Correct email, wrong password is rejected | login-invalid-credentials-rejection.spec.ts | Generated |
| TC-REQ-8.1 | Rejected login creates no session | login-failed-auth-no-session.spec.ts | Generated |
| TC-REQ-9.1 | Session identifies the correct user | login-session-user-identity.spec.ts | Generated |
| TC-REQ-10.1 | Authenticated state persists | login-session-persistence.spec.ts | Generated |
| TC-REQ-11.1 | Malformed token denied | login-invalid-token-rejection.spec.ts | Generated |
| TC-REQ-11.2 | Tampered token denied | login-invalid-token-rejection.spec.ts | Generated |
| TC-REQ-14.1 | Server-side rejection, bypassing the UI | login-server-side-validation.spec.ts | Generated |
| TC-REQ-16.1 | Password not returned in any response | login-password-exposure.spec.ts | Generated |
| TC-REQ-16.2 | Token does not contain the plaintext password | login-password-exposure.spec.ts | Generated |
| TC-REQ-18.1 | Generic error, no account-existence disclosure | login-error-message-consistency.spec.ts | Generated |
| TC-REQ-19.1 | Script-like input does not authenticate | login-injection-safety.spec.ts | Generated |
| TC-REQ-19.2 | SQL-like input does not bypass authentication | login-injection-safety.spec.ts | Generated — fails (genuine finding) |
| TC-REQ-19.3 | Malformed input does not crash the server | login-injection-safety.spec.ts | Generated — fails (genuine finding) |
| TC-REQ-20.2 | Token not required in the URL | login-token-transport.spec.ts | Generated |
| TC-REQ-21.1 | Different-case email | login-edge-cases.spec.ts | Generated — fails (genuine finding) |
| TC-REQ-21.2 | Whitespace-padded email | login-edge-cases.spec.ts | Generated |
| TC-REQ-21.3 | Very long input | login-edge-cases.spec.ts | Generated |
| TC-REQ-21.4 | Unicode/special-character input | login-edge-cases.spec.ts | Generated |
| TC-REQ-22.1 | AC-001 end-to-end successful login | login-e2e-successful-login.spec.ts | Generated |
| TC-REQ-25.1 | AC-004 end-to-end session persistence | login-e2e-session-persistence.spec.ts | Generated |
| TC-REQ-21.5 | Rapid repeated login attempts | — | Deferred — budget-driven curation |
| TC-REQ-27.1 | Backend failure produces a controlled error | — | Pending — no fault-injection mechanism |
| TC-REQ-27.2 | User remains unauthenticated after backend failure | — | Pending — no fault-injection mechanism |

## Cleanup Coverage

| TC-REQ | Creates persistent data? | Cleanup |
|--------|---------------------------|---------|
| TC-REQ-6.1, 7.2, 9.1, 10.1, 11.2, 16.1, 16.2, 18.1, 20.2, 21.1, 21.2, 22.1, 25.1 | Yes (account) | None available — see below |
| TC-REQ-7.1, 8.1, 11.1, 14.1, 19.1, 19.2, 19.3, 21.3, 21.4 | No (rejected before creation, or no registration step) | N/A |

**No cleanup mechanism is available in this codebase.** `server.ts` wires
`/api/Users/:id` as:
```
app.route('/api/Users/:id')
  .get(security.isAuthorized())
  .put(security.denyAll())
  .delete(security.denyAll())
```
`security.denyAll()` (`lib/insecurity.ts`) is an always-failing JWT check
(it rejects even a request carrying a currently-valid bearer token —
confirmed empirically: "No Authorization header was found" with none,
"DECODER routines::unsupported" with one, since `denyAll()`'s own
configured secret cannot successfully verify any real token). This
contradicts `QAPR-0001/api-tests/summary.md`'s discovery note that this
endpoint was "confirmed available and unauthenticated" — either the
codebase changed since that run, or the two runs observed different
states; either way, in this run's live instance, DELETE is
unconditionally denied. Every test therefore uses a unique generated
email (`helpers.ts`'s `uniqueEmail`) instead of a shared literal, so
re-runs never collide with a previous run's leftover accounts — but the
accounts themselves are never removed. This is stated here plainly rather
than silently omitted, per this pipeline's cleanup rule.

## How to Run

See `README.md` for install/run instructions, including a required
`NO_PROXY` environment variable in a proxied environment (see below).

Existing Playwright setup detected: no — scaffolded a new
`playwright.config.ts` and a self-contained `package.json`
(`@playwright/test` 1.62.1, no browsers needed), same as `QAPR-0001/api-tests`.

## Verified Run Results (2026-09-04)

This suite was installed and run against a live instance of the app
(already running and reachable at `http://localhost:3000`) four times in a
row to confirm it's genuinely runnable and repeatable, not just
syntactically generated. Environment note: this sandbox has `HTTP_PROXY`
set globally, which silently intercepted plain requests to `localhost:3000`
(a Squid proxy responded instead of the app); `NO_PROXY=localhost,127.0.0.1`
was required for every `npm install`/`npx playwright test` invocation — see
`README.md`.

- 19 of 22 tests pass consistently across all 4 runs.
- 3 tests fail consistently, and all three are genuine application gaps,
  not test defects (assertions were left exactly as the requirement
  describes, not weakened):
  1. TC-REQ-19.2 (SQL-injection authentication bypass).
     `routes/login.ts` builds its account lookup as a raw interpolated SQL
     string (`WHERE email = '${req.body.email}' AND password = '...'`,
     marked `vuln-code-snippet vuln-line` in the codebase — an intentional
     OWASP Juice Shop training vulnerability). Submitting email
     `' OR 1=1--` returns 200 with a valid authentication token for the
     admin account, not the 401 rejection BR-LOGIN-005 requires. This is
     the most severe finding in this run: a complete authentication bypass.
  2. TC-REQ-19.3 (unhandled 500 with a leaked stack trace). A
     non-string `password` value (an object or array) crashes
     `lib/insecurity.ts`'s `hash()` (`crypto.createHash(...).update(data)`
     requires a string/Buffer/TypedArray) with an uncaught TypeError.
     Express's default error handler returns 500 with a full HTML
     error page containing the raw exception message and a complete
     server-side stack trace with absolute filesystem paths — violating
     both BR-LOGIN-005 (safe handling of malformed input) and LOGIN-011
     (no stack traces / internal details in errors).
  3. TC-REQ-21.1 (case-sensitive email lookup). The same raw-SQL
     lookup in finding 1 does no case normalization, so logging in with
     the registered email in a different letter case is rejected (401)
     instead of succeeding. This assumes login should be case-insensitive
     on email — a reasonable, common expectation and the plain reading of
     the source document's "email with different letter case" edge case —
     which the current implementation does not satisfy.
- One additional, non-reproducing failure was observed on a single run
  under the default 4-worker parallel execution: TC-REQ-11.2 (tampered
  token) failed once, then passed on 3 subsequent full-suite runs and in
  isolation. This looks like dev-server contention under concurrent load
  (the same class of issue `QAPR-0001/ui-tests/summary.md` documents for
  its own suite), not a test defect — no code or assertion was changed to
  "fix" it, since it was not reproducible. If this recurs, re-run with
  `--workers=1`.

Run `npx playwright show-report` for the full report, including the
attached request/response exchange for every call each test made.

## Pending Clarifications

- TC-REQ-27.1 (Backend failure during login produces a controlled error):
  the test case's own precondition requires "a backend failure is forced
  [test data/environment fault-injection mechanism]." No fault-injection
  endpoint, header, query parameter, or test-mode flag for forcing the
  authentication backend to fail was found in `swagger.yml` or in the
  `juice-shop-master` codebase (`routes/login.ts`, `lib/insecurity.ts`).
  Same class of gap as `QAPR-0001/api-tests/summary.md`'s TC-REQ-25.1 for
  registration.
- TC-REQ-27.2 (User remains unauthenticated after a backend failure):
  depends on the same forced-failure precondition as TC-REQ-27.1 having
  "just occurred" — without a discoverable way to force that failure, this
  test cannot be constructed.

## Discovery Notes (not pending, but relevant to generated tests)

- `GET /rest/user/whoami` (`routes/currentUser.ts`) resolves identity
  strictly from the `token` cookie, not the `Authorization` header,
  despite `swagger.yml`'s description saying either works — confirmed
  empirically (a valid bearer token in the `Authorization` header returns
  an empty `user` object; the same token as a `Cookie: token=...` header
  returns the real user). All authenticated-request tests here use the
  Cookie header for this reason.
- The JWT issued by `POST /rest/user/login` embeds the entire Sequelize
  user row into its payload, including an MD5 hash of the password
  (`lib/insecurity.ts`'s `hash()`) — confirmed by decoding a real token.
  This is not the plaintext password (TC-REQ-16.2 passes on that narrower,
  literal reading of BR-LOGIN-006), but it is a password-derived value
  readable by anyone who base64-decodes the token (no signing key needed
  to read a JWT payload, only to verify it) — noted here as a discoverable
  design fact for awareness, not asserted as a rule violation given how
  REQ-20 was scoped in requirements.md.
- `security.denyAll()` (used for `PUT`/`DELETE /api/Users/:id`) is
  implemented as an always-failing JWT check against a secret no real
  token can satisfy, not a simple 403 handler — this is why a request
  carrying a genuinely valid token still fails with a JWT-decode-shaped
  error message rather than a plain "forbidden".
