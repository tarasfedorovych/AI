# QA Pipeline Coordinator

Automates a professional QA workflow for your dev team: give it an issue
key, get back a full trail of QA artifacts — requirements analysis,
checklist, test cases, code review, automation strategy, and generated
Playwright tests.

Supports **English** and **Ukrainian**, each a self-contained skill set
(`en/`, `ua/`) invoked the same way.

**Tested end-to-end against [OWASP Juice Shop](https://github.com/juice-shop/juice-shop)**
— steps 1–9 have a real sample run in this repo (`QAPR-0001/`) against a
live Juice Shop instance, including generated Playwright tests that
actually ran (see [🧪 Try It](#-try-it--sample-run-against-juice-shop)).

---

## 🚀 Quick Start

Open the `SKILL.md` for your language, then invoke it in VS Code Chat:

| Language | Open | Invoke |
|----------|------|--------|
| English | `en/qa-pipeline-coordinator/SKILL.md` | `@qa-pipeline-coordinator Run QA for PROJ-123` |
| Ukrainian | `ua/qa-pipeline-coordinator/SKILL.md` | `@qa-pipeline-coordinator Запусти QA конвеєр для PROJ-123` |

Keep either or both language folders in your workspace — no global
install needed. Add a PR URL to also run code-review, e.g. `..., PR is
https://github.com/owner/repo/pull/456`.

**Read `<lang>/qa-pipeline-coordinator/setup-guide.md` first** to
configure your tracker (Jira, GitHub, GitLab, Linear, Azure DevOps) —
see [🔧 Configuration](#-configuration).

> **💡 For best results, run one phase at a time.** The coordinator
> *can* fire off steps 1–9 unattended from just an issue key, but
> quality and token efficiency are much better when you stay in the
> loop: review each phase's output before the next one starts, and
> answer any clarification question it asks (a missing acceptance
> criterion, an ambiguous requirement, which test cases to automate,
> etc.) instead of leaving it to guess. A guessed gap caught late costs
> far more tokens to fix than answering the question up front would
> have.

---

## 🔍 Workflow

Steps 1–8 run automatically from one issue key. Steps 9–10 are
optional — invoked independently, after the step they depend on.

| # | Phase | Output | Description |
|---|-------|--------|-------------|
| 1 | **task-context** | `context.md` | Pulls tracker data (description, comments, attachments, acceptance criteria) into one unified context file. |
| 2 | **requirements-grooming** | `requirements.md` | Reviews the context for clarity/coverage/contradictions; produces numbered requirements (REQ-1, ...). |
| 3 | **qa-checklist** | `checklist.md` | Decomposes each requirement into atomic, unambiguous checks. |
| 4 | **qa-test-cases** | `test-cases.md` | Builds concrete test cases (preconditions, steps, data, expected results) via EP/BVA/Decision Tables. |
| 5 | **pr-summary** | `pr-summary.md` | Maps changed files/components from the PR or branch — a map for code review. |
| 6 | **code-review** | `code-review.md` | Verifies each test case against the PR code; classifies PASS/FAIL/QA/N/A with findings. |
| 7 | **automation-strategy** | `automation-strategy.md` | Classifies each test case as API / UI / Manual, with rationale. |
| 8 | **api-tests** | `api-tests/*.spec.ts` | Generates Playwright API tests (native `request` fixture) + traceability summary. |
| 9 † | **ui-tests** | `ui-tests/*.spec.ts` | Generates Playwright UI tests through a Page Object Model layer shared across issues (`ui-framework/`). Pauses to let you pick which UI test cases to generate. |
| 10 † | **manual-testing** | `<key>-manual-testing.md` | Exploratory pass in a real browser (Claude-in-Chrome, not Playwright) for whatever QA/FAIL/Manual/deferred points still need a human look. |

† Optional, not part of the automatic chain. Step 9 depends on step 7;
step 10 depends on step 6 (optionally also 7 & 9).

All files save under `<ISSUE_KEY>/` in your working directory (e.g.
`PROJ-123/test-cases.md`, `PROJ-123/api-tests/summary.md`) — one folder
per issue, no filename collisions, easy to zip and hand off.

---

## 📋 Folder Structure

```
QA pipeline
  ├── en/                                        ← English skills
  │   ├── qa-pipeline-coordinator/                ← Orchestrates steps 1-8
  │   ├── 1-task-context-skill-template/          ← Step 1: pull tracker data into context.md
  │   ├── 2-requirements-grooming-template/       ← Step 2: analyze context, number requirements (REQ-N)
  │   ├── 3-qa-checklist-template/                ← Step 3: decompose requirements into atomic checks
  │   ├── 4-qa-test-cases-template/               ← Step 4: build concrete test cases (steps, data, expected results)
  │   ├── 5-pr-summary-template/                  ← Step 5: map changed files/components from the PR or branch
  │   ├── 6-code-review-template/                 ← Step 6: verify test cases against PR code (PASS/FAIL/QA/N/A)
  │   ├── 7-automation-strategy-template/         ← Step 7: classify test cases as API/UI/Manual
  │   ├── 8-api-tests-template/                   ← Step 8: generate Playwright API tests
  │   ├── 9-ui-tests-template/                    ← Optional, after step 7
  │   └── 10-manual-testing-template/             ← Optional, after step 6
  │
  ├── ua/                                         ← Ukrainian mirror, same layout as en/
  │
  ├── juice-shop-sample-reqs/                     ← Sample requirement docs to try the pipeline without a tracker
  │   ├── QAPR-0001 - User-registration-requirements-simplified.md
  │   └── QAPR-0002 - User-login-requirements-simplified.md
  ├── QAPR-0001/                                   ← Sample output: a full pipeline run (steps 1-9) against the file above
  │   ├── context.md · requirements.md · checklist.md · test-cases.md
  │   ├── automation-strategy.md
  │   ├── api-tests/                               ← Generated Playwright API tests + report tooling
  │   └── ui-tests/                                ← Generated Playwright UI tests + report tooling
  ├── ui-framework/pages/                          ← Shared Page Object Model layer written by step 9, reused across issues
  ├── juice-shop-master/                           ← Local OWASP Juice Shop checkout — target app for the QAPR-0001
  │   └── runme.bat                                   sample and for trying steps 8-9 yourself (starts it on :3000)
  │
  └── README.md                                   ← This file
```

Each skill folder contains `SKILL.md` (agent definition), `setup-guide.md`,
and a `references/` folder with output templates and conventions. Each
numbered folder's name matches its pipeline position (1 = first, 8 =
last), independent of the `name:` value in its `SKILL.md` frontmatter
used to invoke it.

---

## 🧪 Try It — Sample Run Against Juice Shop

Two things in this repo let you try the pipeline end-to-end without a
real tracker or ticket:

- **`juice-shop-sample-reqs/`** — a sample requirement document you can
  hand to the coordinator instead of a tracker issue key (`task-context`
  accepts a pasted/attached description when no tracker is configured).
  Includes two independent samples, each with its own issue key:
  `QAPR-0001 - User-registration-requirements-simplified.md` and
  `QAPR-0002 - User-login-requirements-simplified.md`.
- **`QAPR-0001/`** — the full output of running steps 1–9 against that
  file: every intermediate artifact through `automation-strategy.md`,
  plus a verified `api-tests/` suite and a `ui-tests/` suite generated
  with real Page Objects (`ui-framework/pages/`), both with an HTML
  reporter configured. The UI suite was actually run against a live
  Juice Shop instance: **9 passed, 2 failed** — both failures are
  genuine app gaps (a missing auth-redirect guard, an untrimmed
  required-field validator), not test defects.

**Recommended target app:** [OWASP Juice Shop](https://github.com/juice-shop/juice-shop)
— intentionally vulnerable, with real REST endpoints, an OpenAPI
document (`swagger.yml`) for step 8's endpoint discovery, and a real
frontend for step 9's selector discovery. It's exactly what `QAPR-0001`
was generated and verified against (see `juice-shop-master/` and its
`runme.bat`). Point `api-tests`/`ui-tests` at your own checkout to see
steps 7–9 discover real endpoints and pages instead of asking you for
them.

---

## 🔧 Configuration

Before first use, read the setup guide for your language:

```powershell
notepad "en\qa-pipeline-coordinator\setup-guide.md"   # English
notepad "ua\qa-pipeline-coordinator\setup-guide.md"   # Ukrainian
```

What to configure:
1. **Identify your tracker** — Jira, GitHub Issues, GitLab, Linear, or Azure DevOps.
2. **Verify Git CLI is installed and authorized** — `gh auth login` (GitHub), `glab auth login` (GitLab), etc.
3. **Test tracker access** — manually confirm you can open an issue.
4. **Update coordinator config** — if using a non-GitHub VCS.

**Supported trackers:** Jira (Cloud & Server), GitHub Issues, GitLab,
Linear, Azure DevOps — custom integrations supported via configuration.

---

## ❓ Troubleshooting

| Symptom | Check |
|---------|-------|
| Coordinator can't access tracker | `gh auth login` / `glab auth login` |
| Coordinator can't access PR | `gh pr view https://github.com/owner/repo/pull/123` |
| Coordinator stopped at step X | `ls PROJ-123/` — confirm the previous step's output file exists |

For more, see **setup-guide.md → Troubleshooting**.

---

## 📖 Documentation & Support

| Question | See |
|----------|-----|
| How do I use it? | `SKILL.md` |
| How do I configure it? | `setup-guide.md` |
| Technical details of steps 1-8? | `references/workflow.md` |
| Tracking a run? | `references/execution-log-template.md` |

---

**Ready to automate QA?** Open a `SKILL.md` and invoke the coordinator. 🚀
