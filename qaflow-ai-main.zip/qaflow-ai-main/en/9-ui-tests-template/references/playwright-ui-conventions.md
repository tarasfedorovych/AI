# Playwright UI Generation Conventions — reference

## Framework

Use Playwright Test's browser fixtures:

```ts
import { test, expect } from '@playwright/test';
```

Interactions and assertions go through Page Object methods, not
directly through `page` inside a spec file (see Page Object Model
below).

## File Naming and Grouping

- One `.spec.ts` file per requirement group (the REQ heading in the
  test-cases file), not per TC-REQ item. Name the file after the
  page/feature the REQ group covers, in kebab-case, e.g.
  `registration-page-access.spec.ts`,
  `mandatory-field-validation.spec.ts`.
- If a REQ group has only one UI-classified TC-REQ item, it still gets
  its own file — do not merge unrelated REQ groups into one "misc" or
  "other" file, since that breaks the 1:1 traceability from filename to
  requirement.
- Place spec files directly under `<ISSUEKEY>/ui-tests/` (or a `tests/`
  subfolder of it if a detected existing codebase convention uses one —
  match what was found, but never write outside `<ISSUEKEY>/ui-tests/`).
- Page Objects are never placed under `<ISSUEKEY>/`. They live in the
  shared `ui-framework/pages/` folder at the working directory root, one
  file per page/major component, named after the page in PascalCase,
  e.g. `RegistrationPage.ts`, `LoginPage.ts`.

## Page Object Model

### Why shared and reused, not regenerated

Unlike API tests (self-contained per issue), the value of a UI POM
layer comes from reuse: the same login page, navigation, and form
components get exercised by test cases from many different tickets
against the same app. Regenerating Page Objects per issue would
silently drift and duplicate work. The shared `ui-framework/pages/` folder
is the one location this skill is allowed to write to outside the
current issue's own output folder.

### Reuse rule

Before writing a new Page Object file, check `ui-framework/pages/` for a
class matching the target page (by filename/class name, or by a
`// Page:` comment naming the URL/route it covers). If found:
- Reuse it as-is for locators/methods it already has.
- Add any new locator or method the current test cases need, appended
  to the class — never remove, rename, or change the behavior of an
  existing method; other issues' specs may already call it.
If not found, create a new file.

### Shape

```ts
// Page: /#/register — user registration form (Juice Shop)
import type { Page, Locator } from '@playwright/test';

export class RegistrationPage {
  readonly page: Page;
  readonly emailInput: Locator;
  readonly passwordInput: Locator;
  readonly repeatPasswordInput: Locator;
  readonly securityQuestionSelect: Locator;
  readonly securityAnswerInput: Locator;
  readonly submitButton: Locator;
  readonly errorMessage: Locator;

  constructor(page: Page) {
    this.page = page;
    this.emailInput = page.getByLabel('Email');
    this.passwordInput = page.getByLabel('Password', { exact: true });
    this.repeatPasswordInput = page.getByLabel('Repeat Password');
    this.securityQuestionSelect = page.getByLabel('Security Question');
    this.securityAnswerInput = page.getByLabel('Answer');
    this.submitButton = page.getByRole('button', { name: 'Register' });
    this.errorMessage = page.getByRole('alert');
  }

  async goto() {
    await this.page.goto('/#/register');
  }

  async isFormVisible(): Promise<boolean> {
    return this.emailInput.isVisible();
  }

  async fillMandatoryFields(data: { email: string; password: string }) {
    await this.emailInput.fill(data.email);
    await this.passwordInput.fill(data.password);
    await this.repeatPasswordInput.fill(data.password);
  }

  async submit() {
    await this.submitButton.click();
  }
}
```

**Why `import type`, not a plain `import`:** this file has zero runtime
dependency on wherever `@playwright/test` happens to be installed. The
`Page`/`Locator` names are erased entirely at compile time (Playwright
Test's esbuild transform strips `import type`), so this shared file
imports cleanly no matter which issue folder's own `package.json`/
`node_modules` ends up running the spec that constructs it. **Never**
import `test` or `expect` (or any other runtime export) from
`@playwright/test` inside a Page Object file — Node resolves a runtime
import relative to the *importing file's own directory*, walking
upward; a file living in the shared root-level `ui-framework/pages/` folder
would never reach up into `<ISSUEKEY>/ui-tests/node_modules/` when a
self-contained `package.json` was scaffolded there, so a runtime import
of `@playwright/test` from a Page Object can fail depending on which
issue's install happens to be nearby. Keeping the import type-only
sidesteps this entirely, since it's erased before anything tries to
resolve it.

This is also why **assertions stay out of Page Objects** — not just a
resolution workaround, but the standard POM boundary: a Page Object
exposes locators and performs actions/state reads; the spec file (which
always has `expect` available, since it's the file `@playwright/test`
is actually running) does the asserting. Methods represent user actions
and state reads in domain language (`fillMandatoryFields`, `submit`,
`isFormVisible`) — not a thin wrapper that just renames `.click()`, but
never an `expect()` call.

### Spec file importing the Page Object

```ts
// TC-REQ-1.1
import { test, expect } from '@playwright/test';
import { RegistrationPage } from '../../ui-framework/pages/RegistrationPage';

test('TC-REQ-1.1: Registration page is accessible to an unauthenticated visitor', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);

  await test.step('Navigate to the registration page', async () => {
    await registrationPage.goto();
  });

  await test.step('Verify the registration form is displayed', async () => {
    expect(
      await registrationPage.isFormVisible(),
      'expected the registration form to be visible for an unauthenticated visitor'
    ).toBe(true);
  });
});
```

```ts
// TC-REQ-4.1
import { test, expect } from '@playwright/test';
import { RegistrationPage } from '../../ui-framework/pages/RegistrationPage';

const VALID_PASSWORD = 'Str0ngP@ssw0rd!'; // [test data] valid mandatory data

test('TC-REQ-4.1: Submitting with Email left completely empty displays a validation error for that field', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);

  await test.step('Navigate to the registration page', async () => {
    await registrationPage.goto();
  });

  await test.step('Submit with Email left empty', async () => {
    await registrationPage.fillMandatoryFields({ email: '', password: VALID_PASSWORD });
    await registrationPage.submit();
  });

  await test.step('Verify a validation error is displayed for Email', async () => {
    await expect(
      registrationPage.errorMessage,
      'expected a validation error mentioning Email'
    ).toContainText('Email');
  });
});
```

Note the assertion uses the Page Object's exposed `errorMessage`
locator property (defined once in the constructor) — it does not build
a fresh `page.getByRole('alert')` inline in the spec, and the Page
Object itself never calls `expect`. That boundary — locators defined
once on the Page Object, actions as methods, assertions in the spec
against those exposed locators — is what "no raw locator in a spec
file" means in practice.

Import path depth: a spec at `<ISSUEKEY>/ui-tests/<file>.spec.ts`
imports the shared Page Object via `../../ui-framework/pages/<PageName>`
(up out of `ui-tests/`, up out of `<ISSUEKEY>/`, back down into the
root-level `ui-framework/pages/`). Adjust the `../` count if the working
directory nests issue folders any deeper.

## Selector Strategy (Playwright best practices)

Priority order, most to least preferred:

1. `getByRole(role, { name })` — matches how the page is actually
   exposed to assistive tech and users; most resilient to markup churn.
2. `getByLabel` / `getByPlaceholder` — for form fields without a
   distinct role/name combination.
3. `getByText` — for static content, messages, headings.
4. `getByTestId` — only when the app already exposes a stable
   `data-testid` convention (confirmed via codebase discovery); do not
   introduce this attribute yourself into the app, only use it if it's
   already there.
5. CSS or XPath selector — last resort only, when none of the above can
   uniquely identify the element (e.g. no accessible name, no test id,
   ambiguous text). Every use must be flagged as a fragility note in
   `summary.md`, with a one-line reason why the higher-priority options
   didn't work.

Never select by an auto-generated/dynamic class name (e.g. a CSS-modules
hash) or by DOM position (`nth-child`, `:eq()`) — both break on
unrelated markup changes.

## Traceability in Test Output

A generated test must be understandable from its own output — the HTML
report — without opening the source file or re-running it in a
debugger. Two techniques, both required together:

### 1. `test.step` per logical phase

Wrap navigate / act / assert phases (or more granular steps for
multi-part scenarios) in `test.step('<intent>', async () => { ... })`.
This makes the HTML report's step list narrate the scenario on its own
(e.g. "Navigate to the registration page" → "Submit with Email left
empty" → "Verify a validation error is displayed for Email").

### 2. Every assertion carries a descriptive message

Never leave a bare `expect(x).toBe(y)` with no message. State what was
expected; Playwright's error output already includes the actual value
for web-first assertions, so the message only needs to state intent
concisely:

```ts
await expect(
  page.getByRole('alert'),
  'expected a validation error for the Email field'
).toBeVisible();
```

### Why no custom attach-helper is needed here

API tests need a shared `attachExchange` helper because an HTTP
exchange has no visual artifact of its own — the JSON has to be
attached manually to be visible in the report. A browser test doesn't
have this problem: Playwright automatically captures and attaches a
trace, a screenshot, and (if configured) a video to the HTML report for
any failing test, once the config below is in place. Don't build a
UI-specific equivalent of `attachExchange` — configure the artifacts
instead.

## Config Detection and Scaffolding

- If a provided codebase has `playwright.config.ts`/`.js` with a
  `baseURL` and/or `projects`, reuse it — navigate via relative paths
  (`page.goto('/#/register')`), not a hardcoded host.
- If a provided codebase has existing auth fixtures (a `storageState`
  file, a global-setup login step), reuse the same pattern via import
  rather than re-deriving login per test.
- If no codebase was provided, or none of the above was found, create a
  minimal `playwright.config.ts` inside `<ISSUEKEY>/ui-tests/`:

```ts
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  reporter: [['html', { open: 'never' }]],
  use: {
    baseURL: 'http://localhost:3000', // TODO: replace with the real app base URL
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
  ],
});
```

`open: 'never'` keeps a plain `npm test` from trying to launch a browser
after the run — the person running it opens the report explicitly via
`npx playwright show-report`. `trace: 'retain-on-failure'` +
`screenshot: 'only-on-failure'` + `video: 'retain-on-failure'` keep the
report focused (no artifacts cluttering passing tests) while making a
failure fully inspectable — the trace viewer lets you scrub the actual
DOM/network/console state at every `test.step`.

Only `chromium` is configured by default — keep the suite fast unless a
test case explicitly requires cross-browser verification. If it does,
add a `firefox`/`webkit` project and note it in `README.md`.

- If reusing an existing `playwright.config.ts` from a provided
  codebase that doesn't already set `trace`/`screenshot`/`video`, do not
  silently rely on defaults — state plainly in `README.md` how to get
  these artifacts for this run without editing the existing config
  (e.g. `npx playwright test --trace=retain-on-failure`).

## Discovery Script (Code/Page Access, section B)

Used only when a running app URL is available and the codebase either
wasn't provided or doesn't confidently cover a target page. Runs once,
before any code generation, using the `playwright` package directly
(not the `@playwright/test` runner):

```ts
// discover.ts — run once via `node discover.ts` (or `npx tsx discover.ts`), then delete/ignore
import { chromium } from 'playwright';
import { writeFileSync } from 'fs';

const BASE_URL = 'http://localhost:3000'; // TODO: replace with the real app base URL
const TARGET_PAGES = [
  { name: 'registration', path: '/#/register' },
  // one entry per page the selected test cases need
];

async function main() {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  const results: { page: string; url: string; snapshot: string }[] = [];

  for (const target of TARGET_PAGES) {
    await page.goto(`${BASE_URL}${target.path}`);
    const snapshot = await page.locator('body').ariaSnapshot();
    results.push({ page: target.name, url: target.path, snapshot });
  }

  writeFileSync('discovery/pages.json', JSON.stringify(results, null, 2));
  await browser.close();
}

main();
```

Run it once, read `discovery/pages.json` once. This is the reason a
scripted pass is preferred over Playwright MCP for this step: one
script execution plus one file read replaces what would otherwise be a
separate navigate + snapshot (+ occasional click, for a multi-step
precondition) MCP tool round trip per page — each of those round trips
costs a full turn. Reserve Playwright MCP for the genuinely interactive
case: a login flow or branching wizard whose steps can't be listed in
`TARGET_PAGES` up front because they depend on runtime state.

## Cleanup

If `ui-mapping.json` names a confirmed cleanup mechanism for a test (a
UI flow or API endpoint that removes data the test created), wrap
everything after the data is created in `try { ... } finally { ... }`,
with the cleanup call in `finally` — never just appended after the last
assertion, for the same reason documented in the API-tests conventions:
a cleanup call placed after assertions is unreachable exactly when an
assertion throws, which is precisely when leftover data is most likely.

Keep cleanup itself a plain, unasserted best-effort call — don't wrap it
in `expect()`, and don't let a cleanup failure mask the original test
failure (no nested try/catch around the cleanup call itself). If the
mapping notes no cleanup mechanism was found, do not add one; leave the
test as-is.

## Shared Setup

When more than one test needs the same multi-step setup (e.g. "an
account already exists" as a precondition), factor it into a Page
Object method (e.g. `RegistrationPage.registerNewAccount(data)`
returning the created email) rather than re-inlining the same steps
across spec files — the same idea as `helpers.ts` in api-tests, but
living on the relevant Page Object since it's page-specific action
sequencing, not a cross-cutting utility.

## Anti-patterns

- Do not construct a fresh `page.locator`/`page.getByRole`/etc. call
  inline in a `.spec.ts` file — locators live on the Page Object;
  actions go through its methods, assertions target its exposed
  locators.
- Do not call `expect()` inside a Page Object method — assertions
  belong in the spec file.
- Do not generate a test for a TC-REQ item with no discovered or
  confirmed page/selector — list it as pending clarification instead.
- Do not hardcode a full URL when a `baseURL` is configured.
- Do not combine unrelated REQ groups into one file.
- Do not use manual waits/sleeps — rely on Playwright's auto-retrying
  assertions and locator actions.
- Do not select by dynamic class name or DOM position.
- Do not regenerate a Page Object that already exists in
  `ui-framework/pages/` — extend it.
- Do not remove, rename, or change the behavior of an existing Page
  Object method — other issues' specs may depend on it.
- Do not skip configuring `trace`/`screenshot`/`video` — a UI test with
  no failure artifacts is not traceable.
- Do not add cleanup that isn't a confirmed, discovered mechanism — but
  do not omit confirmed cleanup either.
