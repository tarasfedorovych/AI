import { test, expect } from '@playwright/test';
import { attachExchange, uniqueEmail } from './helpers';

// REQ-10: LOGIN-008 — the authenticated state persists while the session
// remains valid. Verified by issuing two sequential authenticated requests
// with the same still-valid token — standing in for "subsequent
// navigation/requests" in a UI sense, since the session's own validity
// (not any particular page) is what this requirement is about.

const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data]

// TC-REQ-10.1
test('TC-REQ-10.1: Authenticated state persists across subsequent requests while the session is valid', async ({ request }, testInfo) => {
  const email = uniqueEmail('session-persistence');

  const registerBody = { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD };
  const registerResponse = await request.post('/api/Users', { data: registerBody });
  const registerRespBody = await attachExchange(testInfo, 'arrange: register account', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
  expect(registerResponse.status(), `expected 201 Created, got ${registerResponse.status()} - ${JSON.stringify(registerRespBody)}`).toBe(201);

  const loginBody = { email, password: VALID_PASSWORD };
  const loginResponse = await request.post('/rest/user/login', { data: loginBody });
  const loginRespBody = await attachExchange(testInfo, 'login', { method: 'POST', url: '/rest/user/login', body: loginBody }, loginResponse);
  expect(loginResponse.status(), `expected 200 OK, got ${loginResponse.status()} - ${JSON.stringify(loginRespBody)}`).toBe(200);
  const token = loginRespBody.authentication.token;

  await test.step('first authenticated request after login', async () => {
    const response = await request.get('/rest/user/whoami', { headers: { Cookie: `token=${token}` } });
    const body = await attachExchange(testInfo, 'whoami #1', { method: 'GET', url: '/rest/user/whoami', headers: { Cookie: 'token=<redacted>' } }, response);
    expect(body.user?.email, `expected the session to still identify ${email} on the first request, got ${JSON.stringify(body)}`).toBe(email);
  });

  await test.step('second, later authenticated request with the same session', async () => {
    const response = await request.get('/rest/user/whoami', { headers: { Cookie: `token=${token}` } });
    const body = await attachExchange(testInfo, 'whoami #2', { method: 'GET', url: '/rest/user/whoami', headers: { Cookie: 'token=<redacted>' } }, response);
    expect(body.user?.email, `expected the session to still identify ${email} on a subsequent request, got ${JSON.stringify(body)}`).toBe(email);
  });
});
