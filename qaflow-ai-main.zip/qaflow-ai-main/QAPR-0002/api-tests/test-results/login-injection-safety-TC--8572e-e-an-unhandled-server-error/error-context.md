# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: login-injection-safety.spec.ts >> TC-REQ-19.3: Malformed input does not produce an unhandled server error
- Location: login-injection-safety.spec.ts:54:5

# Error details

```
Error: expected a controlled 4xx (not an unhandled 5xx) for malformed input — got 500 - <html>
  <head>
    <meta charset='utf-8'> 
    <title>TypeError [ERR_INVALID_ARG_TYPE]: The &quot;data&quot; argument must be of type string or an instance of Buffer, TypedArray, or DataView. Receive (known gap: non-string password crashes hash() with an uncaught TypeError, exposing a full stack trace)

expect(received).toBeLessThan(expected)

Expected: < 500
Received:   500
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import { attachExchange } from './helpers';
  3  | 
  4  | // REQ-19: BR-LOGIN-005 — the login endpoint shall handle malicious or
  5  | // malformed input safely. Endpoint: POST /rest/user/login.
  6  | //
  7  | // TWO GENUINE APPLICATION SECURITY FINDINGS were confirmed here by actually
  8  | // running these tests against the live app (not visible from reading the
  9  | // requirement text alone) — see the per-test comments and summary.md's Run
  10 | // Results. Both assertions are left exactly as the requirement describes
  11 | // (not weakened to match the vulnerable behavior), so the failures stay
  12 | // visible.
  13 | 
  14 | // TC-REQ-19.1
  15 | test('TC-REQ-19.1: HTML/JavaScript-like input in Email or Password does not execute as script and does not authenticate', async ({ request }, testInfo) => {
  16 |   const scriptEmail = '<script>alert(1)</script>'; // literal from test case
  17 | 
  18 |   const loginBody = { email: scriptEmail, password: 'anyPassword1' };
  19 |   const response = await request.post('/rest/user/login', { data: loginBody });
  20 |   const bodyText = await response.text();
  21 |   await attachExchange(testInfo, 'login with script-like email', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);
  22 | 
  23 |   // This app's failed-login response never echoes the submitted email back
  24 |   // into the response (fixed literal "Invalid email or password."), so
  25 |   // there is no reflected-input surface for the script to execute against
  26 |   // at the API layer — confirmed by inspecting the response text itself.
  27 |   expect(response.status(), `expected 401 rejection, got ${response.status()} - ${bodyText}`).toBe(401);
  28 |   expect(bodyText.includes('<script>'), `expected the script-like input not to be reflected back verbatim in the response, got ${bodyText}`).toBe(false);
  29 | });
  30 | 
  31 | // TC-REQ-19.2
  32 | test('TC-REQ-19.2: SQL-like syntax in Email or Password does not cause a database error or bypass authentication', async ({ request }, testInfo) => {
  33 |   const sqlInjectionEmail = "' OR 1=1--"; // literal from test case
  34 | 
  35 |   const loginBody = { email: sqlInjectionEmail, password: 'anyPassword1' };
  36 |   const response = await request.post('/rest/user/login', { data: loginBody });
  37 |   const bodyText = await response.text();
  38 |   await attachExchange(testInfo, 'login with SQL-like injection email', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);
  39 | 
  40 |   // GENUINE FINDING, confirmed by running this test: routes/login.ts builds
  41 |   // its account lookup as a raw interpolated SQL string
  42 |   // (`WHERE email = '${req.body.email}' AND password = '...'`, marked
  43 |   // vuln-code-snippet vuln-line in the codebase — an intentional OWASP
  44 |   // Juice Shop training vulnerability). Submitting `' OR 1=1--` as the email
  45 |   // returns 200 with a valid authentication token for the first user in the
  46 |   // table (the admin account), NOT the 401 rejection BR-LOGIN-005 requires.
  47 |   // This is a classic SQL-injection authentication bypass. The assertion
  48 |   // below is left as written (expecting rejection) rather than weakened —
  49 |   // it currently fails, and that failure is the intended, documented signal.
  50 |   expect(response.status(), `expected 401 rejection (BR-LOGIN-005: malicious input handled safely) — got ${response.status()} - ${bodyText} (known gap: raw-SQL email lookup in routes/login.ts allows an auth bypass via SQL injection)`).toBe(401);
  51 | });
  52 | 
  53 | // TC-REQ-19.3
  54 | test('TC-REQ-19.3: Malformed input does not produce an unhandled server error', async ({ request }, testInfo) => {
  55 |   const loginBody = { email: 'admin@juice-sh.op', password: { a: 1 } }; // [test data] password is an object, an invalid type
  56 | 
  57 |   const response = await request.post('/rest/user/login', { data: loginBody });
  58 |   const bodyText = await response.text();
  59 |   await attachExchange(testInfo, 'login with a malformed (non-string) password type', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);
  60 | 
  61 |   // GENUINE FINDING, confirmed by running this test: a non-string password
  62 |   // crashes lib/insecurity.ts's hash() (`crypto.createHash(...).update(data)`
  63 |   // requires a string/Buffer/TypedArray) with an uncaught TypeError. Express's
  64 |   // default error handler then returns 500 with a full HTML error page that
  65 |   // includes the raw exception message AND a complete server-side stack
  66 |   // trace with absolute filesystem paths — directly violating both
  67 |   // BR-LOGIN-005 (safe handling) and LOGIN-011 (no stack traces/internal
  68 |   // details). The assertions below are left as written (expecting a
  69 |   // controlled 4xx with no stack trace) rather than weakened — they
  70 |   // currently fail, and that failure is the intended, documented signal.
> 71 |   expect(response.status(), `expected a controlled 4xx (not an unhandled 5xx) for malformed input — got ${response.status()} - ${bodyText.slice(0, 200)} (known gap: non-string password crashes hash() with an uncaught TypeError, exposing a full stack trace)`).toBeLessThan(500);
     |                                                                                                                                                                                                                                                                    ^ Error: expected a controlled 4xx (not an unhandled 5xx) for malformed input — got 500 - <html>
  72 |   expect(bodyText.includes('at ') && bodyText.includes('.js:'), `expected no server-side stack trace in the error response, got a body that ${bodyText.includes('at ') ? 'DOES' : 'does not'} look like it contains one`).toBe(false);
  73 | });
  74 | 
```