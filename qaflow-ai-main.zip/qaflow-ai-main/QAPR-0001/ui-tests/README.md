# QAPR-0001 - UI Tests

## Prerequisites
- Node.js 18+ (any version supported by `@playwright/test` 1.62.x)
- The application under test (Juice Shop, `juice-shop-master/`) running and reachable at `http://localhost:3000`
  — either run `juice-shop-master\runme.bat` (starts it, killing anything already on port 3000 first),
  or `npm start` from `juice-shop-master/` manually, in a separate terminal.

## Install

```
cd "QAPR-0001/ui-tests"
npm install
npx playwright install chromium
```

## Run

```
npx playwright test --workers=1
```

`--workers=1` is recommended: this suite runs against a single Juice
Shop dev-mode instance, and parallel workers were observed to cause
intermittent, unrelated timeouts under concurrent load. `npm test` runs
the default (parallel) config if you want to compare.

Or run a single file:

```
npx playwright test registration-page-access.spec.ts
```

## View Report

```
npx playwright show-report
```

Opens the HTML report from the last run. Failing tests include a trace,
a screenshot, and a video — open the trace to scrub through the exact
DOM/network/console state at each test.step.

## Notes
- Page Objects used by these tests live in the shared `ui-framework/pages/`
  folder at the repository root, not inside this folder — they're
  reused across issues targeting the same app. It's named
  `ui-framework/` (not `ui-tests/`) specifically so it doesn't look
  like just another per-issue `ui-tests/` output folder.
- Every test that creates an account through the UI cleans it up via
  `DELETE /api/Users/:id` in a `finally` block (confirmed available,
  same endpoint used by `QAPR-0001/api-tests`).
- TC-REQ-2e.3 is not included in this run — the app has no client-side
  enforcement of the 128-character Security Answer maximum, so there is
  no selector to generate against. See `summary.md`.
- 27 UI-classified test cases (REQ-7 through REQ-24) were deferred by
  the user's Selection Checkpoint choice and are not included in this
  run. See `summary.md`.
- TC-REQ-1.2 and TC-REQ-4.2 fail against the current app (confirmed —
  9 passed, 2 failed as of the last run) — both surface a genuine
  requirement-vs-implementation gap discovered in the codebase, not a
  test defect. See `summary.md`.
