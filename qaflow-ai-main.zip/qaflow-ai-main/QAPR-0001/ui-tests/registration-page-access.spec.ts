import { test, expect } from '@playwright/test';
import { RegistrationPage } from '../../ui-framework/pages/RegistrationPage';
import { LoginPage } from '../../ui-framework/pages/LoginPage';

const NEW_ACCOUNT_PASSWORD = 'Str0ngP@ssw0rd!'; // [test data] valid mandatory data

function uniqueEmail(label: string) {
  return `ui-${label}-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per run
}

// TC-REQ-1.1
test('TC-REQ-1.1: Registration page is accessible to an unauthenticated visitor', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);

  await test.step('Navigate to the registration page', async () => {
    await registrationPage.goto();
  });

  await test.step('Verify the registration page loads and is displayed', async () => {
    await expect(
      registrationPage.emailInput,
      'expected the registration form (Email field) to be visible for an unauthenticated visitor'
    ).toBeVisible();
  });
});

// TC-REQ-1.2
test('TC-REQ-1.2: Authenticated user opening the registration page is redirected away from it', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);
  const loginPage = new LoginPage(page);
  const email = uniqueEmail('auth-redirect');
  let userId: number | undefined;

  await test.step('Precondition: register and log in as a new user', async () => {
    userId = await registrationPage.registerNewAccount({
      email,
      password: NEW_ACCOUNT_PASSWORD,
      securityAnswer: 'TestAnswer123', // [test data]
    });
    await loginPage.goto();
    await loginPage.login(email, NEW_ACCOUNT_PASSWORD);
  });

  try {
    await test.step('While authenticated, navigate to the registration page URL', async () => {
      await registrationPage.goto();
    });

    await test.step('Verify the user is redirected away and the registration form is not displayed', async () => {
      await expect(
        page,
        'expected the app to redirect an authenticated user away from /#/register'
      ).not.toHaveURL(/#\/register/);
      await expect(
        registrationPage.emailInput,
        'expected the registration form not to be displayed to an authenticated user'
      ).not.toBeVisible();
    });
  } finally {
    if (userId) {
      await page.request.delete(`/api/Users/${userId}`);
    }
  }
});
