import { test, expect } from '@playwright/test';
import { attachExchange, uniqueEmail } from './helpers';

// REQ-8: LOGIN-006 — failed authentication shall not create an authenticated
// session. Endpoints: POST /rest/user/login (to produce the rejected
// attempt) and GET /rest/user/whoami (routes/currentUser.ts) as the
// authenticated-only check — it resolves identity strictly from the
// 'token' cookie (confirmed in the codebase) and returns { user: {} } when
// no valid session exists.

// TC-REQ-8.1
test('TC-REQ-8.1: A rejected login attempt does not establish an authenticated session', async ({ request }, testInfo) => {
  const unknownEmail = uniqueEmail('no-session'); // [test data] unique per run, guaranteed not registered

  // Act — a login attempt is rejected
  const loginBody = { email: unknownEmail, password: 'anyPassword1' };
  const loginResponse = await request.post('/rest/user/login', { data: loginBody });
  const loginRespBody = await attachExchange(testInfo, 'act: rejected login attempt', { method: 'POST', url: '/rest/user/login', body: loginBody }, loginResponse);
  expect(loginResponse.status(), `expected 401 for the rejected login, got ${loginResponse.status()} - ${JSON.stringify(loginRespBody)}`).toBe(401);

  // Assert — request authenticated-only data using whatever session state resulted
  // (no token cookie was ever issued by the rejected attempt, so none is sent)
  const whoamiResponse = await request.get('/rest/user/whoami');
  const whoamiRespBody = await attachExchange(testInfo, 'assert: whoami after rejected login', { method: 'GET', url: '/rest/user/whoami' }, whoamiResponse);

  expect(whoamiResponse.status(), `expected 200 (whoami always responds 200, with an empty user when unauthenticated), got ${whoamiResponse.status()}`).toBe(200);
  expect(whoamiRespBody.user, `expected an empty user object (no authenticated session), got ${JSON.stringify(whoamiRespBody)}`).toEqual({});
});
