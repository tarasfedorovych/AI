---
name: ui-tests
description: >
  Ninth stage of task processing. Takes test cases and the
  automation-strategy classification and generates Playwright UI
  test files in TypeScript for every test case classified as UI,
  using a reusable Page Object Model layer and Playwright's own
  browser fixture. Optionally uses a provided frontend codebase
  folder or a running app URL for selector/page discovery, and
  detects existing Playwright/Page Object setup to reuse instead of
  regenerating it. Use when the user says "generate UI tests",
  "automate the UI test cases", "write Playwright UI tests", or
  after automation-strategy completion.
---

# UI Tests

> ⚙️ Recommended settings: **Sonnet · Effort: High · Extended thinking: Off**

Generates Playwright UI test files in TypeScript for every test case
classified as UI by the automation-strategy skill, using Playwright
Test's browser fixtures through a Page Object Model (POM) layer.
Never puts raw locators directly in a spec file.

## Input Data

Required:
1. Test cases file `<ISSUEKEY>/test-cases.md` created by qa-test-cases.
2. Automation strategy file `<ISSUEKEY>/automation-strategy.md` created
   by automation-strategy — used to filter to only TC-REQ items marked
   `UI`.

In the same chat, both files are available in the `<ISSUEKEY>/` folder
automatically. If the chat is new — the user uploads them to the chat.

Optional:
3. A path to an existing frontend codebase folder — used for
   selector/page discovery and to detect an existing Playwright/POM
   setup.
4. A base URL of a running instance of the app — used for live
   selector discovery when the codebase isn't available or doesn't
   cover a given page (see Code/Page Access).
5. A path to the shared Page Object library, if it isn't at the
   default location `ui-framework/pages/` in the working directory root.

If either required file is missing — stop and inform the user which
upstream skill needs to run first.

If there are zero TC-REQ items classified `UI` in the automation
strategy file — inform the user there is nothing to generate and stop.

All input files and any provided codebase folder are read-only. This
skill writes new files under `<ISSUEKEY>/ui-tests/`, and — as the one
sanctioned exception — creates or extends Page Object files under the
shared `ui-framework/pages/` folder at the working directory root (see
Output File). It never edits, deletes, or adds files anywhere inside a
provided codebase folder.

Do not go to the tracker, do not search the internet unless resolving
something the user explicitly gave a URL for.

## Rules

- All communication and all output file content — in English.
- Chat messages — brief.
- Generate tests only for TC-REQ items marked `UI` in the automation
  strategy file, and only for the subset the user selects in the
  Selection Checkpoint below. Do not generate tests for API or Manual
  items.
- Never invent page URLs, navigation paths, selectors, or field/button
  identifiers. Discover them from a provided codebase or a live
  discovery pass (see Code/Page Access). If neither is provided, or
  discovery doesn't cover a given TC-REQ item, ask the user for that
  specific test case's page/selector details before generating its
  test — one clear, batched question listing exactly which TC-REQ
  items need which details, not a vague "give me your app's markup."
- Every locator is defined once inside its Page Object (exposed as a
  readonly property or built inside an action method) — a spec file
  never constructs a fresh `page.locator(...)`/`page.getByRole(...)`
  inline. Actions go through Page Object methods; assertions in the
  spec target the Page Object's exposed locators. Page Object methods
  never call `expect()` themselves — see references/
  playwright-ui-conventions.md for why (module-resolution, not just
  style). This is what makes the POM layer actually reusable instead of
  decorative.
- Before creating a new Page Object, check whether one already exists
  for that page in the shared `ui-framework/pages/` folder. If found, reuse
  it and only add the locators/methods the current test cases need —
  never remove, rename, or rewrite an existing method, since other
  issues' specs may already depend on it.
- Selector priority, most to least preferred (Playwright best
  practices): `getByRole` → `getByLabel`/`getByPlaceholder` →
  `getByText` → `getByTestId` (only when the app already exposes
  stable `data-testid`s) → CSS/XPath selector (last resort only, and
  must be flagged as a fragility note in `summary.md` when used). Never
  select by an auto-generated/dynamic class name or by DOM position
  (`nth-child`).
- No manual waits or sleeps (`page.waitForTimeout`, arbitrary `sleep`).
  Use Playwright's own auto-retrying web-first assertions
  (`toBeVisible`, `toHaveText`, `toContainText`, etc.) and locator
  actions, which wait for actionability on their own.
- Read-only with respect to any provided codebase: never modify
  `playwright.config.ts`, existing test files, `package.json`, or
  anything else inside that folder. Generated `.spec.ts`/mapping/
  summary output goes exclusively into `<ISSUEKEY>/ui-tests/`; Page
  Object output goes exclusively into the shared `ui-framework/pages/`
  folder — never anywhere else.
- Every generated test must carry its TC-REQ-ID visibly in the test
  title (e.g. `test('TC-REQ-1.1: Registration page is accessible to an
  unauthenticated visitor', ...)`) so traceability survives even if the
  file is viewed in isolation.
- Do not add tests, assertions, or setup steps beyond what the source
  test case describes.
- Every test must be understandable from its own output alone — the
  HTML report — without opening the source file or re-running it.
  Unlike API tests, this does not need a custom attach-helper: a
  browser test's failure already gets a trace, a screenshot, and (if
  configured) a video attached automatically by Playwright. What this
  skill must still do deliberately: wrap each logical phase in
  `test.step(...)` so the report's step list narrates the scenario, and
  give every `expect()` a message stating expected vs. actual. See
  "Traceability in Test Output" in
  references/playwright-ui-conventions.md.
- Cleanup is generation-framework hygiene, not test-case content, and
  is required (not optional) whenever it's discoverable: if a test
  creates persistent data through the UI (e.g. registers an account)
  and a confirmed delete/reset mechanism exists (a UI flow or an API
  endpoint), generate a best-effort cleanup call for it in `finally`,
  even though the test case's own steps don't mention cleanup. Never
  invent a cleanup mechanism that isn't discovered/confirmed; if none
  exists, state that plainly in the mapping entry and in summary.md
  instead of silently omitting it.
- Do not change data in the system beyond what a test case's own steps
  require, same as any other step in this pipeline — do not add extra
  records, deletions, or setting changes the test case doesn't ask for.
- After saving files — stop. Do not run the tests, do not continue to
  further skills.

## Selection Checkpoint

Resource-intensive generation should be scoped deliberately, not run
for every UI-classified item automatically. After filtering
automation-strategy.md to `UI` rows, before doing any discovery or
generation:

1. Show the user counts and the full list, grouped by REQ:
   ```
   UI-classified test cases: [N], across [M] requirement groups.

   REQ-1: Registration page access (2)
     - TC-REQ-1.1: Registration page is accessible to an unauthenticated visitor
     - TC-REQ-1.2: Authenticated user opening the registration page is redirected away from it
   REQ-4: Mandatory field validation (2)
     - TC-REQ-4.1: ...
     - TC-REQ-4.2: ...

   Which should be generated in this run? (all / a list of TC-REQ IDs / by REQ group)
   ```
2. Wait for the user's answer. Accept "all" as a valid answer.
3. Only the selected subset proceeds to Code/Page Access and
   generation. Every UI-classified TC-REQ item not selected is recorded
   in `summary.md` under "Deferred by user" — distinct from "Pending —
   discovery needed" (used later for selected items discovery couldn't
   cover).

## Code/Page Access

Three possible input combinations, evaluated only for the TC-REQ items
selected in the Selection Checkpoint. Determine which applies before
generating anything.

### A. Frontend codebase folder provided

1. Ask for or confirm the folder path if not already given.
2. Selector/page discovery — search the codebase (read-only) for:
   - Components/templates for each target page — look for `data-testid`
     attributes, ARIA `role`/`aria-label`, associated `<label>`
     elements, and visible text for buttons/messages.
   - An existing `e2e`/`tests` folder with its own Page Objects — if the
     app already has POM conventions of its own, follow those instead
     of inventing a new file layout (but still write this run's output
     under `<ISSUEKEY>/ui-tests/` and the shared `ui-framework/pages/`
     folder, per Output File).
   For each UI-classified TC-REQ item, match its described page/flow
   (from the test case + rationale in automation-strategy) to the
   closest real page/component. If no confident match is found — do
   not guess; list it as needing user clarification or live discovery.
3. Playwright setup detection — check for:
   - `playwright.config.ts`/`.js` — read `baseURL`, `projects`, `use`
     defaults (viewport, storageState), reporter configuration.
   - Existing auth fixtures (a `storageState` file, a global-setup
     login step) — reuse the same pattern instead of re-inventing login
     per test.
   - Dependency check: does the provided codebase's `package.json`
     already list `@playwright/test`, and are browser binaries
     installed (`node_modules/@playwright` present, or a documented
     `playwright install` step)? If yes, generated tests can run from
     inside that codebase folder as-is — state this in `README.md`. If
     no — or no codebase was provided at all — `<ISSUEKEY>/ui-tests/`
     is self-contained and unrunnable without its own `package.json`
     and a `playwright install` step (see Dependency Scaffolding).

### B. Running app URL provided (with or without codebase)

Used when no codebase is available, or the codebase doesn't confidently
cover a given page.

1. Confirm the base URL and which pages are needed, from the selected
   test cases' preconditions/titles.
2. Run a one-shot headless discovery script (full example in
   references/playwright-ui-conventions.md) that navigates to each
   needed page and captures an ARIA snapshot via
   `page.locator('body').ariaSnapshot()`, writing one JSON file per run
   to `<ISSUEKEY>/ui-tests/discovery/pages.json`. Read that file once
   to get role/name/label information for every element the selected
   test cases need — do not drive the browser interactively step by
   step for this.
3. Prefer this scripted pass over Playwright MCP: it collapses what
   would otherwise be many MCP tool-call round trips (one per
   navigate/snapshot/click) into a single script run plus a single file
   read — the same reason API discovery prefers reading a Swagger
   doc/codebase once over probing endpoints interactively.
4. Use Playwright MCP only as a fallback, and only if it is actually
   configured in this environment: when reaching a target page depends
   on a flow the script can't predict up front (e.g. an unknown login
   sequence, a conditional multi-step wizard). If MCP isn't configured
   and the flow is unknown — ask the user for the navigation steps
   instead of guessing.
5. If a page still has no confident selector/navigation match after
   this — do not guess; list it as needing user clarification.

### C. Neither codebase nor a running app URL provided

Do not invent any page URL, selector, or navigation step. For every
UI-classified TC-REQ item, ask the user directly:

- Page URL, or how to navigate to it from the app's entry point?
- For each field/button/message the test case mentions: how would you
  describe it to someone who's never seen the page (label text,
  placeholder, button text, or a known `data-testid`)?
- Any login/precondition needed to reach the page?

Batch this into one question per test case (or per REQ group, if
several test cases share the same page), not one message per field. Do
not generate that test until answered. Test cases whose details are
answered can be generated while others are still pending clarification
— do not block the whole batch on one unanswered item.

## UI Mapping (Intermediate Artifact)

Before generating any Playwright code, produce a framework-agnostic
mapping file: `<ISSUEKEY>/ui-tests/ui-mapping.json`. This persists the
page/selector-discovery decisions (which page, which Page Object —
new or reused, which locators, why a `[test data]` literal was
substituted, what cleanup is available) as reviewable data instead of
burying them only in code comments.

One entry per selected UI-classified TC-REQ item (including pending
ones). Schema and worked examples — in
references/ui-mapping-schema.md.

Generate the `.spec.ts` files strictly from what's in `ui-mapping.json`
(not by re-deriving page/selector details from test-cases.md a second
time) — this keeps the mapping file the actual source of truth for
what gets generated, not a parallel document that can drift from the
code.

If a mapping entry has no confirmed page/selector for a step — do not
generate that entry's test; keep it as `"status": "pending"` with a
`reason`, matching the pending-clarification handling in Rules above.

## Dependency Scaffolding

Generated tests must be runnable with nothing more than the how-to-run
steps in `README.md` — never assume `@playwright/test`, browser
binaries, or any other dependency is already available on whatever
machine ends up running them.

If dependency check (in Code/Page Access, section A) found that the
provided codebase already has `@playwright/test` installed, configured,
and browsers available — generated tests can run from there; do not
create a second `package.json`, just document the existing install path
in `README.md`.

Otherwise (no codebase provided, or no existing Playwright/npm setup
found), `<ISSUEKEY>/ui-tests/` must be self-contained: generate a
`package.json` there with `@playwright/test` as a devDependency (pin an
exact recent version — do not use `latest` or a bare `*`) and a `test`
script (`"test": "playwright test"`). Unlike API tests, UI tests need
real browser binaries — `README.md` must include `npx playwright
install chromium` as an explicit install step; never assume it's
already installed globally.

## Playwright Generation Conventions

Full conventions — in references/playwright-ui-conventions.md. Summary:

- Framework: Playwright Test's browser fixtures —
  `import { test, expect } from '@playwright/test';`.
- One `.spec.ts` file per REQ group (not per TC-REQ), named by
  feature/page slug, e.g. `registration-page-access.spec.ts`. A REQ
  group with only one UI TC-REQ item still gets its own small file, to
  keep 1:1 traceability to a REQ obvious from the filename.
- One `test()` block per TC-REQ item inside each file. Test title
  format: `'TC-REQ-<id>: <scenario name from test case>'`, with a
  `// TC-REQ-<id>` comment directly above the `test()` call.
- Every spec imports the Page Object(s) it needs from the shared
  `ui-framework/pages/` folder via a relative import — never inlines a raw
  locator.
- Structure per test, wrapped in `test.step(...)` per phase: navigate
  (via a Page Object method) → act (fill/click via Page Object methods,
  using the test case's Test Data column) → assert (via
  auto-retrying `expect(locator)...` with a descriptive message),
  mirroring the test case's own Steps/Expected Result rows one-to-one
  where practical.
- Use the test case's exact literal values where specified (field
  values, expected messages); use realistic placeholder values only for
  anything marked `[test data]`, kept as clearly-named constants at the
  top of the file.

## Output File

Create the folder `<ISSUEKEY>/ui-tests/` in the working directory if it
does not exist. Inside it, create:
- `ui-mapping.json` — the framework-agnostic mapping described above
  (see references/ui-mapping-schema.md). Generate this first.
- One `.spec.ts` file per REQ group containing selected UI-classified
  test cases (see Playwright Generation Conventions).
- `playwright.config.ts` — only if no existing Playwright config was
  found in a provided codebase folder. If an existing config was found,
  do not create a duplicate; state in summary.md which existing config
  the tests assume.
- `package.json` — only if no existing `@playwright/test` install was
  found in a provided codebase folder (see Dependency Scaffolding).
- `discovery/pages.json` — only if a live discovery pass (Code/Page
  Access, section B) was run this session.
- `summary.md` — traceability document: mapping reference, per-TC-REQ
  status table, Selection Checkpoint results (Selected/Deferred by
  user), Page Objects Reused vs. Created, selector-fragility notes,
  cleanup coverage (see references/output-template.md).
- `README.md` — human-facing how-to-run instructions: prerequisites
  (including browser install), install command, run command, required
  environment/base URL (see references/output-template.md).

Outside the issue folder — the one sanctioned exception to writing
only into `<ISSUEKEY>/ui-tests/`: create or extend Page Object files
under `ui-framework/pages/` at the working directory root (e.g.
`ui-framework/pages/RegistrationPage.ts`), shared across every issue that
targets the same app. It's named `ui-framework/`, not `ui-tests/`,
specifically to avoid looking like just another `<ISSUEKEY>/ui-tests/`
output folder — it's the reusable framework layer, not this issue's
generated output. Check this folder for an existing matching Page
Object before creating a new one (see Rules and
references/playwright-ui-conventions.md's Reuse Rule).

Give the user the folder path for download. The files remain in
`<ISSUEKEY>/ui-tests/` — this is the last step in the chain, nothing
consumes them automatically afterward (deferred/pending items may later
feed into the manual-testing skill for manual/exploratory execution).

If files with the same names already exist in `<ISSUEKEY>/ui-tests/` —
delete them completely and create new ones. Always output the result of
the latest run only. Files in the shared `ui-framework/pages/` folder are
never deleted wholesale — only extended (see Rules).

Output template — in references/output-template.md.

## Verification Before Saving

Before saving, verify:

- Every selected UI-classified TC-REQ item has exactly one
  corresponding `test()` block, unless it was left pending user
  clarification (listed explicitly in summary.md instead).
- Every TC-REQ item not selected in the Selection Checkpoint is listed
  under "Deferred by user" in summary.md.
- Every test title contains its TC-REQ-ID.
- No `.spec.ts` file constructs a fresh `page.locator`/`page.getByRole`/
  etc. call inline — every interaction goes through a Page Object
  method, and every assertion targets a locator already exposed by the
  Page Object. No Page Object method calls `expect()` itself.
- No selector was invented — every one traces to the codebase, a live
  discovery snapshot, or an explicit user answer.
- Every entry in `ui-mapping.json` has a corresponding `.spec.ts` test,
  except `"status": "pending"` entries.
- Every mapping entry for a test that creates persistent data states
  either a confirmed `cleanup` step or explicitly notes that no cleanup
  mechanism was found.
- `README.md` exists, includes the `playwright install` step when a
  package.json was scaffolded, and its install/run commands match what
  was actually scaffolded vs. reused.
- An HTML reporter and `trace: 'retain-on-failure'` /
  `screenshot: 'only-on-failure'` / `video: 'retain-on-failure'` are
  configured (scaffolded config) or a documented fallback exists
  (reused existing config that doesn't already set these).
- Every `expect()` carries a descriptive message with expected vs.
  actual.
- Any CSS/XPath selector used is flagged as a fragility note in
  summary.md.

## Final Response

After saving, inform:
- Path to `<ISSUEKEY>/ui-tests/`
- Number of `.spec.ts` files and `test()` blocks generated
- Number of TC-REQ items covered vs. deferred by user vs. pending
  clarification
- Page Objects reused vs. newly created (with paths under
  `ui-framework/pages/`)
- Whether a self-contained `package.json` was scaffolded or an
  existing codebase install is assumed
- How-to-run command (matching what's in `README.md`), including the
  browser-install step if scaffolded
