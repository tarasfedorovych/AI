import { test, expect } from '@playwright/test';
import { LoginPage } from '../../ui-framework/pages/LoginPage';

// REQ-1: Preconditions — the login page is accessible to an unauthenticated
// visitor.

// TC-REQ-1.1
test('TC-REQ-1.1: Login page is accessible to an unauthenticated visitor', async ({ page }) => {
  const loginPage = new LoginPage(page);

  await test.step('Navigate to the login page', async () => {
    await loginPage.goto();
  });

  await test.step('Verify the login page loads and is displayed', async () => {
    await expect(
      loginPage.emailInput,
      'expected the login form (Email field) to be visible for an unauthenticated visitor'
    ).toBeVisible();
  });
});
