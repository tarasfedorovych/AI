# QAPR-0001 - API Tests

## Prerequisites
- Node.js (any version supported by `@playwright/test` 1.62.x, i.e. 18+)
- The application under test (Juice Shop, `juice-shop-master/`) running and reachable at `http://localhost:3000`
  — either run `juice-shop-master\runme.bat` (starts it, killing anything already on port 3000 first),
  or `npm start` from `juice-shop-master/` manually, in a separate terminal.

## Install

```
cd "QAPR-0001/api-tests"
npm install
```

No `playwright install` step needed — these tests only use Playwright's
`request` fixture (plain HTTP calls), not a browser.

## Run

```
npm test
```

Or run a single file:

```
npx playwright test registration-account-creation.spec.ts
```

## View Report

```
npx playwright show-report
```

Opens the HTML report from the last run in a browser (pass/fail per
test, error details, timing). The config sets `open: 'never'` so
`npm test` won't try to launch it automatically — run this command
afterward whenever you want to look at results.

Every test also attaches the full request/response exchange for each
API call it makes (see `helpers.ts`) — open any test in the report and
its attachments show exactly what was sent and what came back, not
just pass/fail.

## Notes
- Tests create real accounts via `POST /api/Users` and clean up after
  themselves via `DELETE /api/Users/:id` where applicable — see
  `summary.md`'s Cleanup Coverage table.
- 5 test cases (TC-REQ-16.1, TC-REQ-16.3, TC-REQ-25.1–25.3) are not
  included in this run — they need log/DB access or a fault-injection
  mechanism that doesn't exist yet. See `summary.md` Pending
  Clarifications and `api-mapping.json` for details.
- Endpoint/request details for every generated test are in
  `api-mapping.json`.
