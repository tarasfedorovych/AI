import { test, expect } from '@playwright/test';
import { attachExchange, uniqueEmail, decodeJwtPayload } from './helpers';

// REQ-16: BR-LOGIN-002 — passwords shall never be stored or logged in
// plaintext, and never returned in any API response or error output.
// Endpoints: POST /api/Users, POST /rest/user/login.

const KNOWN_PASSWORD = 'Str0ngP@ss1'; // [test data]
const WRONG_PASSWORD = 'WrongP@ss1'; // [test data]

// TC-REQ-16.1
test('TC-REQ-16.1: The submitted Password value is not returned in any login API response, including error responses', async ({ request }, testInfo) => {
  const email = uniqueEmail('password-exposure');

  await test.step('register with a known password', async () => {
    const registerBody = { email, password: KNOWN_PASSWORD, passwordRepeat: KNOWN_PASSWORD };
    const response = await request.post('/api/Users', { data: registerBody });
    const bodyText = await response.text();
    await attachExchange(testInfo, 'register', { method: 'POST', url: '/api/Users', body: registerBody }, response);
    expect(response.status(), `expected 201 Created, got ${response.status()} - ${bodyText}`).toBe(201);
    expect(bodyText.includes(KNOWN_PASSWORD), `expected the register response not to contain the plaintext password, got ${bodyText}`).toBe(false);
  });

  await test.step('successful login with the known password', async () => {
    const loginBody = { email, password: KNOWN_PASSWORD };
    const response = await request.post('/rest/user/login', { data: loginBody });
    const bodyText = await response.text();
    await attachExchange(testInfo, 'login success', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);
    expect(response.status(), `expected 200 OK, got ${response.status()} - ${bodyText}`).toBe(200);
    expect(bodyText.includes(KNOWN_PASSWORD), `expected the login response not to contain the plaintext password (the JWT contains a hash of it, not the plaintext value), got ${bodyText}`).toBe(false);
  });

  await test.step('failed login with a wrong password', async () => {
    const loginBody = { email, password: WRONG_PASSWORD };
    const response = await request.post('/rest/user/login', { data: loginBody });
    const bodyText = await response.text();
    await attachExchange(testInfo, 'login failure', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);
    expect(response.status(), `expected 401, got ${response.status()} - ${bodyText}`).toBe(401);
    expect(bodyText.includes(WRONG_PASSWORD), `expected the error response not to contain the submitted password, got ${bodyText}`).toBe(false);
  });
});

// TC-REQ-16.2
test('TC-REQ-16.2: The issued session/token does not contain the plaintext Password value', async ({ request }, testInfo) => {
  const email = uniqueEmail('token-password-content');

  const registerBody = { email, password: KNOWN_PASSWORD, passwordRepeat: KNOWN_PASSWORD };
  const registerResponse = await request.post('/api/Users', { data: registerBody });
  const registerRespBody = await attachExchange(testInfo, 'arrange: register account', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
  expect(registerResponse.status(), `expected 201 Created, got ${registerResponse.status()} - ${JSON.stringify(registerRespBody)}`).toBe(201);

  const loginBody = { email, password: KNOWN_PASSWORD };
  const loginResponse = await request.post('/rest/user/login', { data: loginBody });
  const loginRespBody = await attachExchange(testInfo, 'login', { method: 'POST', url: '/rest/user/login', body: loginBody }, loginResponse);
  expect(loginResponse.status(), `expected 200 OK, got ${loginResponse.status()} - ${JSON.stringify(loginRespBody)}`).toBe(200);

  const token: string = loginRespBody.authentication.token;
  const payload = decodeJwtPayload(token);
  await testInfo.attach('decoded token payload', { body: JSON.stringify(payload, null, 2), contentType: 'application/json' });

  // Discovery note (not a failure): the payload's data.password field is an
  // MD5 hash of the password (lib/insecurity.ts's hash()), confirmed by this
  // very decode — 32 hex characters, never the plaintext value. REQ-20's
  // "shall not contain passwords" is interpreted as plaintext specifically
  // (see requirements.md's REQ-20 assumption); this assertion checks exactly
  // that narrower, defensible claim.
  expect(
    payload?.data?.password,
    `expected the token payload's password field not to equal the plaintext password, got ${JSON.stringify(payload?.data?.password)}`
  ).not.toBe(KNOWN_PASSWORD);
  expect(
    JSON.stringify(payload).includes(KNOWN_PASSWORD),
    `expected the plaintext password not to appear anywhere in the decoded token payload, got ${JSON.stringify(payload)}`
  ).toBe(false);
});
