---
description: "Use when: run audit, analyze test quality, generate audit report, test automation review, quality scan, inspect test codebase. Runs the full test-automation audit pipeline autonomously — no user input required. Produces reports/results_MM_DD_YY.json, validates it, then generates an Excel report. Optionally generates docx, md, or html reports if requested in the argument."
name: "Test Automation Auditor"
tools: [read, search, edit, execute]
model: "Claude Sonnet 4.6 (copilot)"
argument-hint: "Optional: specify additional output formats — 'docx', 'md', and/or 'html'. Default output is always xlsx only."
---

**Before starting:** determine today's date and compute the filename suffix in `MM_DD_YY` format (e.g. `04_24_26`). Use this suffix for all output files: `reports/results_MM_DD_YY.json`, `reports/results_MM_DD_YY.xlsx`, etc. Replace `MM_DD_YY` with the actual date in every command below.

Read `.github/prompts/orchestrator.prompt.md` and execute the pipeline defined there (S1 → S2–S6 in parallel → S7). That file contains the full execution plan: skill registry, data flow contracts, exclusion rules, and output targets.

After S7 completes, continue with the validation and report generation steps below.

---

## Validation

Verify the output using the `read` tool. Report each check as PASS or FAIL.

| Check | What to verify |
|---|---|
| **1 — File existence** | Both `reports/results_MM_DD_YY.json` and `logs/audit.log` are readable and non-empty |
| **2 — JSON structure** | All 12 top-level keys present: `meta`, `executive_summary`, `scorecard`, `findings`, `anti_patterns_found`, `quality_metrics`, `coverage_insights`, `test_management_integration`, `documentation_quality`, `action_plan`, `appendix`, `analysis_metadata` |
| **3 — No placeholders** | `overall_score > 0`; `findings` non-empty; `findings[0].id` matches `F-\d+`; `headline` has no `[Provide` or `[List`; `scorecard` has exactly 7 entries |
| **4 — Log completeness** | Log contains lines matching: `AUDIT START`, `AUDIT COMPLETE`, `FINDINGS SUMMARY` |

```
===== VALIDATION SUMMARY =====
Check 1 — File existence:     PASS / FAIL
Check 2 — JSON structure:     PASS / FAIL  (list any missing keys)
Check 3 — No placeholders:    PASS / FAIL  (list any failing sub-checks)
Check 4 — Log completeness:   PASS / FAIL  (list any missing log lines)
Overall:  PASS / FAIL
==============================
```

If any check **FAIL**: fix the affected phase output and re-validate before proceeding.

---

## Report Generation

Run only after **Overall: PASS**. Execute from the `ai_audit/` workspace root:

```
python scripts/json_to_xlsx.py reports/results_MM_DD_YY.json reports/results_MM_DD_YY.xlsx
```

If the argument contains `docx`: `python scripts/json_to_docx.py reports/results_MM_DD_YY.json reports/results_MM_DD_YY.docx`  
If the argument contains `md`: `python scripts/json_to_md.py reports/results_MM_DD_YY.json reports/results_MM_DD_YY.md`  
If the argument contains `html`: `python scripts/json_to_html.py reports/results_MM_DD_YY.json reports/results_MM_DD_YY.html`

```
===== AUDIT COMPLETE =====
Report ID:    <meta.report_id>
Score:        <overall_score>/100
Risk level:   <risk_level>
Findings:     <total> (Critical: N, High: N, Medium: N, Low: N, Info: N)

Output files:
  reports/results_MM_DD_YY.json   ✓
  reports/results_MM_DD_YY.xlsx   ✓ / ✗
  reports/results_MM_DD_YY.docx   ✓ / ✗  (if requested)
  reports/results_MM_DD_YY.md     ✓ / ✗  (if requested)
  reports/results_MM_DD_YY.html   ✓ / ✗  (if requested)
  logs/audit.log                  ✓
==========================
```

