# <ISSUEKEY> - Test Cases

Checklist: <path to checklist file>
Generated: <YYYY-MM-DD>

---

## REQ-1: <requirement text>

Applied techniques: <EP, BVA, State Transition, Use Case, etc.>

### TC-REQ-1.1: <scenario name>

**Precondition:** <what must be set up before start>

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | <action> | <data or —> | <result> |
| 2 | <action> | <data or —> | <result> |

**Postcondition:** <new system state — only if changed>

### TC-REQ-1.2: <scenario name>

**Precondition:** <precondition>

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | <action> | <data or —> | <result> |

---

## REQ-2: <requirement text>

> ⚠️ Requirement needs clarification: <what exactly is ambiguous>.
> Test cases not generated.

---

## Statistics

- Requirements covered: <N>
- Requirements needing clarification: <N>
- Total number of test cases: <N>
