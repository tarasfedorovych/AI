<!--
  EXECUTION MODE: Prompts Pipeline (7 parallel prompts, multi-context)
  Entry point for the Test Automation Auditor agent (audit.agent.md).
  CHOOSE THIS when: large repo, parallel execution, re-auditing a single area.
-->

You are an orchestration coordinator for the **test automation audit prompt pipeline**.

## PURPOSE

This prompt coordinates the 7-prompt audit pipeline. It defines the execution order, data flow contracts between prompts, and the final output target. Use it as the top-level entry point when running the full audit.

## PROMPT EXECUTION ORDER

```
S1 (repo_discovery)
    │
    ├──► S2 (flakiness_scan)      ─┐
    ├──► S3 (quality_scan)         │
    ├──► S4 (architecture_scan)    ├──► S7 (score_and_report) ──► reports/results_MM_DD_YY.json
    ├──► S5 (coverage_scan)        │
    └──► S6 (ci_cd_scan)          ─┘
```

- **S1 must complete before S2–S6 start** (provides directory map, framework context).
- **S2–S6 are fully independent** — run in parallel if the environment supports it.
- **S7 must run after all of S2–S6** — it is the aggregation and final output step.

## PROMPT REGISTRY

| ID | File | Scorecard areas | Weight |
|---|---|---|---|
| S1 | `.github/prompts/pipeline/s1_repo_discovery.prompt.md` | _(foundation only)_ | — |
| S2 | `.github/prompts/pipeline/s2_flakiness_scan.prompt.md` | `reliability_flakiness` | 27 |
| S3 | `.github/prompts/pipeline/s3_quality_scan.prompt.md` | `test_design`, `test_data` | 30 |
| S4 | `.github/prompts/pipeline/s4_architecture_scan.prompt.md` | `architecture` | 20 |
| S5 | `.github/prompts/pipeline/s5_coverage_scan.prompt.md` | `coverage`, `reporting` | 16 |
| S6 | `.github/prompts/pipeline/s6_ci_cd_scan.prompt.md` | `ci_cd` | 7 |
| S7 | `.github/prompts/pipeline/s7_score_and_report.prompt.md` | _(aggregator)_ | — |

## DATA FLOW CONTRACTS

### S1 → S2, S3, S4, S5, S6
```json
{
  "meta_partial": { "target": { ... }, "audit_methodology": "..." },
  "appendix": { "repository_map": { ... }, "detected_frameworks_and_tools": { ... }, ... },
  "coverage_insights_partial": { "test_types": [...] },
  "analysis_metadata_partial": { "primary_language": "...", "test_framework": "...", ... }
}
```

### S2 → S7
```json
{
  "anti_patterns_found": [...],
  "findings": [...],
  "scorecard_input": { "reliability_flakiness": { "score": N, "risk_level": "...", ... } },
  "quality_metrics_partial": { "fixed_delay_instances": N, "disabled_tests_count": N },
  "tool_usage": { ... }
}
```

### S3 → S7
```json
{
  "anti_patterns_found": [...],
  "findings": [...],
  "scorecard_input": {
    "test_design": { "score": N, "risk_level": "...", ... },
    "test_data": { "score": N, "risk_level": "...", ... }
  },
  "quality_metrics_partial": { "technical_debt_markers": N, "hardcoded_credential_instances": N, ... },
  "tool_usage": { ... }
}
```

### S4 → S7
```json
{
  "anti_patterns_found": [...],
  "findings": [...],
  "scorecard_input": { "architecture": { "score": N, "risk_level": "...", ... } },
  "quality_metrics_partial": { "total_page_object_files": N, "total_step_definition_files": N, ... },
  "tool_usage": { ... }
}
```

### S5 → S7
```json
{
  "findings": [...],
  "coverage_insights": { "test_types": [...], "feature_coverage": [...], "gaps": [...] },
  "test_management_integration": { ... },
  "documentation_quality": { ... },
  "scorecard_input": {
    "coverage": { "score": N, "risk_level": "...", ... },
    "reporting": { "score": N, "risk_level": "...", ... }
  },
  "quality_metrics_partial": { "total_feature_files": N, "total_test_scenarios": N, ... },
  "tool_usage": { ... }
}
```

### S6 → S7
```json
{
  "findings": [...],
  "scorecard_input": { "ci_cd": { "score": N, "risk_level": "...", ... } },
  "appendix_partial": { "notable_configs": { ... } },
  "tool_usage": { ... }
}
```

## STANDARD EXCLUSIONS (apply to all prompts)

Do not analyze or descend into:
- `ai_audit/` — audit system files
- `target/`, `build/`, `dist/`, `out/`, `bin/`, `obj/` — build outputs
- `reports/`, `serenity-reports/`, `allure-results/` — generated reports
- `node_modules/`, `.venv/`, `venv/`, `__pycache__/` — dependencies/cache
- `.git/`, `.idea/`, `.vscode/`, `.settings/` — IDE/VCS configs (except CI/CD pipeline files)
- `drivers/`, `*.jar`, `*.class`, `*.exe`, `*.dll`, `*.so`, `*.dylib` — binaries
- `*.png`, `*.jpg`, `*.gif`, `*.pdf`, `*.zip` — media/archives

## FINAL OUTPUT

S7 writes to two targets:
1. **`logs/audit.log`** — structured execution log
2. **`reports/results_MM_DD_YY.json`** — the complete audit report matching `schemas/audit.schema.json`

## PARTIAL RE-RUN GUIDE

To re-run only a subset of prompts (e.g. after CI pipeline changes):

| Changed area | Re-run prompts | Pass previous outputs for |
|---|---|---|
| CI/CD pipeline files | S6 → S7 | S1, S2, S3, S4, S5 (unchanged) |
| Feature files / BDD | S5 → S7 | S1, S2, S3, S4, S6 (unchanged) |
| Page objects / step defs | S4 → S7 | S1, S2, S3, S5, S6 (unchanged) |
| Framework config, new repo | S1 → S2–S6 → S7 | None (full re-run) |

## SCHEMA SECTION OWNERSHIP

| Schema section | Owner prompt |
|---|---|
| `meta` | S7 (assembled from S1 context) |
| `executive_summary` | S7 |
| `scorecard` | S7 (scores from S2–S6, assembly by S7) |
| `findings` | S7 (merged + sorted from S2–S6) |
| `anti_patterns_found` | S7 (merged from S2–S4) |
| `coverage_insights` | S5 (test_types seeded by S1) |
| `test_management_integration` | S5 |
| `documentation_quality` | S5 |
| `quality_metrics` | S7 (merged from S2–S5) |
| `action_plan` | S7 |
| `analysis_metadata` | S7 (tool_usage summed from all prompts) |
| `appendix` | S1 (notable_configs updated by S6) |
