import { test, expect } from '@playwright/test';
import { attachExchange } from './helpers';

// REQ-19: BR-LOGIN-005 — the login endpoint shall handle malicious or
// malformed input safely. Endpoint: POST /rest/user/login.
//
// TWO GENUINE APPLICATION SECURITY FINDINGS were confirmed here by actually
// running these tests against the live app (not visible from reading the
// requirement text alone) — see the per-test comments and summary.md's Run
// Results. Both assertions are left exactly as the requirement describes
// (not weakened to match the vulnerable behavior), so the failures stay
// visible.

// TC-REQ-19.1
test('TC-REQ-19.1: HTML/JavaScript-like input in Email or Password does not execute as script and does not authenticate', async ({ request }, testInfo) => {
  const scriptEmail = '<script>alert(1)</script>'; // literal from test case

  const loginBody = { email: scriptEmail, password: 'anyPassword1' };
  const response = await request.post('/rest/user/login', { data: loginBody });
  const bodyText = await response.text();
  await attachExchange(testInfo, 'login with script-like email', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);

  // This app's failed-login response never echoes the submitted email back
  // into the response (fixed literal "Invalid email or password."), so
  // there is no reflected-input surface for the script to execute against
  // at the API layer — confirmed by inspecting the response text itself.
  expect(response.status(), `expected 401 rejection, got ${response.status()} - ${bodyText}`).toBe(401);
  expect(bodyText.includes('<script>'), `expected the script-like input not to be reflected back verbatim in the response, got ${bodyText}`).toBe(false);
});

// TC-REQ-19.2
test('TC-REQ-19.2: SQL-like syntax in Email or Password does not cause a database error or bypass authentication', async ({ request }, testInfo) => {
  const sqlInjectionEmail = "' OR 1=1--"; // literal from test case

  const loginBody = { email: sqlInjectionEmail, password: 'anyPassword1' };
  const response = await request.post('/rest/user/login', { data: loginBody });
  const bodyText = await response.text();
  await attachExchange(testInfo, 'login with SQL-like injection email', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);

  // GENUINE FINDING, confirmed by running this test: routes/login.ts builds
  // its account lookup as a raw interpolated SQL string
  // (`WHERE email = '${req.body.email}' AND password = '...'`, marked
  // vuln-code-snippet vuln-line in the codebase — an intentional OWASP
  // Juice Shop training vulnerability). Submitting `' OR 1=1--` as the email
  // returns 200 with a valid authentication token for the first user in the
  // table (the admin account), NOT the 401 rejection BR-LOGIN-005 requires.
  // This is a classic SQL-injection authentication bypass. The assertion
  // below is left as written (expecting rejection) rather than weakened —
  // it currently fails, and that failure is the intended, documented signal.
  expect(response.status(), `expected 401 rejection (BR-LOGIN-005: malicious input handled safely) — got ${response.status()} - ${bodyText} (known gap: raw-SQL email lookup in routes/login.ts allows an auth bypass via SQL injection)`).toBe(401);
});

// TC-REQ-19.3
test('TC-REQ-19.3: Malformed input does not produce an unhandled server error', async ({ request }, testInfo) => {
  const loginBody = { email: 'admin@juice-sh.op', password: { a: 1 } }; // [test data] password is an object, an invalid type

  const response = await request.post('/rest/user/login', { data: loginBody });
  const bodyText = await response.text();
  await attachExchange(testInfo, 'login with a malformed (non-string) password type', { method: 'POST', url: '/rest/user/login', body: loginBody }, response);

  // GENUINE FINDING, confirmed by running this test: a non-string password
  // crashes lib/insecurity.ts's hash() (`crypto.createHash(...).update(data)`
  // requires a string/Buffer/TypedArray) with an uncaught TypeError. Express's
  // default error handler then returns 500 with a full HTML error page that
  // includes the raw exception message AND a complete server-side stack
  // trace with absolute filesystem paths — directly violating both
  // BR-LOGIN-005 (safe handling) and LOGIN-011 (no stack traces/internal
  // details). The assertions below are left as written (expecting a
  // controlled 4xx with no stack trace) rather than weakened — they
  // currently fail, and that failure is the intended, documented signal.
  expect(response.status(), `expected a controlled 4xx (not an unhandled 5xx) for malformed input — got ${response.status()} - ${bodyText.slice(0, 200)} (known gap: non-string password crashes hash() with an uncaught TypeError, exposing a full stack trace)`).toBeLessThan(500);
  expect(bodyText.includes('at ') && bodyText.includes('.js:'), `expected no server-side stack trace in the error response, got a body that ${bodyText.includes('at ') ? 'DOES' : 'does not'} look like it contains one`).toBe(false);
});
