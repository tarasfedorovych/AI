#!/usr/bin/env python3
"""
json_to_html.py
Convert a test-audit JSON report into a standalone HTML report.

Usage:
  python json_to_html.py input.json output.html
"""
from __future__ import annotations
import json
import sys
import html

def esc(s):
    return html.escape("" if s is None else str(s))

def group_findings(findings):
    groups = {"critical": [], "high": [], "medium": [], "low": [], "info": []}
    for f in findings or []:
        sev = (f.get("severity") or "info").lower()
        if sev not in groups:
            sev = "info"
        groups[sev].append(f)
    for k in groups:
        groups[k].sort(key=lambda x: (x.get("area_id") or "", x.get("id") or ""))
    return groups

def render_list(items):
    if not items:
        return "<em>None</em>"
    return "<ul>" + "".join(f"<li>{esc(i)}</li>" for i in items) + "</ul>"

def render_evidence(evs):
    if not evs:
        return "<em>No evidence captured.</em>"
    parts = []
    for e in evs:
        # Support both new format (file_path, line_start, line_end) and old format (file, lines)
        fp = esc(e.get("file_path") or e.get("file", "unknown"))
        
        # Handle line numbers - support both new and old formats
        if "line_start" in e and "line_end" in e:
            ls = esc(e.get("line_start", "?"))
            le = esc(e.get("line_end", "?"))
        elif "lines" in e:
            # Old format like "L-multiple" or "L10-L20"
            lines_str = str(e.get("lines", "?"))
            ls = lines_str
            le = ""
        else:
            ls = "?"
            le = "?"
        
        # Format line range
        if le and le != ls:
            line_range = f"{ls}-{le}"
        else:
            line_range = str(ls)
            
        ctx = e.get("context")
        snippet = e.get("code_snippet") or e.get("snippet", "")
        header = f"<strong>{fp}:{line_range}</strong>" + (f" — {esc(ctx)}" if ctx else "")
        code = f"<pre><code>{esc(str(snippet).rstrip())}</code></pre>" if snippet else ""
        parts.append(f"<div class='evidence'>{header}{code}</div>")
    return "".join(parts)

def render_recommendation(rec):
    if not rec:
        return "<em>No recommendation provided.</em>"
    
    # Handle string recommendations (simple format)
    if isinstance(rec, str):
        return f"<p>{esc(rec)}</p>"
    
    # Handle dictionary recommendations (structured format)
    parts = []
    if rec.get("recommendation_summary"):
        parts.append(f"<p>{esc(rec['recommendation_summary'])}</p>")
    wtd = rec.get("what_to_do") or []
    if wtd:
        parts.append("<h5>What to do</h5>" + render_list(wtd))
    ex = rec.get("example_fix") or []
    if ex:
        parts.append("<h5>Example fix</h5>")
        for item in ex:
            lang = esc(item.get("language",""))
            code = item.get("code","")
            parts.append(f"<div><div class='lang'>{lang}</div><pre><code>{esc(str(code).rstrip())}</code></pre></div>")
    tr = rec.get("tradeoffs") or []
    if tr:
        parts.append("<h5>Tradeoffs</h5>" + render_list(tr))
    return "".join(parts) or "<em>No recommendation provided.</em>"

def main():
    if len(sys.argv) != 3:
        print("Usage: python json_to_html.py input.json output.html", file=sys.stderr)
        sys.exit(2)

    in_path, out_path = sys.argv[1], sys.argv[2]
    with open(in_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    meta = data.get("meta", {})
    target = meta.get("target", {})
    exec_sum = data.get("executive_summary", {})

    title = "Test Automation Audit Report"
    repo = target.get("repo","")
    ref_type = target.get("ref_type","")
    ref_id = target.get("ref_id","")
    generated_at = meta.get("generated_at","")
    tz = meta.get("timezone","")

    overall_score = exec_sum.get("overall_score", 0)
    risk_level = exec_sum.get("risk_level", "unknown")
    headline = exec_sum.get("headline", "")
    highlights = exec_sum.get("highlights", {}) or {}

    # Support both new format (scorecard.areas) and old format (scorecard as array)
    scorecard_data = data.get("scorecard", []) or []
    if isinstance(scorecard_data, dict):
        scorecard = scorecard_data.get("areas", [])
        # Use scorecard's overall_score if executive_summary doesn't have it
        if not overall_score and scorecard_data.get("overall_score"):
            overall_score = scorecard_data.get("overall_score", 0)
    else:
        scorecard = scorecard_data
    
    findings = data.get("findings", []) or []
    groups = group_findings(findings)

    anti = data.get("anti_patterns_found", []) or []
    cov = data.get("coverage_insights", {}) or {}
    tms = data.get("test_management_integration", {}) or {}
    docq = data.get("documentation_quality", {}) or {}
    action_plan = data.get("action_plan", []) or []

    css = """
    body { font-family: Arial, sans-serif; margin: 28px; line-height: 1.4; }
    h1 { margin-bottom: 4px; }
    .meta { color: #444; margin-bottom: 18px; }
    .pill { display:inline-block; padding:2px 8px; border-radius:999px; font-size:12px; border:1px solid #ccc; margin-left:6px; }
    .card { border: 1px solid #ddd; border-radius: 10px; padding: 14px; margin: 12px 0; }
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid #ddd; padding: 8px; vertical-align: top; }
    th { background: #f6f6f6; text-align: left; }
    pre { background: #f6f6f6; padding: 10px; border-radius: 8px; overflow-x: auto; }
    .sev-critical { border-left: 6px solid #b00020; }
    .sev-high { border-left: 6px solid #d35400; }
    .sev-medium { border-left: 6px solid #b58900; }
    .sev-low { border-left: 6px solid #2e86c1; }
    .sev-info { border-left: 6px solid #7f8c8d; }
    .lang { font-size: 12px; color: #666; margin: 6px 0 2px; }
    .section { margin-top: 26px; }
    """

    html_parts = []
    html_parts.append("<!doctype html><html><head><meta charset='utf-8'>")
    html_parts.append(f"<title>{esc(title)}</title>")
    html_parts.append(f"<style>{css}</style></head><body>")
    html_parts.append(f"<h1>{esc(title)}</h1>")
    html_parts.append("<div class='meta'>")
    target_line = f"{repo} {ref_type.upper()}-{ref_id}".strip()
    if target_line.strip():
        html_parts.append(f"<div><strong>Target:</strong> {esc(target_line)}</div>")
    if generated_at:
        tz_part = f" ({tz})" if tz else ""
        html_parts.append(f"<div><strong>Generated:</strong> {esc(generated_at + tz_part)}</div>")
    html_parts.append("</div>")

    html_parts.append("<div class='card'>")
    html_parts.append("<h2>Executive summary</h2>")
    html_parts.append(f"<div><strong>Overall score:</strong> {esc(overall_score)}/100</div>")
    html_parts.append(f"<div><strong>Risk level:</strong> {esc(risk_level)}</div>")
    if headline:
        html_parts.append(f"<div><strong>Headline:</strong> {esc(headline)}</div>")
    html_parts.append("<h3>Highlights</h3>")
    html_parts.append("<h4>Strengths</h4>" + render_list(highlights.get("strengths", [])))
    html_parts.append("<h4>Top risks</h4>" + render_list(highlights.get("top_risks", [])))
    html_parts.append("<h4>Quick wins</h4>" + render_list(highlights.get("quick_wins", [])))
    html_parts.append("</div>")

    html_parts.append("<div class='section'><h2>Scorecard</h2>")
    if scorecard:
        html_parts.append("<table><tr><th>Area</th><th>Score</th><th>Risk</th><th>Rationale</th></tr>")
        for s in scorecard:
            # Support both new format (area_name, area_id) and old format (category)
            area = s.get("area_name") or s.get("area_id") or s.get("category", "")
            rationale = (s.get("rationale") or "").replace("\n", " ")
            html_parts.append(
                "<tr>"
                f"<td>{esc(area)}</td>"
                f"<td>{esc(s.get('score',0))}</td>"
                f"<td>{esc(s.get('risk_level','unknown'))}</td>"
                f"<td>{esc(rationale)}</td>"
                "</tr>"
            )
        html_parts.append("</table>")
    else:
        html_parts.append("<em>No scorecard data.</em>")
    html_parts.append("</div>")

    html_parts.append("<div class='section'><h2>Findings</h2>")
    if not findings:
        html_parts.append("<em>No findings.</em>")
    else:
        for sev in ["critical","high","medium","low","info"]:
            items = groups.get(sev) or []
            if not items:
                continue
            html_parts.append(f"<h3>{sev.title()} ({len(items)})</h3>")
            for fnd in items:
                cls = f"card sev-{sev}"
                fid = esc(fnd.get("id","UNKNOWN"))
                ttl = esc(fnd.get("title",""))
                area = esc(fnd.get("area_id",""))
                cat = esc(fnd.get("category",""))
                risk = esc(fnd.get("risk_level","unknown"))
                effort = esc(fnd.get("effort","unknown"))
                effort_days = fnd.get("effort_days", None)
                conf = fnd.get("confidence", None)
                issue = fnd.get("issue","")
                impact = fnd.get("impact","")
                html_parts.append(f"<div class='{cls}'>")
                html_parts.append(f"<h4>{fid}: {ttl}</h4>")
                pills = (
                    f"<span class='pill'>Area: {area}</span>"
                    f"<span class='pill'>Category: {cat}</span>"
                    f"<span class='pill'>Risk: {risk}</span>"
                    f"<span class='pill'>Effort: {effort}</span>"
                )
                if isinstance(effort_days, (int,float)):
                    pills += f"<span class='pill'>~{esc(effort_days)} day(s)</span>"
                if conf is not None:
                    pills += f"<span class='pill'>Confidence: {esc(conf)}</span>"
                html_parts.append(f"<div>{pills}</div>")
                if issue:
                    html_parts.append(f"<h5>Issue</h5><p>{esc(issue)}</p>")
                if impact:
                    html_parts.append(f"<h5>Impact</h5><p>{esc(impact)}</p>")
                html_parts.append("<h5>Evidence</h5>" + render_evidence(fnd.get("evidence")))
                html_parts.append("<h5>Recommendation</h5>" + render_recommendation(fnd.get("recommendation")))
                html_parts.append("</div>")
    html_parts.append("</div>")

    html_parts.append("<div class='section'><h2>Anti-patterns found</h2>")
    if not anti:
        html_parts.append("<em>None detected.</em>")
    else:
        for ap in anti:
            html_parts.append("<div class='card'>")
            # Support both new format (name) and old format (pattern)
            ap_name = ap.get('name') or ap.get('pattern', 'Unknown')
            html_parts.append(f"<h3>{esc(ap_name)}</h3>")
            html_parts.append(f"<div><strong>Count:</strong> {esc(ap.get('count',0))} "
                              f"<span class='pill'>Severity: {esc(ap.get('severity','unknown'))}</span></div>")
            if ap.get("description"):
                html_parts.append(f"<p>{esc(ap['description'])}</p>")
            if ap.get("recommended_replacement"):
                html_parts.append(f"<p><strong>Recommended replacement:</strong> {esc(ap['recommended_replacement'])}</p>")
            # Also show examples if present (old format)
            if ap.get("examples"):
                examples = ap.get("examples", [])
                if examples:
                    html_parts.append("<p><strong>Examples:</strong></p><ul>")
                    for ex in examples:
                        html_parts.append(f"<li>{esc(ex)}</li>")
                    html_parts.append("</ul>")
            html_parts.append("</div>")
    html_parts.append("</div>")

    html_parts.append("<div class='section'><h2>Coverage insights</h2>")
    test_types = cov.get("test_types", []) or []
    if test_types:
        html_parts.append("<h3>Test types</h3>")
        html_parts.append("<table><tr><th>Type</th><th>Count</th><th>Notes</th></tr>")
        for t in test_types:
            # Support both count field and derived from present/maturity
            count = t.get('count')
            if count is None:
                # Old format - derive count info from present/maturity
                if t.get('present') == True or t.get('present') == 'true':
                    count = "Present"
                elif t.get('present') == False or t.get('present') == 'false':
                    count = "0"
                else:
                    count = str(t.get('present', '0'))
            notes = t.get('notes', '')
            # Add maturity info if present
            if t.get('maturity'):
                maturity = t.get('maturity')
                if notes:
                    notes = f"{notes} (Maturity: {maturity})"
                else:
                    notes = f"Maturity: {maturity}"
            html_parts.append(f"<tr><td>{esc(t.get('type',''))}</td><td>{esc(count)}</td><td>{esc(notes)}</td></tr>")
        html_parts.append("</table>")
    else:
        html_parts.append("<em>No test type info.</em>")

    gaps = cov.get("gaps", []) or []
    html_parts.append("<h3>Gaps</h3>")
    if not gaps:
        html_parts.append("<em>No gaps recorded.</em>")
    else:
        html_parts.append("<ul>")
        for g in gaps:
            # Support both new format (gap_id, description) and old format (gap, severity, suggested_approach)
            gap_id = g.get('gap_id') or 'GAP'
            gap_desc = g.get('description')
            if not gap_desc:
                # Old format
                gap_text = g.get('gap', '')
                suggested = g.get('suggested_approach', '')
                gap_desc = f"{gap_text}. Suggested: {suggested}" if suggested else gap_text
            html_parts.append(f"<li><strong>{esc(gap_id)}</strong> "
                              f"({esc(g.get('severity','unknown'))}): {esc(gap_desc)}</li>")
        html_parts.append("</ul>")
    html_parts.append("</div>")

    html_parts.append("<div class='section'><h2>Test management integration</h2>")
    html_parts.append(f"<div><strong>References present:</strong> {esc(tms.get('presence_of_reference_to_test_management_system','unknown'))}</div>") 
    systems = tms.get("systems_detected", []) or []
    if systems:
        html_parts.append(f"<div><strong>Systems detected:</strong> {esc(', '.join(systems))}</div>")
    refs = tms.get("references_detected", []) or []
    if refs:
        html_parts.append("<h3>References detected</h3><ul>")
        for r in refs:
            examples = ", ".join(r.get("examples", []) or [])
            html_parts.append(f"<li>{esc(r.get('system',''))} pattern <code>{esc(r.get('pattern',''))}</code> "
                              f"examples: {esc(examples)}</li>")
        html_parts.append("</ul>")
    html_parts.append("</div>")

    html_parts.append("<div class='section'><h2>Documentation quality</h2>")
    html_parts.append(f"<div><strong>How well documented:</strong> {esc(docq.get('how_well_documented','unknown'))}</div>")
    html_parts.append(f"<div><strong>Score:</strong> {esc(docq.get('score',0))}/100</div>")
    dgaps = docq.get("gaps", []) or []
    html_parts.append("<h3>Documentation gaps</h3>" + render_list(dgaps))
    drec = docq.get("recommendations", []) or []
    if drec:
        html_parts.append("<h3>Documentation recommendations</h3><ul>")
        for r in drec:
            if isinstance(r, str):
                html_parts.append(f"<li>{esc(r)}</li>")
            else:
                html_parts.append(f"<li><strong>{esc(r.get('title',''))}</strong> "
                                  f"(effort: {esc(r.get('effort','S'))}, days: {esc(r.get('effort_days','1'))})</li>")
        html_parts.append("</ul>")
    html_parts.append("</div>")

    html_parts.append("<div class='section'><h2>Action plan</h2>")
    if not action_plan:
        html_parts.append("<em>No action plan.</em>")
    else:
        for item in action_plan:
            html_parts.append("<div class='card'>")
            # Support both new format (priority, title) and old format (phase, timeframe)
            priority = item.get('priority')
            title = item.get('title')
            if priority is None:
                # Old format - use phase
                priority = item.get('phase', '?')
            if not title:
                # Old format - construct from phase/timeframe
                phase = item.get('phase', '')
                timeframe = item.get('timeframe', '')
                title = f"{phase} ({timeframe})" if timeframe else phase
                
            html_parts.append(f"<h3>P{esc(priority)}: {esc(title)}</h3>")
            
            goal = item.get("goal")
            expected_impact = item.get("expected_impact")
            
            if goal:
                html_parts.append(f"<div><strong>Goal:</strong> {esc(goal)}</div>")
            if expected_impact:
                html_parts.append(f"<div><strong>Expected impact:</strong> {esc(expected_impact)}</div>")
                
            # Handle both new format (tasks array) and old format (actions array)
            tasks = item.get("tasks") or item.get("actions", [])
            if tasks:
                html_parts.append("<h4>Tasks</h4><ul>")
                for t in tasks:
                    # Support both formats
                    task_id = t.get('task_id', '')
                    desc = t.get('description') or t.get('action', '')
                    owner = t.get('owner_role') or t.get('owner', '')
                    effort = t.get('effort_days') or t.get('effort', '?')
                    
                    task_line = ""
                    if task_id:
                        task_line += f"<code>{esc(task_id)}</code> "
                    task_line += f"{esc(desc)}"
                    if owner:
                        task_line += f" (owner: {esc(owner)}"
                        if effort:
                            task_line += f", days: {esc(effort)}"
                        task_line += ")"
                    elif effort:
                        task_line += f" (days: {esc(effort)})"
                        
                    html_parts.append(f"<li>{task_line}</li>")
                html_parts.append("</ul>")
            html_parts.append("</div>")
    html_parts.append("</div>")

    html_parts.append("<div class='section'><h2>Appendix</h2>")
    appendix = data.get("appendix", {})
    html_parts.append("<pre><code>" + esc(json.dumps(appendix, indent=2, ensure_ascii=False)) + "</code></pre>")
    html_parts.append("</div>")

    html_parts.append("</body></html>")

    with open(out_path, "w", encoding="utf-8") as f:
        f.write("".join(html_parts))

if __name__ == "__main__":
    main()
