# QAPR-0002 - Test Cases

Checklist: c:\src\!QA pipeline\QAPR-0002\checklist.md
Generated: 2026-09-04

---

## REQ-1: Preconditions: The application is available; the login page is accessible; a registered account exists for successful-login scenarios.

Applied techniques: Use Case

### TC-REQ-1.1: Login page is accessible to an unauthenticated visitor

**Precondition:** Application is available; user is not authenticated.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Navigate to the login page URL | — | Login page loads and is displayed |

---

## REQ-2a: Login Field — Email (required, must identify an eligible account).

> Structural field requirement — sufficiently verified by TC-REQ-3.1 (field visible/interactable) and TC-REQ-6.1 (accepts a value that authenticates). No additional dedicated test case is generated here to avoid duplication.

## REQ-2b: Login Field — Password (required, must match the account credential).

> Structural field requirement — sufficiently verified by TC-REQ-3.1 and TC-REQ-6.1. No additional dedicated test case is generated here to avoid duplication.

## REQ-2c: Login Field — Remember Me (if supported — uses configured persistent-session behavior).

Applied techniques: Use Case

### TC-REQ-2c.1: Remember Me control is present and can be toggled

**Precondition:** Login page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Locate the Remember Me control | — | Control is visible on the login form |
| 2 | Toggle the control on, then off | — | Control reflects the checked/unchecked state after each toggle |

---

## REQ-3: LOGIN-001: The system shall allow unauthenticated users to access the login form.

Applied techniques: Use Case

### TC-REQ-3.1: Unauthenticated visitor can view and interact with the login fields

**Precondition:** Login page is open; user is not authenticated.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Verify Email field | — | Field is visible and accepts input |
| 2 | Verify Password field | — | Field is visible and accepts input |
| 3 | Verify submit control | — | Control is visible |

---

## REQ-4: LOGIN-002: The system shall require email and password.

Applied techniques: EP

### TC-REQ-4.1: Submitting with Email or Password left completely empty does not authenticate

**Precondition:** Login page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Leave Email empty, fill Password with a value, submit | password=Val1dPassw0rd! [test data] | Login does not succeed; a validation error is displayed or submission is prevented for the missing Email |
| 2 | Fill Email with a value, leave Password empty, submit | email=registered.user@example.com [test data] | Login does not succeed; a validation error is displayed or submission is prevented for the missing Password |

### TC-REQ-4.2: Submitting with a mandatory field containing only whitespace is treated as empty

**Precondition:** Login page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a whitespace-only value in the Email field, fill Password with a value, submit | "   " [test data, 3 spaces] | Login does not succeed as if a real Email value were provided (whitespace-only value is treated as empty or as a non-matching value, not as valid input) |

---

## REQ-5: LOGIN-003: The password field shall obscure its value by default.

Applied techniques: Use Case

### TC-REQ-5.1: Password field masks its entered value by default

**Precondition:** Login page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter a value into the Password field | Str0ngP@ssw0rd! [test data] | The entered characters are rendered obscured (masked), not as plain text, by default |

---

## REQ-6: LOGIN-004: The system shall authenticate a user when valid credentials for an eligible account are provided.

Applied techniques: Use Case

### TC-REQ-6.1: Valid credentials for an existing account authenticate successfully

**Precondition:** A registered account exists with email "registered.user@example.com" and password "Val1dPassw0rd!" [test data].

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter the account's email and password, submit | registered.user@example.com / Val1dPassw0rd! [test data] | Authentication succeeds |

---

## REQ-7: LOGIN-005: The system shall reject an unknown email or incorrect password.

Applied techniques: EP

### TC-REQ-7.1: Submitting an email that does not match any existing account is rejected

**Precondition:** Login page is open; the submitted email is not registered.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter an unregistered email and any password, submit | unknown.user@example.com / anyPassword1 [test data] | Login is rejected |

### TC-REQ-7.2: Submitting a correct/existing email with an incorrect password is rejected

**Precondition:** An account already exists with email "registered.user@example.com" [test data].

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Enter the existing email with an incorrect password, submit | registered.user@example.com / WrongPassw0rd! [test data] | Login is rejected |

---

## REQ-8: LOGIN-006: Failed authentication shall not create an authenticated session.

Applied techniques: Use Case

### TC-REQ-8.1: A rejected login attempt does not establish an authenticated session

**Precondition:** A login attempt was just rejected (e.g. TC-REQ-7.1 or TC-REQ-7.2).

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Request authenticated-only data/functionality using whatever session state resulted from the rejected attempt | — | Request is not granted as authenticated; no valid session exists from the rejected attempt |

---

## REQ-9: LOGIN-007: Successful authentication shall establish a session associated with the correct user.

Applied techniques: Use Case

### TC-REQ-9.1: The session established after login identifies the same account that authenticated

**Precondition:** A successful login has just occurred (TC-REQ-6.1).

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Inspect the identity associated with the established session | — | Session identifies the same account whose credentials were submitted, not a different or generic account |

---

## REQ-10: LOGIN-008: The authenticated state shall persist while the session remains valid.

Applied techniques: Use Case

### TC-REQ-10.1: Authenticated state persists across subsequent navigation/requests while the session is valid

**Precondition:** A successful login has just occurred.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Navigate within the application / issue a subsequent authenticated request, without the session expiring or being invalidated | — | User remains authenticated |

---

## REQ-11: LOGIN-009: Expired or invalid sessions/tokens shall not provide authenticated access.

Applied techniques: EP

### TC-REQ-11.1: A malformed session/token value does not grant authenticated access

**Precondition:** Application is available.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Present a malformed (not a valid token structure) session/token value when requesting authenticated-only data | not-a-real-token [test data] | Access is not granted; the request is treated as unauthenticated |

### TC-REQ-11.2: A tampered session/token value does not grant authenticated access

**Precondition:** A valid session/token was just issued by a successful login.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Alter one character of the valid session/token value, then present it when requesting authenticated-only data | [test data — valid token with last character changed] | Access is not granted; the request is treated as unauthenticated |

---

## REQ-12: LOGIN-010: After successful login, the user shall be navigated according to the configured product flow.

Applied techniques: Use Case

### TC-REQ-12.1: Successful login navigates the user away from the login form

**Precondition:** Login page is open; valid credentials prepared.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the login form with valid credentials | [test data] | User is navigated away from the login form to the application's configured post-login destination |

---

## REQ-13: LOGIN-011: Failed login shall display an appropriate error without exposing sensitive internal details.

Applied techniques: EP

### TC-REQ-13.1: A failed login attempt displays an appropriate error message

**Precondition:** Login page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the login form with incorrect credentials | unknown.user@example.com / anyPassword1 [test data] | An appropriate error message is displayed to the user |

### TC-REQ-13.2: A failed-login error contains no stack trace, raw database error, or internal identifier

**Precondition:** Login page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the login form with incorrect credentials, then inspect the displayed/returned error content | unknown.user@example.com / anyPassword1 [test data] | Error content contains no stack trace, no raw database error text, and no internal identifier |

---

## REQ-14: LOGIN-012: Authentication shall be performed by a trusted server-side mechanism.

Applied techniques: Use Case

### TC-REQ-14.1: A login request bypassing client-side logic with invalid credentials is still rejected server-side

**Precondition:** Application is available.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Send a login request directly to the server-side login endpoint, bypassing the UI/client-side logic, with invalid credentials | unknown.user@example.com / anyPassword1 [test data/mechanism] | Server rejects the request; no session is established |

---

## REQ-15: BR-LOGIN-001: Only valid credentials for an eligible account may establish an authenticated session.

> This requirement restates the same authentication-gate rule already verified under REQ-6/REQ-7/REQ-8 (see TC-REQ-6.1, TC-REQ-7.1, TC-REQ-7.2, TC-REQ-8.1). No additional test cases are generated here to avoid duplication.

---

## REQ-16: BR-LOGIN-002: Passwords shall never be stored or logged in plaintext; they are hashed at rest, never written to logs, and never returned in any API response or error output.

Applied techniques: Use Case

### TC-REQ-16.1: The submitted Password value is not returned in any login API response, including error responses

**Precondition:** Application is available.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit a login request (both a successful one and one that fails) using a known Password value, then inspect the response bodies | Val1dPassw0rd! [test data] | The password value is not present in any response, including error responses |

### TC-REQ-16.2: The issued session/token does not contain the plaintext Password value

**Precondition:** A successful login has just occurred using a known Password value.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Inspect the content of the issued session/token | Val1dPassw0rd! [test data] | The plaintext password value does not appear anywhere in the token's content |

---

## REQ-17: BR-LOGIN-003: Credentials shall be transmitted securely in non-development environments.

Applied techniques: Use Case

### TC-REQ-17.1: Login data, including Password, is transmitted over a secure connection

**Precondition:** Login page is open in the QA environment under test; network traffic capture is available.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the login form while capturing network traffic (e.g. browser dev tools / proxy) | [test data] | The login request, including the Password field, is transmitted over an HTTPS/TLS connection |

---

## REQ-18: BR-LOGIN-004: Authentication errors should not unnecessarily reveal whether a specific account exists.

Applied techniques: Decision Table

### TC-REQ-18.1: The error for an unknown email is indistinguishable from the error for a correct email with an incorrect password

**Precondition:** An account already exists with email "registered.user@example.com" [test data].

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit login with an unregistered email and any password | unknown.user@example.com / anyPassword1 [test data] | A generic authentication-failure error is displayed/returned |
| 2 | Submit login with the existing email and an incorrect password | registered.user@example.com / WrongPassw0rd! [test data] | The same generic authentication-failure error is displayed/returned — indistinguishable from step 1's, not revealing that this email exists |

---

## REQ-19: BR-LOGIN-005: The login endpoint shall handle malicious or malformed input safely.

Applied techniques: EP

### TC-REQ-19.1: HTML/JavaScript-like input in Email or Password does not execute as script and does not authenticate

**Precondition:** Login page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit login with HTML/script-like input in the Email field and any password | `<script>alert(1)</script>` / anyPassword1 [test data] | Login is rejected; the script does not execute; no session is established |

### TC-REQ-19.2: SQL-like syntax in Email or Password does not cause a database error or bypass authentication

**Precondition:** Login page is open; at least one account exists in the system.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit login with SQL-like syntax in the Email field designed to always evaluate true, and any password | `' OR 1=1--` / anyPassword1 [test data] | Login is rejected; no database error occurs; authentication is not bypassed by the injected syntax |

### TC-REQ-19.3: Malformed input does not produce an unhandled server error

**Precondition:** Application is available.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit a login request with a malformed body (e.g. missing/incorrectly-typed fields) directly to the server | [test data/mechanism — e.g. `{}` or non-string field values] | Server responds with a controlled error (e.g. 400/401); no unhandled server error (5xx) occurs |

---

## REQ-20: BR-LOGIN-006: Authentication tokens or session identifiers shall not contain passwords or be exposed in URLs.

> TC-REQ-16.2 already verifies that the issued token does not contain the plaintext password value. No additional test case is generated for that half of this requirement, to avoid duplication.

Applied techniques: Use Case

### TC-REQ-20.2: The session/token is not required as a URL query-string parameter for a normal authenticated request

**Precondition:** A valid session/token was just issued by a successful login.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Request authenticated-only data/functionality using the standard mechanism (e.g. header/cookie), without placing the token in the URL | — | Request succeeds without the token appearing as a URL query-string parameter |

---

## REQ-21: Important Edge Cases (for grooming/test design coverage): empty email; empty password; unknown email; correct email with incorrect password; email with different letter case; leading/trailing whitespace in email; leading/trailing whitespace in password; very long input; Unicode and special-character input; HTML/JavaScript-like or SQL-like input; rapid repeated login attempts; network or authentication-service failure; page refresh immediately after login; expired, malformed, or tampered session/token.

Applied techniques: EP, BVA

### TC-REQ-21.1: Login with the registered email in a different letter case authenticates the same as the original case

**Precondition:** An account already exists with email "registered.user@example.com" [test data].

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit login with the registered email in all-uppercase, with the correct password | REGISTERED.USER@EXAMPLE.COM / Val1dPassw0rd! [test data] | Authentication succeeds, same as with the original letter case |

### TC-REQ-21.2: Login with the registered email padded with leading/trailing whitespace is handled consistently

**Precondition:** An account already exists with email "registered.user@example.com" [test data].

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit login with the registered email padded with leading/trailing whitespace, with the correct password | "  registered.user@example.com  " / Val1dPassw0rd! [test data] | Outcome is consistent and controlled — either authenticated (if trimmed) or rejected the same generic way as an unknown email; no crash or unhandled error either way |

### TC-REQ-21.3: Very long input in Email or Password does not cause a crash or unhandled server error

**Precondition:** Login page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit login with a very long value in the Email field and a normal password | [test data, e.g. 10,000-character string] / anyPassword1 | Login is rejected in a controlled way; no crash or unhandled server error (5xx) occurs |

### TC-REQ-21.4: Unicode/special-character input in Email or Password does not cause a crash and is rejected generically

**Precondition:** Login page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit login with Unicode/special-character input in the Email field and any password | Пошта@example.com / anyPassword1 [test data] | Login is rejected the same generic way as any other non-matching credential; no crash or unhandled server error occurs |

### TC-REQ-21.5: Repeated rapid login attempts with incorrect credentials do not cause a crash or unhandled server error

**Precondition:** Login page is open / server is available.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit multiple login requests in rapid succession, all with incorrect credentials | unknown.user@example.com / anyPassword1 [test data] | Each attempt is rejected in a controlled way; no crash or unhandled server error occurs across the repeated attempts |

### TC-REQ-21.6: Refreshing the page immediately after a successful login preserves the authenticated state

**Precondition:** A successful login has just occurred.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Refresh the page immediately after the successful login | — | The user remains authenticated after the refresh |

---

## REQ-22: AC-LOGIN-001 (Successful Login): Given an eligible registered customer exists, when the customer submits the correct email and password, then authentication succeeds and a valid session is established for the correct customer.

Applied techniques: Use Case

### TC-REQ-22.1: End-to-end successful login authenticates and establishes a session for the correct customer

**Precondition:** An eligible registered customer exists.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the login form with the customer's correct email and password | [test data] | Authentication succeeds |
| 2 | Inspect the resulting session | — | A valid session is established, identifying the correct customer |

---

## REQ-23: AC-LOGIN-002 (Invalid Credentials): Given the submitted credentials are incorrect, when login is attempted, then authentication fails, no authenticated session is created, and an appropriate error is displayed.

Applied techniques: Use Case

### TC-REQ-23.1: Incorrect credentials fail login, create no session, and display an appropriate error

**Precondition:** Login page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the login form with incorrect credentials | unknown.user@example.com / anyPassword1 [test data] | Authentication fails; no authenticated session is created; an appropriate error is displayed |

---

## REQ-24: AC-LOGIN-003 (Missing Credentials): Given email or password is missing, when login is submitted, then authentication does not succeed and an appropriate validation error is displayed.

Applied techniques: Use Case

### TC-REQ-24.1: Missing email or password prevents successful login and shows a validation error

**Precondition:** Login page is open.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit the login form with Email or Password missing | [test data] | Authentication does not succeed; an appropriate validation error is displayed |

---

## REQ-25: AC-LOGIN-004 (Session Persistence): Given the customer successfully logged in, when the customer navigates within the application while the session is valid, then the customer remains authenticated.

Applied techniques: Use Case

### TC-REQ-25.1: Customer remains authenticated while navigating with a valid session

**Precondition:** Customer has successfully logged in.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Navigate within the application while the session remains valid | — | Customer remains authenticated |

---

## REQ-26: AC-LOGIN-005 (Expired Session): Given the customer's session has expired, when authenticated functionality is requested, then authenticated access is rejected and the application follows the configured re-authentication behavior.

Applied techniques: Use Case

### TC-REQ-26.1: Expired/invalid session rejects authenticated access and triggers the re-authentication flow

**Precondition:** The customer's session has expired, or is otherwise invalid/tampered (practical stand-in for time-based expiry — see REQ-11 assumption).

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Request authenticated functionality using the expired/invalid session | — | Authenticated access is rejected |
| 2 | Observe the application's response to the rejection | — | The application follows its configured re-authentication behavior (e.g. returns the user to the login form) |

---

## REQ-27: AC-LOGIN-006 (Backend Failure): Given authentication cannot be completed because of a backend failure, when login is attempted, then a controlled error is shown and the user remains unauthenticated.

Applied techniques: Use Case

### TC-REQ-27.1: Backend failure during login produces a controlled error, not a raw system error

**Precondition:** Login page is open; valid or invalid credentials prepared; a backend failure is forced [test data/environment fault-injection mechanism].

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Submit login while the backend authentication mechanism is forced to fail | [test data] | A controlled error message is shown; no raw system or server error (e.g. stack trace, default server error page) is displayed |

### TC-REQ-27.2: The user remains unauthenticated after a backend failure during login

**Precondition:** The backend failure scenario from TC-REQ-27.1 has just occurred.

| # | Step | Test Data | Expected Result |
|---|------|-----------|------------------|
| 1 | Inspect the user's authentication state after the failed attempt | — | User remains unauthenticated; no session was established |

---

## Statistics

- Requirements covered: 29 (26 with dedicated test cases; 2 structural requirements — REQ-2a, REQ-2b — sufficiently verified by TC-REQ-3.1/TC-REQ-6.1 alone, no dedicated test case needed; 1 duplicate business rule — REQ-15 — covered by REQ-6/REQ-7/REQ-8, see cross-reference note; REQ-20 partially cross-referenced to TC-REQ-16.2)
- Requirements needing clarification: 0
- Total number of test cases: 39
