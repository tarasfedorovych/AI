import { test, expect } from '@playwright/test';
import { attachExchange, uniqueEmail } from './helpers';

// REQ-18: BR-LOGIN-004 — authentication errors should not unnecessarily
// reveal whether a specific account exists. Verified by comparing the
// response for an unknown email against the response for a known email
// with a wrong password — routes/login.ts uses a single else-branch for
// both outcomes (confirmed in the codebase).

const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data]
const WRONG_PASSWORD = 'WrongPassw0rd!'; // [test data]

// TC-REQ-18.1
test('TC-REQ-18.1: The error for an unknown email is indistinguishable from the error for a correct email with an incorrect password', async ({ request }, testInfo) => {
  const existingEmail = uniqueEmail('disclosure-existing');
  const unknownEmail = uniqueEmail('disclosure-unknown');

  // Arrange — precondition: an account already exists with existingEmail
  const registerBody = { email: existingEmail, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD };
  const registerResponse = await request.post('/api/Users', { data: registerBody });
  const registerRespBody = await attachExchange(testInfo, 'arrange: register existing account', { method: 'POST', url: '/api/Users', body: registerBody }, registerResponse);
  expect(registerResponse.status(), `expected 201 Created, got ${registerResponse.status()} - ${JSON.stringify(registerRespBody)}`).toBe(201);

  // Act (step 1) — submit login with an unregistered email
  const unknownLoginBody = { email: unknownEmail, password: 'anyPassword1' };
  const unknownResponse = await request.post('/rest/user/login', { data: unknownLoginBody });
  const unknownBodyText = await unknownResponse.text();
  await attachExchange(testInfo, 'login with unknown email', { method: 'POST', url: '/rest/user/login', body: unknownLoginBody }, unknownResponse);
  expect(unknownResponse.status(), `expected 401 for the unknown email, got ${unknownResponse.status()} - ${unknownBodyText}`).toBe(401);

  // Act (step 2) — submit login with the existing email and an incorrect password
  const wrongPasswordLoginBody = { email: existingEmail, password: WRONG_PASSWORD };
  const wrongPasswordResponse = await request.post('/rest/user/login', { data: wrongPasswordLoginBody });
  const wrongPasswordBodyText = await wrongPasswordResponse.text();
  await attachExchange(testInfo, 'login with existing email, wrong password', { method: 'POST', url: '/rest/user/login', body: wrongPasswordLoginBody }, wrongPasswordResponse);
  expect(wrongPasswordResponse.status(), `expected 401 for the wrong password, got ${wrongPasswordResponse.status()} - ${wrongPasswordBodyText}`).toBe(401);

  // Assert — same status and same generic body for both cases; no account-existence disclosure
  expect(wrongPasswordResponse.status(), 'expected both failure responses to share the same status code').toBe(unknownResponse.status());
  expect(
    wrongPasswordBodyText,
    `expected the same generic error text for both cases (unknown-email: "${unknownBodyText}", wrong-password: "${wrongPasswordBodyText}")`
  ).toBe(unknownBodyText);
});
