import { test, expect, type APIRequestContext, type APIResponse } from '@playwright/test';
import { attachExchange } from './helpers';

// REQ-6: REG-004 — no two accounts may share the same normalized email
// (trim + lowercase). Enforced at persistence level (Users.email has a
// Sequelize `unique: true` constraint — models/user.ts), not only by a
// pre-check. Endpoint: POST /api/Users (swagger.yml: UserRegistration).
// Expected results only state rejection / success without a specific
// status code, so assertions use response.ok() per convention.
//
// The base emails below are marked [test data] in test-cases.md (not
// fixed literal values from the requirement), so each test uses its
// own unique base email rather than a single shared literal — Playwright
// runs spec files in parallel by default, and TC-REQ-6.1/6.2/6.3 sharing
// one hardcoded email caused a real race between workers (confirmed by
// running the suite: two of the three failed with "Cannot read
// properties of undefined (reading 'id')" because another worker's
// concurrent registration of the same email won the race first).
//
// Discovery note, also confirmed by actually running this suite against
// the live app: models/user.ts's email field is `unique: true` with no
// lowercase/normalization transform — only server.ts's registration
// handler trims whitespace. So TC-REQ-6.2 (whitespace) is correctly
// rejected (trim then duplicate), but TC-REQ-6.3 (case variant) is NOT
// rejected by the current implementation — it creates a second, distinct
// account. This is a genuine requirement/implementation gap (REQ-6/REQ-15
// call for case-insensitive uniqueness), not a test bug — left as a
// legitimately failing assertion so it stays visible. Cleanup below
// accounts for this: cleanupIfCreated is called on every response,
// whether or not that response was expected to create an account.

const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data] valid mandatory data

async function registerAccount(request: APIRequestContext, email: string) {
  const body = { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD };
  const response = await request.post('/api/Users', { data: body });
  return { response, requestInfo: { method: 'POST', url: '/api/Users', body } };
}

// Best-effort cleanup for a response that may or may not have created an
// account. Never throws — must run safely from a `finally` block even
// when the response body is unexpected.
async function cleanupIfCreated(request: APIRequestContext, response: APIResponse) {
  if (!response.ok()) return;
  try {
    const body = await response.json();
    const userId = body?.data?.id;
    if (userId) {
      await request.delete(`/api/Users/${userId}`);
    }
  } catch {
    // Response wasn't the expected shape — nothing to clean up.
  }
}

// TC-REQ-6.1
test('TC-REQ-6.1: Registering with an email identical to an existing account\'s email is rejected', async ({ request }, testInfo) => {
  const baseEmail = `uniqueness-identical-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per test run

  // Arrange — precondition: an account already exists with this email
  const arrange = await registerAccount(request, baseEmail);
  const arrangeBody = await attachExchange(testInfo, 'arrange: register existing account', arrange.requestInfo, arrange.response);
  expect(arrange.response.status(), `expected 201 Created for the arrange-step registration, got ${arrange.response.status()} - ${JSON.stringify(arrangeBody)}`).toBe(201);

  // Act — register a new account using the same email
  const act = await registerAccount(request, baseEmail);
  const actBody = await attachExchange(testInfo, 'act: duplicate registration with identical email', act.requestInfo, act.response);
  try {
    // Assert — registration is rejected; no new account is created for this submission
    expect(act.response.ok(), `expected duplicate registration to be rejected, got ${act.response.status()} - ${JSON.stringify(actBody)}`).toBeFalsy();
  } finally {
    // Cleanup — remove whatever was created, whether or not the assertion above passed
    await cleanupIfCreated(request, act.response);
    await cleanupIfCreated(request, arrange.response);
  }
});

// TC-REQ-6.2
test('TC-REQ-6.2: Registering with an email differing only by leading/trailing whitespace from an existing account\'s email is rejected', async ({ request }, testInfo) => {
  const baseEmail = `uniqueness-whitespace-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per test run
  const baseEmailWithWhitespace = `  ${baseEmail}  `;

  // Arrange — precondition: an account already exists with the (trimmed) existing email
  const arrange = await registerAccount(request, baseEmail);
  const arrangeBody = await attachExchange(testInfo, 'arrange: register existing account', arrange.requestInfo, arrange.response);
  expect(arrange.response.status(), `expected 201 Created for the arrange-step registration, got ${arrange.response.status()} - ${JSON.stringify(arrangeBody)}`).toBe(201);

  // Act — register using the existing email with added leading/trailing whitespace
  const act = await registerAccount(request, baseEmailWithWhitespace);
  const actBody = await attachExchange(testInfo, 'act: registration with whitespace-padded duplicate email', act.requestInfo, act.response);
  try {
    // Assert — registration is rejected; no new account is created for this submission
    expect(act.response.ok(), `expected whitespace-padded duplicate email to be rejected (after trim), got ${act.response.status()} - ${JSON.stringify(actBody)}`).toBeFalsy();
  } finally {
    await cleanupIfCreated(request, act.response);
    await cleanupIfCreated(request, arrange.response);
  }
});

// TC-REQ-6.3
test('TC-REQ-6.3: Registering with an email differing only by letter case from an existing account\'s email is rejected', async ({ request }, testInfo) => {
  const baseEmail = `uniqueness-case-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per test run
  const baseEmailDifferentCase = baseEmail.toUpperCase();

  // Arrange — precondition: an account already exists with the existing email
  const arrange = await registerAccount(request, baseEmail);
  const arrangeBody = await attachExchange(testInfo, 'arrange: register existing account', arrange.requestInfo, arrange.response);
  expect(arrange.response.status(), `expected 201 Created for the arrange-step registration, got ${arrange.response.status()} - ${JSON.stringify(arrangeBody)}`).toBe(201);

  // Act — register using the existing email with different letter case
  const act = await registerAccount(request, baseEmailDifferentCase);
  const actBody = await attachExchange(testInfo, 'act: registration with different-case duplicate email', act.requestInfo, act.response);
  try {
    // Assert — registration is rejected; no new account is created for this submission
    // NOTE: as of this codebase, this currently fails — the real implementation has no
    // case-normalization on the email uniqueness check (see Discovery note above).
    expect(act.response.ok(), `expected different-case duplicate email to be rejected, got ${act.response.status()} - ${JSON.stringify(actBody)} (known gap: no case normalization in models/user.ts)`).toBeFalsy();
  } finally {
    await cleanupIfCreated(request, act.response);
    await cleanupIfCreated(request, arrange.response);
  }
});

// TC-REQ-6.4
test('TC-REQ-6.4: Concurrent registration submissions for the same normalized email — exactly one succeeds', async ({ request }, testInfo) => {
  const raceEmail = `uniqueness-race-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per test run

  // Arrange — precondition: no account currently exists with this email (fresh run,
  // guaranteed by the unique email above rather than a fixed literal)

  // Act — submit two registration requests concurrently with the same normalized email
  const [a, b] = await Promise.all([registerAccount(request, raceEmail), registerAccount(request, raceEmail)]);
  const [aBody, bBody] = await Promise.all([
    attachExchange(testInfo, 'submitA: concurrent registration', a.requestInfo, a.response),
    attachExchange(testInfo, 'submitB: concurrent registration', b.requestInfo, b.response),
  ]);

  try {
    // Assert — exactly one submission succeeds and creates one account; the other receives
    // the generic registration failure message (REQ-14)
    const successCount = [a.response, b.response].filter((r) => r.ok()).length;
    expect(successCount, `expected exactly one concurrent submission to succeed, got submitA=${a.response.status()} ${JSON.stringify(aBody)}, submitB=${b.response.status()} ${JSON.stringify(bBody)}`).toBe(1);
  } finally {
    await cleanupIfCreated(request, a.response);
    await cleanupIfCreated(request, b.response);
  }
});
