# Конвенції генерації Playwright для UI — довідка

## Фреймворк

Використовуй браузерні фікстури Playwright Test:

```ts
import { test, expect } from '@playwright/test';
```

Взаємодії та перевірки йдуть через методи Page Object, а не напряму
через `page` всередині spec-файлу (див. Page Object Model нижче).

## Іменування файлів та групування

- Один файл `.spec.ts` на групу вимог (заголовок REQ у файлі
  тест-кейсів), а не на TC-REQ пункт. Назви файл за
  сторінкою/фічею, яку покриває група REQ, у kebab-case, наприклад
  `registration-page-access.spec.ts`,
  `mandatory-field-validation.spec.ts`.
- Якщо група REQ має лише один UI-класифікований TC-REQ пункт, вона
  все одно отримує свій власний файл — не обʼєднуй непов'язані
  групи REQ в один "misc" чи "other" файл, оскільки це ламає
  трасованість 1:1 від назви файлу до вимоги.
- Розміщуй spec-файли безпосередньо в `<ISSUEKEY>/ui-tests/` (або в
  підпапці `tests/` цієї папки, якщо виявлена конвенція існуючої
  кодової бази використовує таку — відповідай знайденому, але
  ніколи не пиши поза межами `<ISSUEKEY>/ui-tests/`).
- Page Object ніколи не розміщуються під `<ISSUEKEY>/`. Вони живуть
  у спільній папці `ui-framework/pages/` в корені робочої
  директорії, один файл на сторінку/головний компонент, названий за
  сторінкою у PascalCase, наприклад `RegistrationPage.ts`,
  `LoginPage.ts`.

## Page Object Model

### Чому спільний та повторно використовуваний, а не регенерований

На відміну від API-тестів (самодостатніх для кожної задачі),
цінність шару UI POM походить з повторного використання: та сама
сторінка логіну, навігація та компоненти форми задіюються
тест-кейсами з багатьох різних задач проти того самого застосунку.
Регенерація Page Object для кожної задачі мовчки б розходилась і
дублювала роботу. Спільна папка `ui-framework/pages/` — це єдине
місце, куди цьому скілу дозволено писати поза власною папкою виводу
поточної задачі.

### Правило повторного використання

Перед написанням нового файлу Page Object перевір `ui-framework/pages/`
на наявність класу, що відповідає цільовій сторінці (за
назвою файлу/класу, або за коментарем `// Page:`, що називає
URL/маршрут, який він покриває). Якщо знайдено:
- Повторно використай його як є для локаторів/методів, які він вже
  має.
- Додай будь-який новий локатор чи метод, якого потребують поточні
  тест-кейси, додавши його до класу — ніколи не видаляй, не
  перейменовуй і не змінюй поведінку існуючого методу; spec-файли
  інших задач можуть вже викликати його.
Якщо не знайдено, створи новий файл.

### Форма

```ts
// Page: /#/register — форма реєстрації користувача (Juice Shop)
import type { Page, Locator } from '@playwright/test';

export class RegistrationPage {
  readonly page: Page;
  readonly emailInput: Locator;
  readonly passwordInput: Locator;
  readonly repeatPasswordInput: Locator;
  readonly securityQuestionSelect: Locator;
  readonly securityAnswerInput: Locator;
  readonly submitButton: Locator;
  readonly errorMessage: Locator;

  constructor(page: Page) {
    this.page = page;
    this.emailInput = page.getByLabel('Email');
    this.passwordInput = page.getByLabel('Password', { exact: true });
    this.repeatPasswordInput = page.getByLabel('Repeat Password');
    this.securityQuestionSelect = page.getByLabel('Security Question');
    this.securityAnswerInput = page.getByLabel('Answer');
    this.submitButton = page.getByRole('button', { name: 'Register' });
    this.errorMessage = page.getByRole('alert');
  }

  async goto() {
    await this.page.goto('/#/register');
  }

  async isFormVisible(): Promise<boolean> {
    return this.emailInput.isVisible();
  }

  async fillMandatoryFields(data: { email: string; password: string }) {
    await this.emailInput.fill(data.email);
    await this.passwordInput.fill(data.password);
    await this.repeatPasswordInput.fill(data.password);
  }

  async submit() {
    await this.submitButton.click();
  }
}
```

**Чому `import type`, а не звичайний `import`:** цей файл не має
жодної runtime-залежності від того, де саме встановлено
`@playwright/test`. Назви `Page`/`Locator` повністю видаляються під
час компіляції (esbuild-трансформація Playwright Test прибирає
`import type`), тому цей спільний файл імпортується чисто незалежно
від того, чий власний `package.json`/`node_modules` папки задачі
зрештою запускає spec, що його конструює. **Ніколи** не імпортуй
`test` чи `expect` (чи будь-який інший runtime-експорт) з
`@playwright/test` всередині файлу Page Object — Node резолвить
runtime-імпорт відносно *директорії файлу, що імпортує*, йдучи
вгору; файл, що живе у спільній кореневій папці `ui-framework/pages/`,
ніколи б не дістався вгору до `<ISSUEKEY>/ui-tests/node_modules/`,
коли там заготовлений самодостатній `package.json`, тому runtime-імпорт
`@playwright/test` з Page Object може провалитись залежно від того,
чиє встановлення задачі опиниться поряд. Тримання імпорту
тільки-типовим повністю уникає цього, оскільки він видаляється до
того, як хтось намагається його резолвити.

Це також причина, чому **перевірки лишаються поза Page Object** —
не лише обхідний шлях резолву, а стандартна межа POM: Page Object
виставляє локатори та виконує дії/читання стану; spec-файл (який
завжди має доступний `expect`, оскільки саме цей файл фактично
запускає `@playwright/test`) робить перевірку. Методи представляють
дії користувача та читання стану доменною мовою
(`fillMandatoryFields`, `submit`, `isFormVisible`) — не тонку
обгортку, що просто перейменовує `.click()`, але ніколи не викликає
`expect()`.

### Spec-файл, що імпортує Page Object

```ts
// TC-REQ-1.1
import { test, expect } from '@playwright/test';
import { RegistrationPage } from '../../ui-framework/pages/RegistrationPage';

test('TC-REQ-1.1: Registration page is accessible to an unauthenticated visitor', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);

  await test.step('Перейти на сторінку реєстрації', async () => {
    await registrationPage.goto();
  });

  await test.step('Перевірити, що форма реєстрації відображається', async () => {
    expect(
      await registrationPage.isFormVisible(),
      'очікували, що форма реєстрації буде видима для неавтентифікованого відвідувача'
    ).toBe(true);
  });
});
```

```ts
// TC-REQ-4.1
import { test, expect } from '@playwright/test';
import { RegistrationPage } from '../../ui-framework/pages/RegistrationPage';

const VALID_PASSWORD = 'Str0ngP@ssw0rd!'; // [test data] valid mandatory data

test('TC-REQ-4.1: Submitting with Email left completely empty displays a validation error for that field', async ({ page }) => {
  const registrationPage = new RegistrationPage(page);

  await test.step('Перейти на сторінку реєстрації', async () => {
    await registrationPage.goto();
  });

  await test.step('Надіслати форму з порожнім Email', async () => {
    await registrationPage.fillMandatoryFields({ email: '', password: VALID_PASSWORD });
    await registrationPage.submit();
  });

  await test.step('Перевірити, що відображається помилка валідації для Email', async () => {
    await expect(
      registrationPage.errorMessage,
      'очікували помилку валідації, що згадує Email'
    ).toContainText('Email');
  });
});
```

Зверни увагу, що перевірка використовує виставлену властивість
локатора `errorMessage` Page Object (визначену один раз у
конструкторі) — вона не будує свіжий `page.getByRole('alert')`
inline у spec, і сам Page Object ніколи не викликає `expect`. Ця
межа — локатори, визначені один раз на Page Object, дії як методи,
перевірки в spec націлені на ці виставлені локатори — це те, що
означає «жодного сирого локатора в spec-файлі» на практиці.

Глибина шляху імпорту: spec у `<ISSUEKEY>/ui-tests/<file>.spec.ts`
імпортує спільний Page Object через `../../ui-framework/pages/<PageName>`
(вгору з `ui-tests/`, вгору з `<ISSUEKEY>/`, назад вниз у кореневу
`ui-framework/pages/`). Скоригуй кількість `../`, якщо структура
робочої директорії вкладає папки задач глибше.

## Стратегія селекторів (найкращі практики Playwright)

Порядок пріоритету, від найбільш до найменш пріоритетного:

1. `getByRole(role, { name })` — відповідає тому, як сторінка
   фактично виставлена для допоміжних технологій та користувачів;
   найбільш стійкий до змін розмітки.
2. `getByLabel` / `getByPlaceholder` — для полів форми без чіткої
   комбінації role/name.
3. `getByText` — для статичного контенту, повідомлень, заголовків.
4. `getByTestId` — тільки коли застосунок вже виставляє стабільну
   конвенцію `data-testid` (підтверджено через пошук у кодовій
   базі); не додавай цей атрибут у застосунок сам, використовуй
   лише якщо він вже там є.
5. CSS чи XPath селектор — тільки як останній варіант, коли жоден з
   вищих не може унікально ідентифікувати елемент (наприклад, немає
   accessible name, немає test id, неоднозначний текст). Кожне
   використання повинно бути позначене як нотатка про крихкість у
   `summary.md`, з однорядковою причиною, чому варіанти вищого
   пріоритету не спрацювали.

Ніколи не вибирай за авто-згенерованим/динамічним іменем класу
(наприклад, хеш CSS-modules) чи за позицією в DOM (`nth-child`,
`:eq()`) — обидва ламаються на непов'язаних змінах розмітки.

## Трасованість у виводі тестів

Згенерований тест повинен бути зрозумілим з власного виводу —
HTML-звіту — без відкриття файлу з кодом чи повторного запуску в
дебагері. Дві техніки, обидві обов'язкові разом:

### 1. `test.step` на кожну логічну фазу

Обгорни фази навігація / дія / перевірка (або більш деталізовані
кроки для багаточастинних сценаріїв) у `test.step('<намір>', async
() => { ... })`. Це робить так, що список кроків HTML-звіту сам
розповідає сценарій (наприклад, «Перейти на сторінку реєстрації» →
«Надіслати форму з порожнім Email» → «Перевірити, що відображається
помилка валідації для Email»).

### 2. Кожна перевірка несе описове повідомлення

Ніколи не залишай голий `expect(x).toBe(y)` без повідомлення.
Зазнач, що очікувалось; вивід помилки Playwright вже включає
фактичне значення для web-first перевірок, тому повідомлення
потрібне лише щоб коротко вказати намір:

```ts
await expect(
  page.getByRole('alert'),
  'очікували помилку валідації для поля Email'
).toBeVisible();
```

### Чому тут не потрібен власний attach-хелпер

API-тести потребують спільного хелпера `attachExchange`, тому що
HTTP-обмін не має власного візуального артефакту — JSON має бути
прикріплений вручну, щоб бути видимим у звіті. Браузерний тест не
має цієї проблеми: Playwright автоматично захоплює і прикріплює
трейс, скріншот, і (якщо налаштовано) відео до HTML-звіту для
будь-якого проваленого тесту, щойно налаштована конфігурація нижче.
Не будуй UI-специфічний еквівалент `attachExchange` — натомість
налаштуй артефакти.

## Виявлення конфігурації та генерація заготовки

- Якщо надана кодова база має `playwright.config.ts`/`.js` з
  `baseURL` та/або `projects` — повторно використовуй її: переходь
  через відносні шляхи (`page.goto('/#/register')`), а не з жорстко
  прописаним хостом.
- Якщо надана кодова база має існуючі фікстури авторизації (файл
  `storageState`, крок логіну в global-setup) — повторно використай
  той самий патерн через імпорт, а не через повторне виведення
  логіну для кожного тесту.
- Якщо кодова база не надана, або нічого з вищезгаданого не
  знайдено, створи мінімальний `playwright.config.ts` всередині
  `<ISSUEKEY>/ui-tests/`:

```ts
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  reporter: [['html', { open: 'never' }]],
  use: {
    baseURL: 'http://localhost:3000', // TODO: замінити на реальний базовий URL застосунку
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
  ],
});
```

`open: 'never'` не дає простому `npm test` намагатись відкрити
браузер після запуску — людина, що запускає тести, відкриває звіт
явно через `npx playwright show-report`. `trace: 'retain-on-failure'`
+ `screenshot: 'only-on-failure'` + `video: 'retain-on-failure'`
тримають звіт сфокусованим (жодних артефактів, що засмічують
пройдені тести), водночас роблячи провал повністю дослідним —
trace-viewer дозволяє прогорнути фактичний стан DOM/мережі/консолі
на кожному `test.step`.

Тільки `chromium` налаштований за замовчуванням — тримай набір
швидким, якщо тест-кейс явно не вимагає крос-браузерної перевірки.
Якщо вимагає, додай проєкт `firefox`/`webkit` і зазнач це в
`README.md`.

- Якщо повторно використовується існуючий `playwright.config.ts` з
  наданої кодової бази, який ще не встановлює
  `trace`/`screenshot`/`video`, не покладайся мовчки на дефолт —
  явно зазнач у `README.md`, як отримати ці артефакти для цього
  запуску без редагування існуючої конфігурації (наприклад, `npx
  playwright test --trace=retain-on-failure`).

## Скрипт пошуку (Доступ до коду/сторінок, секція B)

Використовується тільки коли доступний URL запущеного застосунку, і
кодова база або не була надана, або не покриває цільову сторінку
впевнено. Запускається один раз, перед будь-якою генерацією коду,
використовуючи пакет `playwright` напряму (не раннер
`@playwright/test`):

```ts
// discover.ts — запусти один раз через `node discover.ts` (чи `npx tsx discover.ts`), потім видали/ігноруй
import { chromium } from 'playwright';
import { writeFileSync } from 'fs';

const BASE_URL = 'http://localhost:3000'; // TODO: замінити на реальний базовий URL застосунку
const TARGET_PAGES = [
  { name: 'registration', path: '/#/register' },
  // один запис на кожну сторінку, якої потребують вибрані тест-кейси
];

async function main() {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  const results: { page: string; url: string; snapshot: string }[] = [];

  for (const target of TARGET_PAGES) {
    await page.goto(`${BASE_URL}${target.path}`);
    const snapshot = await page.locator('body').ariaSnapshot();
    results.push({ page: target.name, url: target.path, snapshot });
  }

  writeFileSync('discovery/pages.json', JSON.stringify(results, null, 2));
  await browser.close();
}

main();
```

Запусти його один раз, прочитай `discovery/pages.json` один раз. Це
причина, чому скриптований прохід тут кращий за Playwright MCP: одне
виконання скрипта плюс одне читання файлу замінює те, що інакше
було б окремим циклом навігація + знімок (+ час від часу клік, для
багатокрокової передумови) інструмент-виклику MCP на кожну сторінку
— кожен такий цикл коштує повного ходу. Зберігай Playwright MCP для
дійсно інтерактивного випадку: флоу логіну чи розгалужений wizard,
чиї кроки не можна перелічити в `TARGET_PAGES` заздалегідь, оскільки
вони залежать від стану під час виконання.

## Очищення

Якщо `ui-mapping.json` називає підтверджений механізм очищення для
тесту (UI-флоу чи API-ендпоінт, що видаляє дані, які тест створив),
обгорни все, що йде після створення даних, в
`try { ... } finally { ... }`, з викликом очищення в `finally` —
ніколи просто не дописуй його після останньої перевірки, з тієї
самої причини, задокументованої в конвенціях api-tests: виклик
очищення, розміщений після перевірок, недосяжний саме тоді, коли
перевірка кидає помилку — а це саме той момент, коли лишкові дані
найбільш ймовірні.

Тримай саме очищення простим, неперевіреним best-effort викликом —
не обгортай його у `expect()`, і не дозволяй помилці очищення
маскувати оригінальну помилку тесту (не обгортай сам виклик очищення
у власний try/catch). Якщо мапінг зазначає, що механізм очищення не
знайдено — не додавай його; залиш тест як є.

## Спільне налаштування

Коли більше одного тесту потребує того самого багатокрокового
налаштування (наприклад, «акаунт вже існує» як передумова), виведи
його в метод Page Object (наприклад,
`RegistrationPage.registerNewAccount(data)`, що повертає створений
email), а не повторюй ті самі кроки inline в кожному spec-файлі —
та сама ідея, що й `helpers.ts` в api-tests, але живе на відповідному
Page Object, оскільки це специфічне для сторінки впорядкування дій,
а не крос-функціональна утиліта.

## Антипатерни

- Не конструюй свіжий `page.locator`/`page.getByRole`/тощо inline у
  файлі `.spec.ts` — локатори живуть на Page Object; дії йдуть через
  його методи, перевірки націлені на його виставлені локатори.
- Не викликай `expect()` всередині методу Page Object — перевірки
  належать spec-файлу.
- Не генеруй тест для TC-REQ пункту без виявленої чи підтвердженої
  сторінки/селектора — натомість познач його як такий, що потребує
  уточнення.
- Не жорстко прописуй повний URL, коли налаштовано `baseURL`.
- Не обʼєднуй непов'язані групи REQ в один файл.
- Не використовуй ручні очікування/сон — покладайся на
  авто-повторювані перевірки та дії локатора Playwright.
- Не вибирай за динамічним іменем класу чи позицією в DOM.
- Не регенеруй Page Object, який вже існує в `ui-framework/pages/`
  — розширюй його.
- Не видаляй, не перейменовуй і не змінюй поведінку існуючого
  методу Page Object — spec-файли інших задач можуть залежати від
  нього.
- Не пропускай налаштування `trace`/`screenshot`/`video` — UI-тест
  без артефактів провалу не є трасованим.
- Не додавай очищення, яке не є підтвердженим, виявленим механізмом
  — але й не пропускай підтверджене очищення.
