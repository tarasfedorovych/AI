# QAPR-0002 - User Login

Source: Local file `juice-shop-sample-reqs/QAPR-0002 - User-login-requirements-simplified.md`
Type: Requirements document (no tracker integration configured)
Generated: 2026-09-04

## Goal
Allow a registered customer to log in with their credentials (Feature ID: AUTH-LOGIN, Priority: Critical) so they can access customer functionality.

## Scope
- In scope: login form access, mandatory field validation, password field obscuring, credential authentication, session establishment/persistence, expired/invalid session handling, post-login navigation, error messaging, server-side authentication trust boundary, and the associated business/security rules and edge cases listed below.
- Out of scope: Not specified in source document.

## Requirements
- Preconditions: The application is available; the login page is accessible; a registered account exists for successful-login scenarios.
- Login Fields: Email (required, must identify an eligible account); Password (required, must match the account credential); Remember Me (if supported — uses configured persistent-session behavior).
- LOGIN-001: The system shall allow unauthenticated users to access the login form.
- LOGIN-002: The system shall require email and password.
- LOGIN-003: The password field shall obscure its value by default.
- LOGIN-004: The system shall authenticate a user when valid credentials for an eligible account are provided.
- LOGIN-005: The system shall reject an unknown email or incorrect password.
- LOGIN-006: Failed authentication shall not create an authenticated session.
- LOGIN-007: Successful authentication shall establish a session associated with the correct user.
- LOGIN-008: The authenticated state shall persist while the session remains valid.
- LOGIN-009: Expired or invalid sessions/tokens shall not provide authenticated access.
- LOGIN-010: After successful login, the user shall be navigated according to the configured product flow.
- LOGIN-011: Failed login shall display an appropriate error without exposing sensitive internal details.
- LOGIN-012: Authentication shall be performed by a trusted server-side mechanism.
- BR-LOGIN-001: Only valid credentials for an eligible account may establish an authenticated session.
- BR-LOGIN-002: Passwords shall never be stored or logged in plaintext.
- BR-LOGIN-003: Credentials shall be transmitted securely in non-development environments.
- BR-LOGIN-004: Authentication errors should not unnecessarily reveal whether a specific account exists.
- BR-LOGIN-005: The login endpoint shall handle malicious or malformed input safely.
- BR-LOGIN-006: Authentication tokens or session identifiers shall not contain passwords or be exposed in URLs.
- Important Edge Cases (for grooming/test design coverage): empty email; empty password; unknown email; correct email with incorrect password; email with different letter case; leading/trailing whitespace in email; leading/trailing whitespace in password; very long input; Unicode and special-character input; HTML/JavaScript-like or SQL-like input; rapid repeated login attempts; network or authentication-service failure; page refresh immediately after login; expired, malformed, or tampered session/token.
- AC-LOGIN-001 (Successful Login): Given an eligible registered customer exists, when the customer submits the correct email and password, then authentication succeeds and a valid session is established for the correct customer.
- AC-LOGIN-002 (Invalid Credentials): Given the submitted credentials are incorrect, when login is attempted, then authentication fails, no authenticated session is created, and an appropriate error is displayed.
- AC-LOGIN-003 (Missing Credentials): Given email or password is missing, when login is submitted, then authentication does not succeed and an appropriate validation error is displayed.
- AC-LOGIN-004 (Session Persistence): Given the customer successfully logged in, when the customer navigates within the application while the session is valid, then the customer remains authenticated.
- AC-LOGIN-005 (Expired Session): Given the customer's session has expired, when authenticated functionality is requested, then authenticated access is rejected and the application follows the configured re-authentication behavior.
- AC-LOGIN-006 (Backend Failure): Given authentication cannot be completed because of a backend failure, when login is attempted, then a controlled error is shown and the user remains unauthenticated.
