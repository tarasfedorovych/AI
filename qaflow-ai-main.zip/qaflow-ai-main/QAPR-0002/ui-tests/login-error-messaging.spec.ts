import { test, expect } from '@playwright/test';
import { LoginPage } from '../../ui-framework/pages/LoginPage';

// REQ-13: LOGIN-011 — failed login displays an appropriate error without
// exposing sensitive internal details. login.component.html renders the
// server's raw error text verbatim via `{{error}}` (routes/login.ts always
// answers a failed login with the fixed literal "Invalid email or
// password." — confirmed in the codebase).

// TC-REQ-13.1
test('TC-REQ-13.1: A failed login attempt displays an appropriate error message', async ({ page }) => {
  const loginPage = new LoginPage(page);

  await test.step('Submit the login form with incorrect credentials', async () => {
    await loginPage.goto();
    await loginPage.login('unknown.user@example.com', 'anyPassword1'); // [test data]
  });

  await test.step('Verify an appropriate error message is displayed', async () => {
    await expect(
      loginPage.invalidCredentialsError,
      'expected an appropriate error message to be displayed for a failed login'
    ).toBeVisible();
  });
});

// TC-REQ-13.2
test('TC-REQ-13.2: A failed-login error contains no stack trace, raw database error, or internal identifier', async ({ page }) => {
  const loginPage = new LoginPage(page);

  await test.step('Submit the login form with incorrect credentials', async () => {
    await loginPage.goto();
    await loginPage.login('unknown.user@example.com', 'anyPassword1'); // [test data]
  });

  await test.step('Inspect the displayed error content', async () => {
    await expect(loginPage.invalidCredentialsError, 'expected the generic error to be displayed').toBeVisible();
    const errorText = (await loginPage.invalidCredentialsError.textContent()) ?? '';
    expect(
      /at .+:\d+:\d+|stack|SequelizeDatabaseError|TypeError|\.js:\d+/i.test(errorText),
      `expected no stack trace, raw database error, or internal identifier in the displayed error, got "${errorText}"`
    ).toBe(false);
  });
});
