---
name: api-tests
description: >
  Eighth stage of task processing. Takes test cases and the
  automation-strategy classification and generates Playwright API
  test files in TypeScript for every test case classified as API,
  using Playwright Test's native request fixture. Optionally uses a
  provided codebase folder or Swagger/OpenAPI document for endpoint
  and schema discovery, and detects existing Playwright setup to
  match project conventions. Use when the user says "generate API
  tests", "automate the API test cases", "write Playwright API
  tests", or after automation-strategy completion.
---

# API Tests

> ⚙️ Recommended settings: **Sonnet · Effort: High · Extended thinking: Off**

Generates Playwright API test files in TypeScript for every test case
classified as API by the automation-strategy skill, using Playwright
Test's native `request` fixture. Never uses supertest, axios, or any
other HTTP client.

## Input Data

Required:
1. Test cases file `<ISSUEKEY>/test-cases.md` created by qa-test-cases.
2. Automation strategy file `<ISSUEKEY>/automation-strategy.md` created
   by automation-strategy — used to filter to only TC-REQ items marked
   `API`.

In the same chat, both files are available in the `<ISSUEKEY>/` folder
automatically. If the chat is new — the user uploads them to the chat.

Optional:
3. A path to an existing codebase folder — used for endpoint/schema
   discovery and to detect existing Playwright setup.
4. A Swagger/OpenAPI document — URL or local file — used for
   endpoint/schema discovery.

If either required file is missing — stop and inform the user which
upstream skill needs to run first.

If there are zero TC-REQ items classified `API` in the automation
strategy file — inform the user there is nothing to generate and stop.

All input files and any provided codebase folder are read-only. This
skill only ever writes new files under `<ISSUEKEY>/api-tests/`. It
never edits, deletes, or adds files anywhere inside a provided
codebase folder.

Do not go to the tracker, do not open a browser, do not search the
internet unless resolving a Swagger URL the user explicitly gave.

## Rules

- All communication and all output file content — in English.
- Chat messages — brief.
- Generate tests only for TC-REQ items marked `API` in the automation
  strategy file. Do not generate tests for UI or Manual items.
- Never invent endpoint paths, methods, request/response shapes, auth
  mechanisms, or base URLs. Discover them from a provided codebase or
  Swagger doc (see Code/Endpoint Access). If neither is provided, or
  discovery doesn't cover a given TC-REQ item, ask the user for that
  specific test case's endpoint details before generating its test —
  one clear, batched question listing exactly which TC-REQ items need
  which details, not a vague "give me your API info."
- Do not use supertest, axios, node-fetch, or any other HTTP client —
  only Playwright Test's built-in `request` fixture / `APIRequestContext`,
  imported from `@playwright/test`.
- Read-only with respect to any provided codebase: never modify
  `playwright.config.ts`, existing test files, `package.json`, or
  anything else inside that folder. All generated output goes
  exclusively into `<ISSUEKEY>/api-tests/` in the working directory,
  separate from the codebase folder.
- Every generated test must carry its TC-REQ-ID visibly in the test
  title (e.g. `test('TC-REQ-6.1: checkout.session.completed activates
  the subscription', ...)`) so traceability survives even if the file
  is viewed in isolation.
- Do not add tests, assertions, or setup steps beyond what the source
  test case describes.
- Every test must be understandable from its own output alone — the
  HTML report or terminal log — without opening the source file or
  re-running it. This is not optional polish: attach every
  request/response exchange (input parameters and full result) via the
  shared `attachExchange` helper, and never leave an `expect()` on a
  response without a message stating expected vs. actual. See
  "Traceability in Test Output" in references/playwright-conventions.md.
- Cleanup is generation-framework hygiene, not test-case content, and
  is required (not optional) whenever it's discoverable: if a test
  creates persistent data (e.g. a registered account) and a confirmed
  delete/reset endpoint exists for that resource, generate a
  best-effort cleanup call for it, even though the test case's own
  steps don't mention cleanup. This does not count as "setup/assertions
  beyond what the test case describes" — it's the same category as
  scaffolding `playwright.config.ts`. Never invent a cleanup mechanism
  that isn't discovered/confirmed; if none exists, state that plainly
  in the mapping entry and in summary.md instead of silently omitting
  it.
- After saving files — stop. Do not run the tests, do not continue to
  further skills.

## Code/Endpoint Access

Three possible input combinations. Determine which applies before
generating anything.

### A. Codebase folder provided

1. Ask for or confirm the folder path if not already given.
2. Endpoint/schema discovery — search the codebase (read-only) for:
   - Route/controller definitions (path, HTTP method, handler).
   - Request/response types, DTOs, validation schemas — to know
     required fields and realistic value shapes.
   - Auth setup — how requests authenticate (bearer token, cookie, API
     key header) and where test credentials/tokens would come from.
   For each API-classified TC-REQ item, match its described behavior
   (from the test case + rationale in automation-strategy) to the
   closest real endpoint. If no confident match is found — do not
   guess; list it as needing user clarification.
3. Playwright setup detection — check for:
   - `playwright.config.ts` / `.js` — read `baseURL`,
     `use.extraHTTPHeaders`, any `request` context defaults, project
     definitions.
   - Existing test folder location and naming convention — match it
     for reference, but always place new files under
     `<ISSUEKEY>/api-tests/` regardless (see Output File section).
   - Existing auth/token fixtures — reuse the same pattern instead of
     re-inventing auth per test.
   - If a Playwright config exists, generated tests should reuse its
     `baseURL` (via relative paths in requests) rather than hardcoding
     a full URL. If no config exists in the provided codebase, or no
     codebase was provided at all, generate a minimal own
     `playwright.config.ts` inside `<ISSUEKEY>/api-tests/` with a
     `baseURL` placeholder the user must fill in.
   - Dependency check: does the provided codebase's `package.json`
     already list `@playwright/test` as a dependency, and is
     `node_modules/@playwright` present? If yes, generated tests can
     run from inside that codebase folder as-is — state this in
     `README.md`. If no — or no codebase was provided at all — the
     `<ISSUEKEY>/api-tests/` folder is self-contained and unrunnable
     without its own `package.json` (see Dependency Scaffolding below).
     Never assume `@playwright/test` or `npx playwright` is available
     globally on the machine that will run these tests.

### B. Swagger/OpenAPI doc provided (with or without codebase folder)

1. Fetch/read the document (URL or local file, JSON or YAML).
2. For each API-classified TC-REQ item, find the matching path +
   method + schema in the doc. Use its parameter names, required
   fields, and response schema for assertions.
3. If a TC-REQ item has no matching operation in the doc — do not
   invent one; list it as needing user clarification.

### C. Neither codebase nor Swagger doc provided

Do not invent any endpoint path, method, payload shape, or base URL.
For every API-classified TC-REQ item, ask the user directly:

- Endpoint path and method?
- Expected status code for the success/failure case described?
- Required request body fields (name : example value)?
- Auth requirement (none / bearer token / API key / cookie)?

Batch this into one question per test case, not one message per field.
Do not generate that test until answered. Test cases whose details are
answered can be generated while others are still pending clarification
— do not block the whole batch on one unanswered item.

## API Mapping (Intermediate Artifact)

Before generating any Playwright code, produce a framework-agnostic
mapping file: `<ISSUEKEY>/api-tests/api-mapping.json`. This persists
the endpoint-discovery decisions (which endpoint, which request shape,
why a `[test data]` literal was substituted, what cleanup is
available) as reviewable data instead of burying them only in code
comments — and makes the same discovery work reusable by a
non-Playwright renderer later, without redoing it.

One entry per API-classified TC-REQ item (including pending ones).
Schema and worked examples — in
references/api-mapping-schema.md. Supports single-request test cases
as well as multi-step chains, concurrent requests, and cleanup steps —
do not force a multi-call scenario into a single `request` object.

Generate the `.spec.ts` files strictly from what's in `api-mapping.json`
(not by re-deriving endpoint details from test-cases.md a second time)
— this keeps the mapping file the actual source of truth for what gets
generated, not a parallel document that can drift from the code.

If a mapping entry has no confirmed endpoint for a step — do not
generate that entry's test; keep it as `"status": "pending"` with a
`reason`, matching the pending-clarification handling in Rules above.

## Dependency Scaffolding

Generated tests must be runnable with nothing more than the how-to-run
steps in `README.md` — never assume `@playwright/test`, `npx
playwright`, or any other dependency is already available on whatever
machine ends up running them.

If dependency check (in Code/Endpoint Access, section A) found that the
provided codebase already has `@playwright/test` installed and
configured — generated tests can run from there; do not create a
second `package.json`, just document the existing install path in
`README.md`.

Otherwise (no codebase provided, or no existing Playwright/npm setup
found), `<ISSUEKEY>/api-tests/` must be self-contained: generate a
`package.json` there with `@playwright/test` as a devDependency (pin
an exact recent version — do not use `latest` or a bare `*`, so the
install is reproducible) and a `test` script (`"test": "playwright
test"`). API tests using only the `request` fixture do not need
browser binaries — do not add a `playwright install` step or
`browsers` config for this folder.

Whichever config is used (scaffolded or an existing one from a
provided codebase), generated tests must produce an HTML report the
user can view after a run — see the reporter configuration in
references/playwright-conventions.md and the `README.md` "View
Report" section in references/output-template.md.

## Playwright Generation Conventions

Full conventions — in references/playwright-conventions.md. Summary:

- Framework: Playwright Test's `request` fixture only —
  `import { test, expect } from '@playwright/test';`
- One `.spec.ts` file per REQ group (not per TC-REQ), named by feature
  slug, e.g. `checkout-webhooks.spec.ts` for a REQ about webhook
  events. Group by the requirement/feature area shown in the
  test-cases file's REQ headings, not by TC-REQ ID, so related endpoint
  tests share setup. A REQ group with only one API TC-REQ item still
  gets its own small file rather than a catch-all file, to keep 1:1
  traceability to a REQ obvious from the filename.
- One `test()` block per TC-REQ item inside each file. Test title
  format: `'TC-REQ-<id>: <scenario name from test case>'`, with a
  `// TC-REQ-<id>` comment directly above the `test()` call.
- Structure per test: arrange (build request payload from the test
  case's Test Data column) → act (`request.get/post/put/delete(...)`,
  immediately attached via `attachExchange`) → assert (status via
  `expect(response.ok()).toBeTruthy()` or explicit
  `expect(response.status()).toBe(<code>)`, both with a descriptive
  message, then body assertions), mirroring the test case's own
  Steps/Expected Result rows one-to-one where practical.
- Use the test case's exact literal values where specified (status
  codes, field names, event types); use realistic placeholder values
  only for anything marked `[test data]`, kept as clearly-named
  constants at the top of the file.
- Every request/response exchange attached via `attachExchange`
  (`helpers.ts`); every assertion on a response carries a message with
  expected vs. actual; multi-step tests grouped with `test.step`.

## Output File

Create the folder `<ISSUEKEY>/api-tests/` in the working directory if
it does not exist. Inside it, create:
- `api-mapping.json` — the framework-agnostic mapping described above
  (see references/api-mapping-schema.md). Generate this first.
- `helpers.ts` — the shared `attachExchange` function (and any shared
  multi-step setup helpers), imported by every `.spec.ts` file (see
  references/playwright-conventions.md).
- One `.spec.ts` file per REQ group containing API-classified test
  cases (see Playwright Generation Conventions).
- `playwright.config.ts` — only if no existing Playwright config was
  found in a provided codebase folder. If an existing config was
  found, do not create a duplicate; state in summary.md which existing
  config the tests assume.
- `package.json` — only if no existing `@playwright/test` install was
  found in a provided codebase folder (see Dependency Scaffolding).
- `summary.md` — traceability document: mapping reference, per-TC-REQ
  status table, cleanup coverage (see references/output-template.md).
- `README.md` — human-facing how-to-run instructions: prerequisites,
  install command, run command, required environment/base URL (see
  references/output-template.md). This is the file a person actually
  follows to execute the suite; keep it short and copy-pasteable.

Give the user the folder path for download. The files remain in
`<ISSUEKEY>/api-tests/` — this is the last step in the chain, nothing
consumes them automatically afterward.

If files with the same names already exist in `<ISSUEKEY>/api-tests/`
— delete them completely and create new ones. Always output the
result of the latest run only.

Output template — in references/output-template.md.

## Verification Before Saving

Before saving, verify:

- Every API-classified TC-REQ item from automation-strategy.md has
  exactly one corresponding `test()` block, unless it was left pending
  user clarification (listed explicitly in summary.md instead).
- Every test title contains its TC-REQ-ID.
- No test uses an HTTP client other than Playwright's request fixture.
- No endpoint, payload field, or status code appears that wasn't
  sourced from the codebase, Swagger doc, or explicit user answer.
- Every entry in `api-mapping.json` has a corresponding `.spec.ts`
  test, except `"status": "pending"` entries.
- Every mapping entry for a test that creates persistent data states
  either a confirmed `cleanup` step or explicitly notes that no
  cleanup mechanism was found (see Rules on cleanup below).
- `README.md` exists and its install/run commands are the actual
  commands needed given what was scaffolded (a self-contained
  `package.json` vs. an existing codebase install) — not a copy-paste
  assumption.
- An HTML reporter is configured (scaffolded config) or a documented
  `--reporter=html` fallback exists (reused existing config), and
  `README.md`'s "View Report" section matches which of the two applies.
- Every `request` call in every test is followed by an `attachExchange`
  call before any assertion runs against its response.
- No `expect()` on a response, or a value derived from one, is missing
  a descriptive message.

## Final Response

After saving, inform:
- Path to `<ISSUEKEY>/api-tests/`
- Number of `.spec.ts` files and `test()` blocks generated
- Number of TC-REQ items covered vs. pending clarification
- Whether a self-contained `package.json` was scaffolded or an
  existing codebase install is assumed
- How-to-run command (matching what's in `README.md`)
