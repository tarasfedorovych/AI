#!/usr/bin/env python3
"""
json_to_xlsx.py
Convert a test-audit JSON report into a comprehensive XLSX report with charts and diagrams.

Usage:
  python json_to_xlsx.py input.json output.xlsx

Requires:
  pip install openpyxl
"""
from __future__ import annotations
import json
import sys
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, PieChart, Reference, RadarChart
from openpyxl.chart.label import DataLabelList


# Color schemes
COLORS = {
    "critical": "DC3545",  # Red
    "high": "FD7E14",      # Orange
    "medium": "FFC107",    # Yellow
    "low": "28A745",       # Green
    "info": "17A2B8",      # Blue
    "header": "343A40",    # Dark gray
    "subheader": "6C757D", # Medium gray
    "light": "F8F9FA",     # Light gray
}

RISK_COLORS = {
    "critical": "DC3545",
    "high": "FD7E14",
    "medium": "FFC107",
    "low": "28A745",
}

# Area ID to Name mapping
AREA_NAMES = {
    "reliability_flakiness": "Reliability/Flakiness Control",
    "test_design": "Test Design & Readability",
    "architecture": "Framework Architecture",
    "test_data": "Test Data Strategy",
    "ci_cd": "CI/CD Integration",
    "reporting": "Reporting & Observability",
    "coverage": "Coverage Maturity",
}


def setup_column_widths(ws, widths):
    """Set column widths for a worksheet."""
    for col_idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(col_idx)].width = width


def add_header_row(ws, row_idx, values, bg_color=COLORS["header"]):
    """Add a styled header row."""
    for col_idx, value in enumerate(values, start=1):
        cell = ws.cell(row=row_idx, column=col_idx, value=value)
        cell.font = Font(bold=True, color="FFFFFF", size=11)
        cell.fill = PatternFill(start_color=bg_color, end_color=bg_color, fill_type="solid")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(
            left=Side(style="thin"),
            right=Side(style="thin"),
            top=Side(style="thin"),
            bottom=Side(style="thin"),
        )


def add_data_row(ws, row_idx, values, bg_color=None):
    """Add a data row with optional background color."""
    for col_idx, value in enumerate(values, start=1):
        cell = ws.cell(row=row_idx, column=col_idx, value=value)
        cell.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
        cell.border = Border(
            left=Side(style="thin"),
            right=Side(style="thin"),
            top=Side(style="thin"),
            bottom=Side(style="thin"),
        )
        if bg_color:
            cell.fill = PatternFill(start_color=bg_color, end_color=bg_color, fill_type="solid")


def create_summary_sheet(wb, data):
    """Create overview summary sheet with key metrics."""
    ws = wb.active
    ws.title = "Summary"
    setup_column_widths(ws, [30, 20, 50])

    # Title
    ws.merge_cells("A1:C1")
    title_cell = ws["A1"]
    title_cell.value = "Test Automation Audit Report - Summary"
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color=COLORS["header"], end_color=COLORS["header"], fill_type="solid")
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 30

    # Meta information
    meta = data.get("meta", {})
    repo = meta.get("repository", {})
    row = 3

    ws.merge_cells(f"A{row}:C{row}")
    ws[f"A{row}"] = "Report Information"
    ws[f"A{row}"].font = Font(bold=True, size=14)
    row += 1

    # Extract timezone from generated_at
    timezone = "UTC"
    generated_at = meta.get("generated_at", "")
    if "Z" not in generated_at and "+" not in generated_at:
        timezone = "UTC"

    info_items = [
        ("Report ID", meta.get("report_id", "N/A")),
        ("Generated At", generated_at or "N/A"),
        ("Timezone", timezone),
        ("Repository", repo.get("name", "N/A")),
        ("Language", repo.get("primary_language", "N/A")),
        ("Framework", repo.get("framework", "N/A")),
        ("Build Tool", repo.get("build_tool", "N/A")),
    ]

    for label, value in info_items:
        ws[f"A{row}"] = label
        ws[f"A{row}"].font = Font(bold=True)
        ws[f"B{row}"] = value
        row += 1

    # Executive Summary
    exec_sum = data.get("executive_summary", {})
    row += 2
    ws.merge_cells(f"A{row}:C{row}")
    ws[f"A{row}"] = "Executive Summary"
    ws[f"A{row}"].font = Font(bold=True, size=14)
    row += 1

    overall_score = exec_sum.get("overall_score", 0)
    risk_level = exec_sum.get("risk_level", "unknown").upper()
    
    # Score and risk level
    ws[f"A{row}"] = "Overall Score"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"] = overall_score
    ws[f"B{row}"].font = Font(bold=True, size=24)
    ws[f"B{row}"].alignment = Alignment(horizontal="center")
    
    ws[f"A{row+1}"] = "Risk Level"
    ws[f"A{row+1}"].font = Font(bold=True)
    ws[f"B{row+1}"] = risk_level
    risk_color = RISK_COLORS.get(risk_level.lower(), COLORS["info"])
    ws[f"B{row+1}"].font = Font(bold=True, size=14, color=risk_color)
    ws[f"B{row+1}"].alignment = Alignment(horizontal="center")
    row += 3

    # Overall Assessment (Extended Summary matching Executive Summary tab)
    ws.merge_cells(f"A{row}:C{row}")
    ws[f"A{row}"] = "Overall Assessment"
    ws[f"A{row}"].font = Font(bold=True, size=12)
    row += 1
    
    # Build comprehensive summary (same as Executive Summary tab)
    headline = exec_sum.get("headline", "")
    summary_parts = [headline]
    
    # Add score context
    if overall_score < 50:
        summary_parts.append(f"With an overall score of {overall_score}/100, the test suite demonstrates significant quality concerns requiring immediate attention.")
    elif overall_score < 70:
        summary_parts.append(f"The test suite scores {overall_score}/100, indicating moderate quality with room for improvement in several areas.")
    else:
        summary_parts.append(f"The test suite achieves a good score of {overall_score}/100, showing solid quality practices with opportunities for optimization.")
    
    # Add risk context from key_risks
    top_risks = exec_sum.get("key_risks", [])
    if top_risks:
        summary_parts.append(f"Key concerns include: {'; '.join(top_risks[:2])}")
    
    extended_summary = " ".join(summary_parts)
    
    ws.merge_cells(f"A{row}:C{row}")
    ws[f"A{row}"] = extended_summary
    ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[row].height = 120
    row += 2

    # Statistics from scorecard
    scorecard = data.get("scorecard", [])
    if scorecard:
        ws.merge_cells(f"A{row}:C{row}")
        ws[f"A{row}"] = "Area Scores Overview"
        ws[f"A{row}"].font = Font(bold=True, size=12)
        row += 1

        add_header_row(ws, row, ["Area", "Score", "Risk Level"])
        row += 1

        for area in scorecard:
            # Handle both area_name and area fields
            area_id = area.get("area") or area.get("area_id", "unknown")
            area_name = area.get("area_name") or AREA_NAMES.get(area_id, area_id.replace("_", " ").title())
            score = area.get("score")
            # Handle None/null scores (e.g., coverage area without metrics)
            if score is None:
                score = "N/A"
            area_risk = area.get("risk_level", "unknown")
            if area_risk == "unknown" and score != "N/A":
                # Determine risk level from score if not provided
                if score < 50:
                    area_risk = "high"
                elif score < 70:
                    area_risk = "medium"
                else:
                    area_risk = "low"
            area_risk = area_risk.upper()
            risk_color = RISK_COLORS.get(area_risk.lower(), COLORS["light"])
            
            add_data_row(ws, row, [area_name, score, area_risk], bg_color=risk_color)
            row += 1

    # Findings summary
    findings = data.get("findings", [])
    if findings:
        row += 2
        ws.merge_cells(f"A{row}:C{row}")
        ws[f"A{row}"] = "Findings Summary"
        ws[f"A{row}"].font = Font(bold=True, size=12)
        row += 1

        severity_counts = {}
        for finding in findings:
            sev = finding.get("severity", "info").lower()  # Convert to lowercase
            severity_counts[sev] = severity_counts.get(sev, 0) + 1

        add_header_row(ws, row, ["Severity", "Count", ""])
        row += 1

        for sev in ["critical", "high", "medium", "low", "info"]:
            count = severity_counts.get(sev, 0)
            if count > 0:
                sev_color = COLORS.get(sev, COLORS["light"])
                add_data_row(ws, row, [sev.upper(), count, ""], bg_color=sev_color)
                row += 1


def create_executive_summary_sheet(wb, data):
    """Create executive summary sheet with highlights."""
    ws = wb.create_sheet("Executive Summary")
    setup_column_widths(ws, [80])

    exec_sum = data.get("executive_summary", {})
    highlights = exec_sum.get("highlights", {})

    # Title
    ws.merge_cells("A1:A1")
    title_cell = ws["A1"]
    title_cell.value = "Executive Summary - Key Highlights"
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color=COLORS["header"], end_color=COLORS["header"], fill_type="solid")
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 30

    row = 3

    # Overall assessment
    ws[f"A{row}"] = "Overall Assessment"
    ws[f"A{row}"].font = Font(bold=True, size=14, color=COLORS["header"])
    row += 1

    # Create extended summary from headline and risk assessment
    headline = exec_sum.get("headline", "")
    overall_score = exec_sum.get("overall_score", 0)
    risk_level = exec_sum.get("risk_level", "unknown").lower()
    
    # Build comprehensive summary
    summary_parts = [headline]
    
    # Add score context
    if overall_score < 50:
        summary_parts.append(f"With an overall score of {overall_score}/100, the test suite demonstrates significant quality concerns requiring immediate attention.")
    elif overall_score < 70:
        summary_parts.append(f"The test suite scores {overall_score}/100, indicating moderate quality with room for improvement in several areas.")
    else:
        summary_parts.append(f"The test suite achieves a good score of {overall_score}/100, showing solid quality practices with opportunities for optimization.")
    
    # Add risk context from key_risks
    top_risks = exec_sum.get("key_risks", [])
    if top_risks:
        summary_parts.append(f"Key concerns include: {'; '.join(top_risks[:2])}")
    
    extended_summary = " ".join(summary_parts)
    
    ws[f"A{row}"] = extended_summary
    ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[row].height = 120
    row += 2

    # Key Strengths
    strengths = exec_sum.get("key_strengths", [])
    if strengths:
        ws[f"A{row}"] = "Key Strengths"
        ws[f"A{row}"].font = Font(bold=True, size=12, color=COLORS["low"])
        ws[f"A{row}"].fill = PatternFill(start_color="D4EDDA", end_color="D4EDDA", fill_type="solid")
        row += 1

        for strength in strengths:
            ws[f"A{row}"] = f"✓ {strength}"
            ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top", indent=1)
            ws.row_dimensions[row].height = 40
            row += 1
        row += 1

    # Key Risks
    risks = exec_sum.get("key_risks", [])
    if risks:
        ws[f"A{row}"] = "Key Risks"
        ws[f"A{row}"].font = Font(bold=True, size=12, color=COLORS["critical"])
        ws[f"A{row}"].fill = PatternFill(start_color="F8D7DA", end_color="F8D7DA", fill_type="solid")
        row += 1

        for risk in risks:
            ws[f"A{row}"] = f"⚠ {risk}"
            ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top", indent=1)
            ws.row_dimensions[row].height = 40
            row += 1
        row += 1


def create_scorecard_sheet(wb, data):
    """Create scorecard sheet with area assessments and chart."""
    ws = wb.create_sheet("Scorecard")
    setup_column_widths(ws, [30, 12, 15, 60])

    # Title
    ws.merge_cells("A1:D1")
    title_cell = ws["A1"]
    title_cell.value = "Quality Scorecard by Area"
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color=COLORS["header"], end_color=COLORS["header"], fill_type="solid")
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 30

    # Header
    add_header_row(ws, 3, ["Area", "Score", "Risk Level", "Rationale"])

    # Data
    scorecard = data.get("scorecard", [])
    row = 4
    for area in scorecard:
        # Handle both area_name and area fields
        area_id = area.get("area") or area.get("area_id", "unknown")
        area_name = area.get("area_name") or AREA_NAMES.get(area_id, area_id.replace("_", " ").title())
        score = area.get("score")
        # Handle None/null scores (e.g., coverage area without metrics)
        if score is None:
            score = "N/A"
        risk_level = area.get("risk_level", "unknown")
        if risk_level == "unknown" and score != "N/A":
            # Determine risk level from score if not provided
            if score < 50:
                risk_level = "high"
            elif score < 70:
                risk_level = "medium"
            else:
                risk_level = "low"
        risk_level = risk_level.upper()
        
        # Handle nested rationale in details object or at root level  
        rationale = area.get("rationale", "")
        if not rationale and "details" in area:
            rationale = area.get("details", {}).get("rationale", "")
        if not rationale:
            rationale = area.get("summary", "")
        
        risk_color = RISK_COLORS.get(risk_level.lower(), COLORS["light"])
        add_data_row(ws, row, [area_name, score, risk_level, rationale], bg_color=risk_color)
        ws.row_dimensions[row].height = 45
        row += 1

    # Add bar chart
    if scorecard:
        chart = BarChart()
        chart.type = "col"
        chart.title = "Scores by Area"
        chart.y_axis.title = "Score"
        chart.x_axis.title = "Area"
        chart.height = 12
        chart.width = 20

        # Data for chart
        data_ref = Reference(ws, min_col=2, min_row=3, max_row=3 + len(scorecard))
        cats_ref = Reference(ws, min_col=1, min_row=4, max_row=3 + len(scorecard))
        chart.add_data(data_ref, titles_from_data=True)
        chart.set_categories(cats_ref)
        
        ws.add_chart(chart, f"A{row + 2}")


def create_findings_sheet(wb, data):
    """Create detailed findings sheet."""
    ws = wb.create_sheet("Findings")
    setup_column_widths(ws, [10, 50, 12, 12, 15, 10, 10, 60])

    # Title
    ws.merge_cells("A1:H1")
    title_cell = ws["A1"]
    title_cell.value = "Detailed Findings"
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color=COLORS["header"], end_color=COLORS["header"], fill_type="solid")
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 30

    # Header
    add_header_row(ws, 3, ["ID", "Title", "Severity", "Risk Level", "Category", "Effort", "Priority", "Issue"])

    # Data
    findings = data.get("findings", [])
    row = 4
    for finding in findings:
        finding_id = finding.get("id", "")
        title = finding.get("title", "")
        severity = finding.get("severity", "info").upper()
        
        # Extract risk_level or derive from severity
        risk_level = finding.get("risk_level", "")
        if not risk_level or risk_level == "unknown":
            # Derive from severity if not provided
            if severity in ["CRITICAL", "HIGH"]:
                risk_level = "HIGH"
            elif severity == "MEDIUM":
                risk_level = "MEDIUM"
            else:
                risk_level = "LOW"
        risk_level = risk_level.upper()
        
        area_key = finding.get("area", "")
        # Use explicit "category" field first, then fall back to area name mapping
        category = finding.get("category", "") or AREA_NAMES.get(area_key, area_key.replace("_", " ").title())
        
        # Extract effort from root or recommendation
        effort = finding.get("effort", "")
        if not effort:
            rec = finding.get("recommendation", {})
            if isinstance(rec, dict):
                effort = rec.get("effort", "")
            if not effort and isinstance(rec, dict) and "priority" in rec:
                # Map priority to effort size if effort field absent
                priority_str = rec.get("priority", "")
                if "P0" in priority_str or "Immediate" in priority_str:
                    effort = "Large"
                elif "P1" in priority_str:
                    effort = "Medium"
                elif "P2" in priority_str:
                    effort = "Medium"
                else:
                    effort = "Low"
        
        # Extract priority_rank from recommendation priority field
        priority = finding.get("priority_rank", "")
        if not priority:
            rec = finding.get("recommendation", {})
            if isinstance(rec, dict) and "priority" in rec:
                priority_str = rec.get("priority", "")
                if "P0" in priority_str:
                    priority = "P0"  
                elif "P1" in priority_str:
                    priority = "P1"
                elif "P2" in priority_str:
                    priority = "P2"
                elif "P3" in priority_str:
                    priority = "P3"
        
        # Extract issue/description
        issue = finding.get("issue", finding.get("description", ""))
        if len(issue) > 100:
            issue = issue[:97] + "..."
        
        sev_color = COLORS.get(severity.lower(), COLORS["light"])
        add_data_row(ws, row, [finding_id, title, severity, risk_level, category, effort, priority, issue], bg_color=sev_color)
        ws.row_dimensions[row].height = 60
        row += 1


def create_findings_detail_sheet(wb, data):
    """Create detailed findings with recommendations."""
    ws = wb.create_sheet("Findings Details")
    setup_column_widths(ws, [80])

    # Title
    ws.merge_cells("A1:A1")
    title_cell = ws["A1"]
    title_cell.value = "Findings - Full Details with Recommendations"
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color=COLORS["header"], end_color=COLORS["header"], fill_type="solid")
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 30

    findings = data.get("findings", [])
    row = 3

    for finding in findings:
        finding_id = finding.get("id", "")
        title = finding.get("title", "")
        severity = finding.get("severity", "info").upper()
        
        # Finding header
        ws[f"A{row}"] = f"{finding_id}: {title}"
        sev_color = COLORS.get(severity.lower(), COLORS["header"])
        ws[f"A{row}"].font = Font(bold=True, size=12, color="FFFFFF")
        ws[f"A{row}"].fill = PatternFill(start_color=sev_color, end_color=sev_color, fill_type="solid")
        ws.row_dimensions[row].height = 25
        row += 1

        # Metadata with proper extraction
        area_id = finding.get("area", "")
        category = AREA_NAMES.get(area_id, area_id.replace("_", " ").title())
        
        # Extract effort and priority from recommendation if not at root
        effort = finding.get("effort", "")
        effort_days = finding.get("effort_days", "")
        priority_rank = finding.get("priority_rank", "")
        
        rec = finding.get("recommendation", {})
        if isinstance(rec, dict):
            if not effort and "priority" in rec:
                priority_str = rec.get("priority", "")
                if "P0" in priority_str:
                    effort = "L"
                    priority_rank = "P0"
                elif "P1" in priority_str:
                    effort = "M"
                    priority_rank = "P1"
                else:
                    effort = "S"
                    priority_rank = rec.get("priority", "")
        
        # Extract risk_level or derive from severity
        risk_level = finding.get("risk_level", "")
        if not risk_level or risk_level == "unknown":
            if severity in ["CRITICAL", "HIGH"]:
                risk_level = "HIGH"
            elif severity == "MEDIUM":
                risk_level = "MEDIUM"
            else:
                risk_level = "LOW"
        
        effort_str = effort
        if effort_days:
            effort_str = f"{effort} ({effort_days} days)"
        elif effort and not effort_days:
            # Estimate days from effort
            days_map = {"S": "1-2", "M": "3-7", "L": "8-15"}
            effort_str = f"{effort} ({days_map.get(effort, '')} days)"
        
        metadata = [
            ("Severity", severity),
            ("Risk Level", risk_level.upper()),
            ("Category", category),
            ("Area", area_id),
            ("Effort", effort_str),
            ("Priority Rank", priority_rank),
            ("Confidence", finding.get("confidence", "High")),
        ]
        
        for label, value in metadata:
            ws[f"A{row}"] = f"{label}: {value}"
            ws[f"A{row}"].font = Font(italic=True)
            row += 1
        row += 1

        # Issue
        ws[f"A{row}"] = "Issue:"
        ws[f"A{row}"].font = Font(bold=True)
        row += 1
        issue_text = finding.get("issue", finding.get("description", ""))
        ws[f"A{row}"] = issue_text
        ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[row].height = 60
        row += 2

        # Impact
        ws[f"A{row}"] = "Impact:"
        ws[f"A{row}"].font = Font(bold=True)
        row += 1
        
        # Handle both string and dict formats for impact
        impact = finding.get("impact", "")
        if isinstance(impact, str):
            ws[f"A{row}"] = impact
            ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")
            ws.row_dimensions[row].height = 60
            row += 1
        elif isinstance(impact, dict):
            # Format dictionary impact as bullet points
            impact_text = ""
            # New format: functional, technical, business
            if "functional" in impact:
                impact_text += f"• Functional: {impact['functional']}\n"
            if "technical" in impact:
                impact_text += f"• Technical: {impact['technical']}\n"
            if "business" in impact:
                impact_text += f"• Business: {impact['business']}\n"
            # Old format fallback: test_reliability, execution_time, maintainability
            if "test_reliability" in impact:
                impact_text += f"• Test Reliability: {impact['test_reliability']}\n"
            if "execution_time" in impact:
                impact_text += f"• Execution Time: {impact['execution_time']}\n"
            if "maintainability" in impact:
                impact_text += f"• Maintainability: {impact['maintainability']}\n"
            ws[f"A{row}"] = impact_text.strip()
            ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")
            ws.row_dimensions[row].height = 80
            row += 1
        row += 1

        # Recommendation
        recommendation = finding.get("recommendation", {})
        if recommendation:
            ws[f"A{row}"] = "Recommendation:"
            ws[f"A{row}"].font = Font(bold=True)
            row += 1
            
            # Handle both string and dict formats
            if isinstance(recommendation, str):
                ws[f"A{row}"] = recommendation
                ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")
                ws.row_dimensions[row].height = 60
                row += 1
            elif isinstance(recommendation, dict):
                # Try what/how format first
                what = recommendation.get("what", "")
                how_steps = recommendation.get("how", [])
                
                # If not found, try action/implementation format
                if not what:
                    rec_text = ""
                    if "priority" in recommendation:
                        rec_text += f"Priority: {recommendation['priority']}"
                    if "effort" in recommendation:
                        rec_text += f" | Effort: {recommendation['effort']}"
                    if rec_text:
                        rec_text += "\n\n"
                    if "action" in recommendation:
                        rec_text += f"{recommendation['action']}\n\n"
                    if "implementation" in recommendation:
                        rec_text += f"Implementation:\n{recommendation['implementation']}"
                    
                    ws[f"A{row}"] = rec_text.strip()
                    ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")
                    ws.row_dimensions[row].height = 120
                    row += 1
                else:
                    # Use what/how format
                    ws[f"A{row}"] = what
                    ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")
                    ws.row_dimensions[row].height = 40
                    row += 1

                    if how_steps:
                        ws[f"A{row}"] = "How to fix:"
                        ws[f"A{row}"].font = Font(bold=True, italic=True)
                        row += 1
                        
                        for step in how_steps:
                            ws[f"A{row}"] = f"  • {step}"
                            ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top", indent=1)
                            ws.row_dimensions[row].height = 35
                            row += 1
        
        # Evidence
        evidence = finding.get("evidence", [])
        if evidence:
            row += 1
            ws[f"A{row}"] = "Evidence:"
            ws[f"A{row}"].font = Font(bold=True)
            row += 1
            
            for ev in evidence:
                # Support both old and new field names for compatibility
                file_path = ev.get("file_path", ev.get("file", "unknown"))
                line_start = ev.get("line_start", ev.get("line", ""))
                line_end = ev.get("line_end", ev.get("line", line_start))
                context = ev.get("context", "")
                code_snippet = ev.get("code_snippet", ev.get("snippet", ""))
                
                ev_text = f"📄 {file_path}"
                if line_start and line_end:
                    if line_start == line_end:
                        ev_text += f" (Line {line_start})"
                    else:
                        ev_text += f" (Lines {line_start}-{line_end})"
                if context:
                    ev_text += f"\n   Context: {context}"
                if code_snippet:
                    ev_text += f"\n   Code: {code_snippet[:100]}..." if len(code_snippet) > 100 else f"\n   Code: {code_snippet}"
                
                ws[f"A{row}"] = ev_text
                ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top", indent=1)
                ws.row_dimensions[row].height = 50 if code_snippet else 30
                row += 1

        # Separator
        row += 2
        ws[f"A{row}"] = "─" * 80
        row += 2


def create_recommendations_sheet(wb, data):
    """Create actionable recommendations sheet."""
    ws = wb.create_sheet("Recommendations")
    setup_column_widths(ws, [10, 55, 12, 10, 10, 70])

    # Title
    ws.merge_cells("A1:F1")
    title_cell = ws["A1"]
    title_cell.value = "Actionable Recommendations (Prioritized)"
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color=COLORS["header"], end_color=COLORS["header"], fill_type="solid")
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 30

    # Header
    add_header_row(ws, 3, ["ID", "What to Do", "Severity", "Effort", "Area", "How to Do It (Action Plan Tasks)"])

    # Build action_plan lookup: area -> list of tasks (merged if multiple items share area)
    action_plan_tasks_by_area = {}
    for ap_item in data.get("action_plan", []):
        area = ap_item.get("area", "")
        tasks = ap_item.get("tasks", [])
        if area and tasks:
            if area not in action_plan_tasks_by_area:
                action_plan_tasks_by_area[area] = []
            action_plan_tasks_by_area[area].extend(tasks)

    # Data - sort by severity then finding id
    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    findings = data.get("findings", [])
    sorted_findings = sorted(
        findings,
        key=lambda f: (severity_order.get(f.get("severity", "info").lower(), 99), f.get("id", ""))
    )

    row = 4
    for finding in sorted_findings:
        finding_id = finding.get("id", "")
        recommendation = finding.get("recommendation", "")
        severity = finding.get("severity", "info").upper()
        rec_obj = finding.get("recommendation", {})
        # Effort: check root field first, then recommendation.effort, then recommendation.priority
        effort = finding.get("effort", "")
        if not effort and isinstance(rec_obj, dict):
            effort = rec_obj.get("effort", "")
        if not effort and isinstance(rec_obj, dict) and "priority" in rec_obj:
            priority_str = rec_obj.get("priority", "")
            effort = "Large" if "P0" in priority_str else ("Medium" if "P1" in priority_str or "P2" in priority_str else "Low")
        # Area: use explicit category field first, then area key mapping
        area_id = finding.get("area", "")
        area_display = finding.get("category", "") or AREA_NAMES.get(area_id, area_id.replace("_", " ").title())

        # Extract "What to Do" from recommendation field (string or dict)
        if isinstance(recommendation, str):
            what = recommendation
        elif isinstance(recommendation, dict):
            what = (
                recommendation.get("what")
                or recommendation.get("action")
                or recommendation.get("implementation", "")
            )
        else:
            what = ""

        # Build "How to Do It" from action_plan tasks matching this finding's area
        tasks = action_plan_tasks_by_area.get(area_id, [])
        if tasks:
            how_text = "\n".join(f"{i+1}. {t}" for i, t in enumerate(tasks))
        elif isinstance(recommendation, dict):
            how_steps = recommendation.get("how", [])
            how_text = "\n".join(f"• {s}" for s in how_steps) if how_steps else ""
        else:
            how_text = ""

        sev_color = COLORS.get(severity.lower(), COLORS["light"])
        add_data_row(ws, row, [finding_id, what, severity, effort, area_display, how_text], bg_color=sev_color)

        how_lines = how_text.count("\n") + 1 if how_text else 1
        ws.row_dimensions[row].height = max(60, how_lines * 15 + 30)
        row += 1


def create_evidence_sheet(wb, data):
    """Create evidence/references sheet."""
    ws = wb.create_sheet("Evidence")
    setup_column_widths(ws, [10, 60, 25, 12, 12, 45])

    # Title
    ws.merge_cells("A1:F1")
    title_cell = ws["A1"]
    title_cell.value = "Finding Evidence & Code References"
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color=COLORS["header"], end_color=COLORS["header"], fill_type="solid")
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 30

    # Header
    add_header_row(ws, 3, ["Finding ID", "Title", "File Path", "Line Ref", "Severity", "Tags"])

    # Data
    findings = data.get("findings", [])
    row = 4

    for finding in findings:
        finding_id = finding.get("id", "")
        title = finding.get("title", "")
        severity = finding.get("severity", "info").upper()
        tags = ", ".join(finding.get("tags", []))
        sev_color = COLORS.get(severity.lower(), COLORS["light"])

        evidence_list = finding.get("evidence", [])

        if evidence_list:
            # Structured evidence array (new schema)
            for ev in evidence_list:
                file_path = ev.get("file_path", ev.get("file", ""))
                line_start = ev.get("line_start", ev.get("line", ""))
                line_end = ev.get("line_end", "")
                line_ref = f"{line_start}-{line_end}" if line_end and line_end != line_start else str(line_start)
                context = ev.get("context", ev.get("description", ""))
                add_data_row(ws, row, [finding_id, title, file_path, line_ref, severity, tags], bg_color=sev_color)
                ws.row_dimensions[row].height = 40
                row += 1
        else:
            # Fall back to file + line_refs fields present in this schema
            file_path = finding.get("file", "")
            line_refs = finding.get("line_refs", [])
            if line_refs:
                for line_ref in line_refs:
                    add_data_row(ws, row, [finding_id, title, file_path, str(line_ref), severity, tags], bg_color=sev_color)
                    ws.row_dimensions[row].height = 40
                    row += 1
            else:
                add_data_row(ws, row, [finding_id, title, file_path, "", severity, tags], bg_color=sev_color)
                ws.row_dimensions[row].height = 40
                row += 1


def create_charts_sheet(wb, data):
    """Create a sheet with various charts and visualizations."""
    ws = wb.create_sheet("Charts")
    setup_column_widths(ws, [25, 12, 60])
    
    # Title
    ws.merge_cells("A1:H1")
    title_cell = ws["A1"]
    title_cell.value = "Visual Analytics Dashboard"
    title_cell.font = Font(bold=True, size=16, color="FFFFFF")
    title_cell.fill = PatternFill(start_color=COLORS["header"], end_color=COLORS["header"], fill_type="solid")
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 30

    # ========================================
    # SECTION 1: FINDINGS BY SEVERITY
    # ========================================
    row = 3
    ws.merge_cells(f"A{row}:C{row}")
    ws[f"A{row}"] = "Findings Distribution by Severity Level"
    ws[f"A{row}"].font = Font(bold=True, size=14, color=COLORS["header"])
    ws[f"A{row}"].fill = PatternFill(start_color=COLORS["light"], end_color=COLORS["light"], fill_type="solid")
    ws.row_dimensions[row].height = 20
    row += 1

    # Description
    ws.merge_cells(f"A{row}:C{row}")
    ws[f"A{row}"] = "This pie chart shows the distribution of all findings categorized by severity level. Each severity indicates the potential impact on test quality and reliability."
    ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[row].height = 40
    row += 1

    # Legend explanation
    ws.merge_cells(f"A{row}:C{row}")
    ws[f"A{row}"] = "Severity Levels Explained:"
    ws[f"A{row}"].font = Font(bold=True, size=11)
    row += 1
    
    severity_explanations = [
        ("CRITICAL", "Requires immediate action - blocking issues that prevent proper test execution"),
        ("HIGH", "Significant impact - major gaps that affect test reliability and coverage"),
        ("MEDIUM", "Moderate impact - improvements needed to enhance test quality"),
        ("LOW", "Minor issues - optimizations for better maintainability"),
        ("INFO", "Informational - suggestions and best practices"),
    ]
    
    for sev, explanation in severity_explanations:
        sev_color = COLORS.get(sev.lower(), COLORS["light"])
        ws[f"A{row}"] = sev
        ws[f"A{row}"].font = Font(bold=True, color="FFFFFF")
        ws[f"A{row}"].fill = PatternFill(start_color=sev_color, end_color=sev_color, fill_type="solid")
        ws[f"A{row}"].alignment = Alignment(horizontal="center")
        ws[f"B{row}"] = explanation
        ws[f"B{row}"].alignment = Alignment(wrap_text=True, vertical="center")
        ws.row_dimensions[row].height = 30
        row += 1
    
    row += 1

    # Prepare data for severity pie chart
    findings = data.get("findings", [])
    severity_counts = {}
    for finding in findings:
        sev = finding.get("severity", "info").lower()  # Convert to lowercase
        severity_counts[sev] = severity_counts.get(sev, 0) + 1

    # Create data table for pie chart
    data_start_row = row
    ws[f"A{row}"] = "Severity"
    ws[f"B{row}"] = "Count"
    ws[f"A{row}"].font = Font(bold=True)
    ws[f"B{row}"].font = Font(bold=True)
    
    row += 1
    chart_data_start = row
    for sev in ["critical", "high", "medium", "low", "info"]:
        if sev in severity_counts:
            ws[f"A{row}"] = sev.upper()
            ws[f"B{row}"] = severity_counts[sev]
            row += 1

    # Create pie chart
    pie = PieChart()
    pie.title = "Findings by Severity"
    labels = Reference(ws, min_col=1, min_row=chart_data_start, max_row=row-1)
    data_ref = Reference(ws, min_col=2, min_row=data_start_row, max_row=row-1)
    pie.add_data(data_ref, titles_from_data=True)
    pie.set_categories(labels)
    pie.height = 12
    pie.width = 16
    
    # Add data labels to show percentages
    pie.dataLabels = DataLabelList()
    pie.dataLabels.showPercent = True
    pie.dataLabels.showCatName = False
    
    ws.add_chart(pie, "D3")

    # ========================================
    # SECTION 2: AREA SCORES RADAR CHART
    # ========================================
    row += 2
    ws.merge_cells(f"A{row}:C{row}")
    ws[f"A{row}"] = "Quality Assessment Radar by Area"
    ws[f"A{row}"].font = Font(bold=True, size=14, color=COLORS["header"])
    ws[f"A{row}"].fill = PatternFill(start_color=COLORS["light"], end_color=COLORS["light"], fill_type="solid")
    ws.row_dimensions[row].height = 20
    row += 1

    # Description
    ws.merge_cells(f"A{row}:C{row}")
    ws[f"A{row}"] = "This radar chart visualizes quality scores across different testing areas. Each axis represents a specific area of test automation. The distance from center indicates the score (0-100), with outer edges representing higher quality."
    ws[f"A{row}"].alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[row].height = 60
    row += 1

    # Score scale explanation
    ws.merge_cells(f"A{row}:C{row}")
    ws[f"A{row}"] = "Score Interpretation (0-100 scale):"
    ws[f"A{row}"].font = Font(bold=True, size=11)
    row += 1
    
    score_ranges = [
        ("75-100", "Excellent - Strong practices in place", COLORS["low"]),
        ("50-74", "Good - Minor improvements needed", COLORS["medium"]),
        ("25-49", "Fair - Significant gaps to address", COLORS["high"]),
        ("0-24", "Poor - Critical improvements required", COLORS["critical"]),
    ]
    
    for score_range, interpretation, color in score_ranges:
        ws[f"A{row}"] = score_range
        ws[f"A{row}"].font = Font(bold=True)
        ws[f"A{row}"].fill = PatternFill(start_color=color, end_color=color, fill_type="solid")
        ws[f"A{row}"].alignment = Alignment(horizontal="center")
        ws[f"B{row}"] = interpretation
        ws[f"B{row}"].alignment = Alignment(wrap_text=True, vertical="center")
        ws.row_dimensions[row].height = 25
        row += 1
    
    row += 1

    # Areas explanation
    ws.merge_cells(f"A{row}:C{row}")
    ws[f"A{row}"] = "Assessment Areas:"
    ws[f"A{row}"].font = Font(bold=True, size=11)
    row += 1
    
    # Create data for area scores
    scorecard = data.get("scorecard", [])
    if scorecard:
        area_start_row = row
        ws[f"A{area_start_row}"] = "Area"
        ws[f"B{area_start_row}"] = "Score"
        ws[f"C{area_start_row}"] = "Description"
        ws[f"A{area_start_row}"].font = Font(bold=True)
        ws[f"B{area_start_row}"].font = Font(bold=True)
        ws[f"C{area_start_row}"].font = Font(bold=True)
        
        area_descriptions = {
            "Reliability": "Test stability, flakiness, and consistency",
            "Test Design": "Test structure, coverage, and patterns",
            "Framework": "Test framework architecture and setup",
            "Test Data": "Test data management and quality",
            "CI/CD Integration": "Continuous integration and deployment practices",
            "Reporting": "Test results reporting and visibility",
            "Coverage": "Code and requirements coverage",
        }
        
        data_row = area_start_row + 1
        for area in scorecard:
            # Handle both area_name and area fields
            area_id = area.get("area") or area.get("area_id", "unknown")
            area_name = area.get("area_name") or AREA_NAMES.get(area_id, area_id.replace("_", " ").title())
            ws[f"A{data_row}"] = area_name  # Use full area name for axis labels
            ws[f"B{data_row}"] = area.get("score", 0)
            ws[f"B{data_row}"].alignment = Alignment(horizontal="center")
            ws[f"C{data_row}"] = area_descriptions.get(area_name, "")
            ws[f"C{data_row}"].alignment = Alignment(wrap_text=True, vertical="center")
            ws.row_dimensions[data_row].height = 30
            data_row += 1

        # Create radar chart for area scores
        radar = RadarChart()
        radar.type = "filled"
        radar.title = "Area Score Radar (0-100 scale)"
        
        # Set up data and categories
        labels = Reference(ws, min_col=1, min_row=area_start_row+1, max_row=data_row-1)
        data_ref = Reference(ws, min_col=2, min_row=area_start_row, max_row=data_row-1)
        radar.add_data(data_ref, titles_from_data=True)
        radar.set_categories(labels)
        
        # Configure chart appearance to show labels
        radar.height = 15
        radar.width = 18
        radar.style = 26  # Use a style that emphasizes labels
        
        # Add data labels to show actual scores
        radar.dataLabels = DataLabelList()
        radar.dataLabels.showVal = True  # Show values on data points
        
        # Calculate chart position to place it after the description
        chart_position = f"D{area_start_row - 10}"
        ws.add_chart(radar, chart_position)


def main():
    if len(sys.argv) != 3:
        print("Usage: python json_to_xlsx.py input.json output.xlsx", file=sys.stderr)
        sys.exit(2)

    in_path, out_path = sys.argv[1], sys.argv[2]
    
    # Load JSON data
    with open(in_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # Create workbook
    wb = Workbook()
    
    # Create all sheets
    print("Creating Summary sheet...")
    create_summary_sheet(wb, data)
    
    print("Creating Executive Summary sheet...")
    create_executive_summary_sheet(wb, data)
    
    print("Creating Scorecard sheet...")
    create_scorecard_sheet(wb, data)
    
    print("Creating Findings sheet...")
    create_findings_sheet(wb, data)
    
    print("Creating Findings Details sheet...")
    create_findings_detail_sheet(wb, data)
    
    print("Creating Recommendations sheet...")
    create_recommendations_sheet(wb, data)
    
    print("Creating Evidence sheet...")
    create_evidence_sheet(wb, data)
    
    print("Creating Charts sheet...")
    create_charts_sheet(wb, data)
    
    # Save workbook
    wb.save(out_path)
    print(f"✓ Excel report generated: {out_path}")
    print(f"  - Summary with key metrics")
    print(f"  - Executive summary with highlights")
    print(f"  - Scorecard with area assessments and charts")
    print(f"  - Detailed findings with recommendations")
    print(f"  - Evidence and code references")
    print(f"  - Visual analytics dashboard with charts")


if __name__ == "__main__":
    main()
