# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: registration-email-uniqueness.spec.ts >> TC-REQ-6.3: Registering with an email differing only by letter case from an existing account's email is rejected
- Location: registration-email-uniqueness.spec.ts:101:5

# Error details

```
Error: expected different-case duplicate email to be rejected, got 201 - {"status":"success","data":{"username":"","role":"customer","deluxeToken":"","lastLoginIp":"0.0.0.0","profileImage":"/assets/public/images/uploads/default.svg","isActive":true,"id":52,"email":"UNIQUENESS-CASE-1788264652610-ZK5F22XU1P@EXAMPLE.COM","updatedAt":"2026-09-01T12:10:52.887Z","createdAt":"2026-09-01T12:10:52.887Z","deletedAt":null}} (known gap: no case normalization in models/user.ts)

expect(received).toBeFalsy()

Received: true
```

# Test source

```ts
  17  | // properties of undefined (reading 'id')" because another worker's
  18  | // concurrent registration of the same email won the race first).
  19  | //
  20  | // Discovery note, also confirmed by actually running this suite against
  21  | // the live app: models/user.ts's email field is `unique: true` with no
  22  | // lowercase/normalization transform — only server.ts's registration
  23  | // handler trims whitespace. So TC-REQ-6.2 (whitespace) is correctly
  24  | // rejected (trim then duplicate), but TC-REQ-6.3 (case variant) is NOT
  25  | // rejected by the current implementation — it creates a second, distinct
  26  | // account. This is a genuine requirement/implementation gap (REQ-6/REQ-15
  27  | // call for case-insensitive uniqueness), not a test bug — left as a
  28  | // legitimately failing assertion so it stays visible. Cleanup below
  29  | // accounts for this: cleanupIfCreated is called on every response,
  30  | // whether or not that response was expected to create an account.
  31  | 
  32  | const VALID_PASSWORD = 'Val1dPassw0rd!'; // [test data] valid mandatory data
  33  | 
  34  | async function registerAccount(request: APIRequestContext, email: string) {
  35  |   const body = { email, password: VALID_PASSWORD, passwordRepeat: VALID_PASSWORD };
  36  |   const response = await request.post('/api/Users', { data: body });
  37  |   return { response, requestInfo: { method: 'POST', url: '/api/Users', body } };
  38  | }
  39  | 
  40  | // Best-effort cleanup for a response that may or may not have created an
  41  | // account. Never throws — must run safely from a `finally` block even
  42  | // when the response body is unexpected.
  43  | async function cleanupIfCreated(request: APIRequestContext, response: APIResponse) {
  44  |   if (!response.ok()) return;
  45  |   try {
  46  |     const body = await response.json();
  47  |     const userId = body?.data?.id;
  48  |     if (userId) {
  49  |       await request.delete(`/api/Users/${userId}`);
  50  |     }
  51  |   } catch {
  52  |     // Response wasn't the expected shape — nothing to clean up.
  53  |   }
  54  | }
  55  | 
  56  | // TC-REQ-6.1
  57  | test('TC-REQ-6.1: Registering with an email identical to an existing account\'s email is rejected', async ({ request }, testInfo) => {
  58  |   const baseEmail = `uniqueness-identical-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per test run
  59  | 
  60  |   // Arrange — precondition: an account already exists with this email
  61  |   const arrange = await registerAccount(request, baseEmail);
  62  |   const arrangeBody = await attachExchange(testInfo, 'arrange: register existing account', arrange.requestInfo, arrange.response);
  63  |   expect(arrange.response.status(), `expected 201 Created for the arrange-step registration, got ${arrange.response.status()} - ${JSON.stringify(arrangeBody)}`).toBe(201);
  64  | 
  65  |   // Act — register a new account using the same email
  66  |   const act = await registerAccount(request, baseEmail);
  67  |   const actBody = await attachExchange(testInfo, 'act: duplicate registration with identical email', act.requestInfo, act.response);
  68  |   try {
  69  |     // Assert — registration is rejected; no new account is created for this submission
  70  |     expect(act.response.ok(), `expected duplicate registration to be rejected, got ${act.response.status()} - ${JSON.stringify(actBody)}`).toBeFalsy();
  71  |   } finally {
  72  |     // Cleanup — remove whatever was created, whether or not the assertion above passed
  73  |     await cleanupIfCreated(request, act.response);
  74  |     await cleanupIfCreated(request, arrange.response);
  75  |   }
  76  | });
  77  | 
  78  | // TC-REQ-6.2
  79  | test('TC-REQ-6.2: Registering with an email differing only by leading/trailing whitespace from an existing account\'s email is rejected', async ({ request }, testInfo) => {
  80  |   const baseEmail = `uniqueness-whitespace-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per test run
  81  |   const baseEmailWithWhitespace = `  ${baseEmail}  `;
  82  | 
  83  |   // Arrange — precondition: an account already exists with the (trimmed) existing email
  84  |   const arrange = await registerAccount(request, baseEmail);
  85  |   const arrangeBody = await attachExchange(testInfo, 'arrange: register existing account', arrange.requestInfo, arrange.response);
  86  |   expect(arrange.response.status(), `expected 201 Created for the arrange-step registration, got ${arrange.response.status()} - ${JSON.stringify(arrangeBody)}`).toBe(201);
  87  | 
  88  |   // Act — register using the existing email with added leading/trailing whitespace
  89  |   const act = await registerAccount(request, baseEmailWithWhitespace);
  90  |   const actBody = await attachExchange(testInfo, 'act: registration with whitespace-padded duplicate email', act.requestInfo, act.response);
  91  |   try {
  92  |     // Assert — registration is rejected; no new account is created for this submission
  93  |     expect(act.response.ok(), `expected whitespace-padded duplicate email to be rejected (after trim), got ${act.response.status()} - ${JSON.stringify(actBody)}`).toBeFalsy();
  94  |   } finally {
  95  |     await cleanupIfCreated(request, act.response);
  96  |     await cleanupIfCreated(request, arrange.response);
  97  |   }
  98  | });
  99  | 
  100 | // TC-REQ-6.3
  101 | test('TC-REQ-6.3: Registering with an email differing only by letter case from an existing account\'s email is rejected', async ({ request }, testInfo) => {
  102 |   const baseEmail = `uniqueness-case-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per test run
  103 |   const baseEmailDifferentCase = baseEmail.toUpperCase();
  104 | 
  105 |   // Arrange — precondition: an account already exists with the existing email
  106 |   const arrange = await registerAccount(request, baseEmail);
  107 |   const arrangeBody = await attachExchange(testInfo, 'arrange: register existing account', arrange.requestInfo, arrange.response);
  108 |   expect(arrange.response.status(), `expected 201 Created for the arrange-step registration, got ${arrange.response.status()} - ${JSON.stringify(arrangeBody)}`).toBe(201);
  109 | 
  110 |   // Act — register using the existing email with different letter case
  111 |   const act = await registerAccount(request, baseEmailDifferentCase);
  112 |   const actBody = await attachExchange(testInfo, 'act: registration with different-case duplicate email', act.requestInfo, act.response);
  113 |   try {
  114 |     // Assert — registration is rejected; no new account is created for this submission
  115 |     // NOTE: as of this codebase, this currently fails — the real implementation has no
  116 |     // case-normalization on the email uniqueness check (see Discovery note above).
> 117 |     expect(act.response.ok(), `expected different-case duplicate email to be rejected, got ${act.response.status()} - ${JSON.stringify(actBody)} (known gap: no case normalization in models/user.ts)`).toBeFalsy();
      |                                                                                                                                                                                                         ^ Error: expected different-case duplicate email to be rejected, got 201 - {"status":"success","data":{"username":"","role":"customer","deluxeToken":"","lastLoginIp":"0.0.0.0","profileImage":"/assets/public/images/uploads/default.svg","isActive":true,"id":52,"email":"UNIQUENESS-CASE-1788264652610-ZK5F22XU1P@EXAMPLE.COM","updatedAt":"2026-09-01T12:10:52.887Z","createdAt":"2026-09-01T12:10:52.887Z","deletedAt":null}} (known gap: no case normalization in models/user.ts)
  118 |   } finally {
  119 |     await cleanupIfCreated(request, act.response);
  120 |     await cleanupIfCreated(request, arrange.response);
  121 |   }
  122 | });
  123 | 
  124 | // TC-REQ-6.4
  125 | test('TC-REQ-6.4: Concurrent registration submissions for the same normalized email — exactly one succeeds', async ({ request }, testInfo) => {
  126 |   const raceEmail = `uniqueness-race-${Date.now()}-${Math.random().toString(36).slice(2)}@example.com`; // [test data] unique per test run
  127 | 
  128 |   // Arrange — precondition: no account currently exists with this email (fresh run,
  129 |   // guaranteed by the unique email above rather than a fixed literal)
  130 | 
  131 |   // Act — submit two registration requests concurrently with the same normalized email
  132 |   const [a, b] = await Promise.all([registerAccount(request, raceEmail), registerAccount(request, raceEmail)]);
  133 |   const [aBody, bBody] = await Promise.all([
  134 |     attachExchange(testInfo, 'submitA: concurrent registration', a.requestInfo, a.response),
  135 |     attachExchange(testInfo, 'submitB: concurrent registration', b.requestInfo, b.response),
  136 |   ]);
  137 | 
  138 |   try {
  139 |     // Assert — exactly one submission succeeds and creates one account; the other receives
  140 |     // the generic registration failure message (REQ-14)
  141 |     const successCount = [a.response, b.response].filter((r) => r.ok()).length;
  142 |     expect(successCount, `expected exactly one concurrent submission to succeed, got submitA=${a.response.status()} ${JSON.stringify(aBody)}, submitB=${b.response.status()} ${JSON.stringify(bBody)}`).toBe(1);
  143 |   } finally {
  144 |     await cleanupIfCreated(request, a.response);
  145 |     await cleanupIfCreated(request, b.response);
  146 |   }
  147 | });
  148 | 
```